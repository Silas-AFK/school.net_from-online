<?php
// Unified Database Connection for Entire System
// This file provides both PDO and MySQLi connections for compatibility
declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Database Configuration
$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASS = '';
$DB_NAME = 'mercy'; // Single unified database name

// PDO Connection (for report_system and voucher system)
try {
    $conn = new PDO("mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4", $DB_USER, $DB_PASS, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
    $pdo = $conn; // Alias for voucher system compatibility
} catch (PDOException $e) {
    error_log('Database connection failed: ' . $e->getMessage());
    exit('Database connection failed. Please ensure XAMPP MySQL is running and the database "mercy" exists.');
}

// MySQLi Connection (for legacy files using mysqli)
$mysqli_conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
if ($mysqli_conn->connect_error) {
    die("DB Connection failed: " . $mysqli_conn->connect_error);
}
$mysqli_conn->set_charset('utf8mb4');

// Files can check which type they need
if (!isset($conn) || !($conn instanceof PDO)) {
    // If $conn is not PDO, some files might expect mysqli
    // We keep both available
}
?>
