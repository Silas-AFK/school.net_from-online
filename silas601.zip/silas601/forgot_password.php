<?php
// forgot_password.php
require 'includes/db.php';

$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $matricule = trim($_POST['matricule']);

    $stmt = $pdo->prepare("SELECT * FROM admission WHERE matricule = ?");
    $stmt->execute([$matricule]);
    
    if ($stmt->rowCount() > 0) {
        $token = bin2hex(random_bytes(32));
        $expiry = date("Y-m-d H:i:s", strtotime("+1 hour"));

        $updateStmt = $pdo->prepare("UPDATE admission SET reset_token=?, reset_expiry=? WHERE matricule=?");
        $updateStmt->execute([$token, $expiry, $matricule]);

        $resetLink = "http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "/reset_password.php?token=$token";

        $message = "<p style='color: green;'>Password reset link: <a href='$resetLink'>$resetLink</a></p>";
    } else {
        $message = "<p style='color: red;'>Matricule not found.</p>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Forgot Password | CAROMA</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: Arial, sans-serif;
      background: #f0f4f8;
      display: flex;
      flex-direction: column;
      min-height: 100vh;
    }

    /* Logo slide-in */
    .logo-container {
      text-align: center;
      padding: 30px 0 10px;
      animation: slideIn 1s ease-in-out;
    }
    .logo-container img {
      width: 120px;
      height: 120px;
      border-radius: 50%;
      object-fit: cover;
    }
    @keyframes slideIn {
      from { transform: translateY(-100px); opacity: 0; }
      to { transform: translateY(0); opacity: 1; }
    }

    /* Form styling */
    .form-container {
      max-width: 400px;
      margin: 20px auto;
      background: white;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
      text-align: center;
    }

    h2 {
      color: #2e86de;
      margin-bottom: 20px;
    }

    input {
      width: 100%;
      padding: 12px;
      margin-bottom: 15px;
      border: 1px solid #ccc;
      border-radius: 6px;
      font-size: 16px;
    }

    button {
      width: 100%;
      padding: 12px;
      background: #2e86de;
      color: white;
      font-size: 16px;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      transition: background 0.3s;
    }

    button:hover {
      background: #1c5ca8;
    }

    .message {
      margin-top: 10px;
      text-align: center;
    }

    /* Footer */
    footer {
      margin-top: auto;
      background: #000;
      color: white;
      text-align: center;
      padding: 15px 10px;
      font-size: 14px;
    }

    @media (max-width: 500px) {
      .form-container { width: 90%; padding: 20px; }
      .logo-container img { width: 100px; height: 100px; }
    }
  </style>
</head>
<body>

   
  <div class="logo-container">
    <img src="joys.jpg" alt="SMCC Logo">
  </div>

   
  <div class="form-container">
    <h2>Forgot Password</h2>
    <form method="POST">
      <input name="matricule" placeholder="Enter your Matricule" required>
      <button type="submit">Request Reset</button>
    </form>
    <div class="message"><?= $message ?></div>
    <p><a href="login.php">Back to Login</a></p>
  </div>

   
  <footer>
    &copy; <?= date("Y") ?> CAROMA | Powered by Osiris Tech
  </footer>

</body>
</html>
