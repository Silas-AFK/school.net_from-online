<?php
require 'includes/db.php';

// Fetch all staff ordered by display_order
$result = $mysqli_conn->query("SELECT * FROM administrative_staff ORDER BY display_order ASC, id ASC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Administrative Structure | CAROMA</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="style.css">
  
  <style>
    .admin-structure-section {
      padding: 60px 20px;
      background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
    }

    .admin-container {
      max-width: 1200px;
      margin: 0 auto;
    }

    .admin-header {
      text-align: center;
      margin-bottom: 50px;
    }

    .admin-header h1 {
      font-size: 2.5rem;
      color: #2e86de;
      margin-bottom: 15px;
      animation: fadeInDown 1s ease;
    }

    .admin-header p {
      font-size: 1.2rem;
      color: #666;
    }

    @keyframes fadeInDown {
      from {
        opacity: 0;
        transform: translateY(-30px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .staff-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
      gap: 30px;
      margin-bottom: 40px;
    }

    .staff-card {
      background: white;
      border-radius: 15px;
      overflow: hidden;
      box-shadow: 0 5px 20px rgba(0,0,0,0.1);
      transition: transform 0.3s ease, box-shadow 0.3s ease;
      animation: fadeInUp 0.8s ease;
    }

    .staff-card:hover {
      transform: translateY(-10px);
      box-shadow: 0 15px 40px rgba(0,0,0,0.2);
    }

    @keyframes fadeInUp {
      from {
        opacity: 0;
        transform: translateY(30px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .staff-photo-container {
      position: relative;
      width: 100%;
      height: 300px;
      overflow: hidden;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    }

    .staff-photo {
      width: 100%;
      height: 100%;
      object-fit: cover;
      object-position: center top;
      transition: transform 0.5s ease;
      display: block;
    }

    .staff-card:hover .staff-photo {
      transform: scale(1.1);
    }

    .staff-info {
      padding: 25px;
    }

    .staff-name {
      font-size: 1.5rem;
      font-weight: 700;
      color: #333;
      margin-bottom: 8px;
    }

    .staff-position {
      color: #2e86de;
      font-weight: 600;
      font-size: 1.1rem;
      margin-bottom: 15px;
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .staff-bio {
      color: #666;
      line-height: 1.8;
      font-size: 15px;
    }

    .back-home {
      text-align: center;
      margin-top: 40px;
    }

    .back-home a {
      display: inline-block;
      padding: 15px 40px;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      text-decoration: none;
      border-radius: 50px;
      font-weight: 600;
      font-size: 16px;
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .back-home a:hover {
      transform: translateY(-3px);
      box-shadow: 0 10px 25px rgba(102, 126, 234, 0.4);
    }

    @media (max-width: 768px) {
      .admin-header h1 {
        font-size: 2rem;
      }

      .staff-grid {
        grid-template-columns: 1fr;
        gap: 20px;
      }

      .staff-photo-container {
        height: auto;
      }

      .staff-photo {
        height: auto;
        max-width: 100%;
      }
    }
  </style>
</head>
<body>
  <!-- Header -->
  <header class="header">
    <div class="logo">
        <a href="index.html"><img src="joys.jpg" alt="CAROMA Logo" class="pic"></a>
    </div>
    <nav class="nav-links">
      <a href="index.html">Home</a>
      <a href="registrations.html">Admission</a>
      <a href="news.php">News</a>
      <a href="online_class.html">Online Classes</a>
      <a href="view_books.php">E-Library</a>
      <a href="login.php">Log In</a>
      <a href="#contact">Contact</a>
      <a href="administrative.php">Administration</a>
      <a href="#">CCEC</a>
    </nav>
    <div class="hamburger" onclick="toggleSidebar()">☰</div>
  </header>

  <!-- Sidebar for mobile -->
  <div id="sidebar" class="sidebar">
    <a href="javascript:void(0)" class="closebtn" onclick="closeSidebar()">×</a>
    <a href="index.html">Home</a>
    <a href="registrations.html">Admission</a>
    <a href="news.php">News</a> 
    <a href="online_class.html">Online Classes</a>
    <a href="view_books.php">E-Library</a>
    <a href="login.php">Log In</a>
    <a href="#contact">Contact</a>
    <a href="administrative.php">Administration</a>
    <a href="#">CCEC</a>
  </div>

  <!-- Administrative Structure Section -->
  <section class="admin-structure-section">
    <div class="admin-container">
      <div class="admin-header">
        <h1>Our Administrative Team</h1>
        <p>Meet the dedicated leaders of CAROMA COMPREHENSIVE EDUCATION CENTER</p>
      </div>

      <?php if ($result && $result->num_rows > 0): ?>
        <div class="staff-grid">
          <?php while ($staff = $result->fetch_assoc()): ?>
            <div class="staff-card">
              <div class="staff-photo-container">
                <img src="<?= htmlspecialchars($staff['photo']) ?>" 
                     alt="<?= htmlspecialchars($staff['name']) ?>" 
                     class="staff-photo">
              </div>
              <div class="staff-info">
                <div class="staff-name"><?= htmlspecialchars($staff['name']) ?></div>
                <div class="staff-position">
                  <i class="fas fa-user-tie"></i>
                  <?= htmlspecialchars($staff['position']) ?>
                </div>
                <?php if (!empty($staff['bio'])): ?>
                  <div class="staff-bio"><?= nl2br(htmlspecialchars($staff['bio'])) ?></div>
                <?php endif; ?>
              </div>
            </div>
          <?php endwhile; ?>
        </div>
      <?php else: ?>
        <p style="text-align: center; color: #666; font-size: 1.2rem;">
          Administrative information will be available soon.
        </p>
      <?php endif; ?>

      <div class="back-home">
        <a href="index.html">
          <i class="fas fa-home"></i> Back to Home
        </a>
      </div>
    </div>
  </section>

  <!-- Footer Section -->
  <footer class="footer">
    <div class="footer-content">
      <p>&copy; 2025 CAROMA COMPREHENSIVE EDUCATION CENTER. All Rights Reserved.</p>
      <p>Powered By <span style="color: goldenrod; opacity: 80%; ">OSIRIS</span> Tech</p>
      <div class="social-icons">
        <a href="https://wa.me/237676763842" target="_blank" title="Chat with us on WhatsApp">
          <i class="fab fa-whatsapp"></i>
        </a>
      </div>
    </div>
  </footer>
   
  <script src="script.js"></script>
</body>
</html>
