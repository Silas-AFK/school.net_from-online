<?php
session_start();
require 'includes/db.php';

// Check if token is provided
if (!isset($_GET['token'])) {
    die("Invalid or missing token.");
}

$token = trim($_GET['token']);

$stmt = $pdo->prepare("SELECT matricule FROM admission WHERE reset_token=? AND reset_expiry > NOW()");
$stmt->execute([$token]);

if ($stmt->rowCount() == 0) {
    die("This reset link is invalid or has expired.");
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validate new password (basic example)
    if (empty($_POST['password']) || strlen($_POST['password']) < 6) {
        $error = "Password must be at least 6 characters long.";
    } else {
        $newPassword = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $updateStmt = $pdo->prepare("UPDATE admission SET password=?, reset_token=NULL, reset_expiry=NULL WHERE reset_token=?");
        
        if ($updateStmt->execute([$newPassword, $token])) {
            $success = "Password has been reset successfully. <a href='login.php'>Login Now</a>";
        } else {
            $error = "Error updating password, please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Reset Password | CAROMA</title>
<style>
  body {
    font-family: Arial, sans-serif;
    background: #f4f6f8;
    display: flex;
    flex-direction: column;
    min-height: 100vh;
    margin: 0; padding: 0;
  }
  header {
    text-align: center;
    padding: 20px 10px;
    background: #00050a;
    color: white;
    font-weight: bold;
    font-size: 1.5rem;
  }
  main {
    flex: 1;
    max-width: 400px;
    margin: 40px auto;
    background: white;
    padding: 25px 30px;
    border-radius: 10px;
    box-shadow: 0 0 15px rgba(0,0,0,0.1);
  }
  form > h2 {
    text-align: center;
    margin-bottom: 20px;
    color: #2e86de;
  }
  input[type="password"] {
    width: 100%;
    padding: 12px;
    margin-bottom: 15px;
    border-radius: 8px;
    border: 1px solid #ccc;
    font-size: 1rem;
  }
  button {
    width: 100%;
    padding: 12px;
    background-color: #2e86de;
    border: none;
    color: white;
    font-size: 1.1rem;
    border-radius: 8px;
    cursor: pointer;
  }
  button:hover {
    background-color: #1c5ca8;
  }
  .message {
    margin-bottom: 15px;
    padding: 10px;
    border-radius: 6px;
    font-weight: bold;
  }
  .error {
    background-color: #ffdddd;
    color: #d8000c;
  }
  .success {
    background-color: #ddffdd;
    color: #270;
  }
  footer {
    text-align: center;
    padding: 15px 0;
    background: #00050a;
    color: white;
    font-size: 0.9rem;
  }
</style>
</head>
<body>

<header>CAROMA Password Reset</header>

<main>
  <?php if (!empty($error)): ?>
    <div class="message error"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <?php if (!empty($success)): ?>
    <div class="message success"><?= $success ?></div>
  <?php else: ?>
  <form method="POST" novalidate>
    <h2>Enter New Password</h2>
    <input type="password" name="password" placeholder="New password (min 6 chars)" required minlength="6" />
    <button type="submit">Reset Password</button>
  </form>
  <?php endif; ?>
</main>

<footer>
  &copy; <?= date("Y") ?> CAROMA | Powered by Osiris Tech
</footer>

</body>
</html>
