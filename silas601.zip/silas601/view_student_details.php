<?php
session_start();
if (empty($_SESSION['admin']) && empty($_SESSION['main_admin'])) {
    header('Location: admin_login.php');
    exit();
}

require 'includes/db.php';

$matricule = $_GET['matricule'] ?? '';

if (empty($matricule)) {
    header('Location: manage_students.php');
    exit();
}

$stmt = $conn->prepare("SELECT * FROM admission WHERE matricule = :matricule");
$stmt->bindValue(':matricule', $matricule, PDO::PARAM_STR);
$stmt->execute();
$student = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$student) {
    header('Location: manage_students.php?error=notfound');
    exit();
}

$stmt = null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Student Details - <?= htmlspecialchars($student['fullName']) ?></title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
      padding: 20px;
    }

    .container {
      max-width: 1000px;
      margin: 0 auto;
      background: white;
      border-radius: 15px;
      box-shadow: 0 10px 40px rgba(0,0,0,0.3);
      overflow: hidden;
    }

    .header {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      padding: 30px;
      text-align: center;
    }

    .header h1 {
      font-size: 2rem;
      margin-bottom: 10px;
    }

    .content {
      padding: 40px;
    }

    .profile-section {
      display: flex;
      gap: 30px;
      margin-bottom: 40px;
      flex-wrap: wrap;
    }

    .photo-container {
      flex-shrink: 0;
    }

    .student-photo {
      width: 200px;
      height: 200px;
      border-radius: 15px;
      object-fit: cover;
      border: 5px solid #667eea;
      box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    }

    .basic-info {
      flex: 1;
    }

    .info-card {
      background: #f8f9fa;
      border-left: 4px solid #667eea;
      padding: 20px;
      margin-bottom: 20px;
      border-radius: 8px;
    }

    .info-card h3 {
      color: #667eea;
      margin-bottom: 15px;
      font-size: 1.3rem;
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .info-row {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 15px;
      margin-bottom: 10px;
    }

    .info-item {
      padding: 10px 0;
    }

    .info-label {
      font-weight: 600;
      color: #666;
      font-size: 14px;
      margin-bottom: 5px;
    }

    .info-value {
      color: #333;
      font-size: 16px;
    }

    .actions {
      display: flex;
      gap: 15px;
      justify-content: center;
      margin-top: 30px;
      flex-wrap: wrap;
    }

    .btn {
      padding: 12px 30px;
      border: none;
      border-radius: 8px;
      font-size: 16px;
      font-weight: 600;
      cursor: pointer;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      transition: transform 0.2s ease, box-shadow 0.2s ease;
    }

    .btn-primary {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
    }

    .btn-secondary {
      background: #6c757d;
      color: white;
    }

    .btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 5px 15px rgba(0,0,0,0.3);
    }

    @media (max-width: 768px) {
      .profile-section {
        flex-direction: column;
        align-items: center;
      }

      .student-photo {
        width: 150px;
        height: 150px;
      }

      .content {
        padding: 20px;
      }

      .info-row {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>

<div class="container">
  <div class="header">
    <h1><i class="fas fa-user-graduate"></i> Student Details</h1>
    <p>Complete information for <?= htmlspecialchars($student['fullName']) ?></p>
  </div>

  <div class="content">
    <div class="profile-section">
      <div class="photo-container">
        <?php 
          $photoPath = !empty($student['photo']) ? $student['photo'] : 'uploads/default.jpg';
          if (!file_exists($photoPath)) $photoPath = 'uploads/default.jpg';
        ?>
        <img src="<?= htmlspecialchars($photoPath) ?>" alt="Student Photo" class="student-photo">
      </div>

      <div class="basic-info">
        <div class="info-card">
          <h3><i class="fas fa-id-card"></i> Basic Information</h3>
          <div class="info-row">
            <div class="info-item">
              <div class="info-label">Matricule Number</div>
              <div class="info-value"><strong><?= htmlspecialchars($student['matricule']) ?></strong></div>
            </div>
            <div class="info-item">
              <div class="info-label">Full Name</div>
              <div class="info-value"><?= htmlspecialchars($student['fullName']) ?></div>
            </div>
          </div>
          <div class="info-row">
            <div class="info-item">
              <div class="info-label">Gender</div>
              <div class="info-value"><?= htmlspecialchars($student['sex']) ?></div>
            </div>
            <div class="info-item">
              <div class="info-label">Class Level</div>
              <div class="info-value"><?= htmlspecialchars($student['classLevel']) ?></div>
            </div>
          </div>
          <div class="info-row">
            <div class="info-item">
              <div class="info-label">Date of Birth</div>
              <div class="info-value"><?= date("F j, Y", strtotime($student['dob'])) ?></div>
            </div>
            <div class="info-item">
              <div class="info-label">Place of Birth</div>
              <div class="info-value"><?= htmlspecialchars($student['placeOfBirth']) ?></div>
            </div>
          </div>
          <div class="info-row">
            <div class="info-item">
              <div class="info-label">Residence</div>
              <div class="info-value"><?= htmlspecialchars($student['residence']) ?></div>
            </div>
            <div class="info-item">
              <div class="info-label">Registration Date</div>
              <div class="info-value"><?= date("F j, Y", strtotime($student['registrationDate'])) ?></div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="info-card">
      <h3><i class="fas fa-users"></i> Parent/Guardian Information</h3>
      <div class="info-row">
        <div class="info-item">
          <div class="info-label">Father's Name</div>
          <div class="info-value"><?= htmlspecialchars($student['fatherName']) ?></div>
        </div>
        <div class="info-item">
          <div class="info-label">Father's Phone</div>
          <div class="info-value"><?= htmlspecialchars($student['fatherPhone']) ?></div>
        </div>
        <div class="info-item">
          <div class="info-label">Father's Residence</div>
          <div class="info-value"><?= htmlspecialchars($student['fatherResidence']) ?></div>
        </div>
      </div>
      <div class="info-row">
        <div class="info-item">
          <div class="info-label">Mother's Name</div>
          <div class="info-value"><?= htmlspecialchars($student['motherName']) ?></div>
        </div>
        <div class="info-item">
          <div class="info-label">Mother's Phone</div>
          <div class="info-value"><?= htmlspecialchars($student['motherPhone']) ?></div>
        </div>
        <div class="info-item">
          <div class="info-label">Mother's Residence</div>
          <div class="info-value"><?= htmlspecialchars($student['motherResidence']) ?></div>
        </div>
      </div>
      <div class="info-row">
        <div class="info-item">
          <div class="info-label">Guardian's Name</div>
          <div class="info-value"><?= htmlspecialchars($student['guardianName']) ?></div>
        </div>
        <div class="info-item">
          <div class="info-label">Guardian's Phone</div>
          <div class="info-value"><?= htmlspecialchars($student['guardianPhone']) ?></div>
        </div>
        <div class="info-item">
          <div class="info-label">Guardian's Residence</div>
          <div class="info-value"><?= htmlspecialchars($student['guardianResidence']) ?></div>
        </div>
      </div>
    </div>

    <div class="actions">
      <a href="manage_students.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i> Back to Student List
      </a>
      <a href="admin_panel.php" class="btn btn-primary">
        <i class="fas fa-home"></i> Admin Panel
      </a>
    </div>
  </div>
</div>

</body>
</html>
