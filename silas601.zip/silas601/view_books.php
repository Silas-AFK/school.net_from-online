<?php
require 'includes/db.php';

// Get class filter from GET or POST
$classFilter = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty(trim($_POST['class']))) {
    $classFilter = trim($_POST['class']);
} elseif (!empty($_GET['class'])) {
    $classFilter = trim($_GET['class']);
}

// Get unique classes for dropdown
$classes_result = $mysqli_conn->query("SELECT DISTINCT class FROM books WHERE class IS NOT NULL AND class != '' ORDER BY class");

if ($classFilter !== '') {
    $stmt = $mysqli_conn->prepare("SELECT * FROM books WHERE class LIKE ? ORDER BY uploaded_at DESC");
    $likeClass = "%$classFilter%";
    $stmt->bind_param("s", $likeClass);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $mysqli_conn->query("SELECT * FROM books ORDER BY uploaded_at DESC");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>CAROMA E-Library</title>
  <meta name="viewport" content="width=device-width, initial-scale=1" />

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />

  <style>
    * {
      box-sizing: border-box;
    }
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      background: #f4f6f8;
      color: #333;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }
    /* Header */
    header.header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: #2e86de;
      padding: 10px 20px;
      color: white;
      position: sticky;
      top: 0;
      z-index: 1000;
    }
    header .logo a {
      display: inline-block;
    }
    header .logo img {
      height: 40px;
      border-radius: 8px;
      vertical-align: middle;
    }
    nav.nav-links {
      display: flex;
      gap: 20px;
      font-weight: bold;
    }
    nav.nav-links a {
      color: white;
      text-decoration: none;
      transition: color 0.3s;
      line-height: 40px;
    }
    nav.nav-links a:hover {
      color: #a8c7ff;
    }
    .hamburger {
      display: none;
      font-size: 28px;
      cursor: pointer;
      user-select: none;
    }
    .sidebar {
      display: none;
      position: fixed;
      top: 0; left: 0;
      width: 250px;
      height: 100%;
      background: #2e86de;
      padding-top: 60px;
      overflow-y: auto;
      z-index: 1100;
      transition: transform 0.3s ease;
      transform: translateX(-260px);
    }
    .sidebar.open {
      transform: translateX(0);
      display: block;
    }
    .sidebar a {
      display: block;
      color: white;
      padding: 12px 20px;
      text-decoration: none;
      font-weight: bold;
      border-bottom: 1px solid #3d9bff;
    }
    .sidebar a:hover {
      background: #1e66c0;
    }
    .sidebar .closebtn {
      position: absolute;
      top: 10px;
      right: 20px;
      font-size: 28px;
      cursor: pointer;
    }

    /* Filter form styles */
    form.filter-form {
      max-width: 500px;
      margin: 20px auto;
      text-align: center;
      display: flex;
      gap: 10px;
      justify-content: center;
      flex-wrap: wrap;
    }
    form.filter-form select {
      padding: 12px;
      font-size: 16px;
      border: 2px solid #2e86de;
      border-radius: 8px;
      outline: none;
      flex: 1;
      min-width: 200px;
      background: white;
    }
    form.filter-form button {
      padding: 12px 24px;
      font-size: 16px;
      border: none;
      background-color: #2e86de;
      color: white;
      border-radius: 8px;
      cursor: pointer;
      transition: background-color 0.3s ease;
      font-weight: 600;
    }
    form.filter-form button:hover {
      background-color: #1b4f91;
    }

    main.content {
      flex-grow: 1;
      padding: 20px;
      max-width: 1200px;
      margin: 20px auto;
    }
    h2.page-title {
      text-align: center;
      margin-bottom: 30px;
      color: #2e86de;
      font-size: 28px;
    }
    .book-container {
      display: flex;
      flex-wrap: wrap;
      gap: 20px;
      justify-content: center;
    }
    .book-card {
      background: white;
      padding: 15px;
      border-radius: 8px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
      width: 200px;
      text-align: center;
      transition: transform 0.2s ease;
    }
    .book-card:hover {
      transform: translateY(-5px);
    }
    .book-card img {
      width: 100%;
      height: 250px;
      object-fit: cover;
      border-radius: 5px;
      margin-bottom: 10px;
    }
    .book-card h3 {
      font-size: 16px;
      margin: 10px 0 5px;
      color: #333;
    }
    .book-card p {
      font-size: 14px;
      color: #555;
      margin: 0;
    }

    footer.footer {
      background: #2e86de;
      color: white;
      text-align: center;
      padding: 15px 20px;
      flex-shrink: 0;
    }
    .footer-content {
      max-width: 900px;
      margin: auto;
    }
    .social-icons {
      margin-top: 8px;
    }
    .social-icons a {
      color: white;
      margin: 0 10px;
      font-size: 20px;
      transition: color 0.3s;
      text-decoration: none;
    }
    .social-icons a:hover {
      color: #a8c7ff;
    }

    @media (max-width: 768px) {
      nav.nav-links {
        display: none;
      }
      .hamburger {
        display: block;
      }
      main.content {
        margin: 15px;
        padding: 10px;
      }
      .book-card {
        width: 45%;
      }
      form.filter-form {
        flex-direction: column;
      }
      form.filter-form select {
        min-width: 100%;
      }
    }
    @media (max-width: 480px) {
      .book-card {
        width: 100%;
      }
    }
    .admission-logo {
      display: flex;
      justify-content: center;
      align-items: center;
      margin: 20px auto 0 auto;
      animation: slide-in 1s ease-out;
    }

    .admission-logo img {
      width: 120px;
      height: auto;
      border-radius: 12px;
      animation: logo-fade 1s ease-out;
    }

    @keyframes slide-in {
      from {
        transform: translateX(-100%);
        opacity: 0;
      }
      to {
        transform: translateX(0);
        opacity: 1;
      }
    }

    @keyframes logo-fade {
      from {
        opacity: 0;
        transform: scale(0.8);
      }
      to {
        opacity: 1;
        transform: scale(1);
      }
    }

    @media (max-width: 600px) {
      .admission-logo img {
        width: 80px;
      }
    }
  </style>
</head>
<body>

  <!-- Header / Navbar -->
  <header class="header" role="banner">
    <div class="logo">
      <a href="index.html" aria-label="CAROMA Home">
        <img src="joys.jpg" alt="CAROMA Logo" />
      </a>
    </div>
    <nav class="nav-links" role="navigation" aria-label="Primary navigation">
      <a href="index.html">Home</a>
      <a href="registrations.html">Admission</a>
      <a href="login.php">Log In</a>
      <a href="news.php">News</a>
    </nav>
    <div class="hamburger" role="button" tabindex="0" aria-label="Open menu" onclick="toggleSidebar()">☰</div>
  </header>

  <!-- Sidebar for mobile -->
  <nav id="sidebar" class="sidebar" aria-hidden="true" aria-label="Mobile menu">
    <a href="javascript:void(0)" class="closebtn" aria-label="Close menu" onclick="closeSidebar()">×</a>
    <a href="index.html">Home</a>
    <a href="admission.html">Admission</a>
    <a href="login.php">Log In</a>
    <a href="news.php">News</a>
  </nav>

  <!-- Admission Logo -->
  <div class="admission-logo">
    <img src="joys.jpg" alt="CAROMA">
  </div>

  <!-- Filter form -->
  <form method="POST" class="filter-form" aria-label="Filter books by class">
    <select name="class" aria-label="Select class">
      <option value="">All Classes</option>
      <?php while ($class_row = $classes_result->fetch_assoc()): ?>
        <option value="<?= htmlspecialchars($class_row['class']) ?>" 
                <?= $classFilter === $class_row['class'] ? 'selected' : '' ?>>
          <?= htmlspecialchars($class_row['class']) ?>
        </option>
      <?php endwhile; ?>
    </select>
    <button type="submit"><i class="fas fa-filter"></i> Filter Books</button>
  </form>

  <!-- Main E-Library Content -->
  <main class="content" role="main">
    <h2 class="page-title">CAROMA E-Library</h2>

    <?php if ($result->num_rows === 0): ?>
      <p style="text-align:center; font-size: 18px; color: #666;">
        <?php if ($classFilter): ?>
          No books found for "<?= htmlspecialchars($classFilter) ?>".
        <?php else: ?>
          No books available in the library yet.
        <?php endif; ?>
      </p>
    <?php else: ?>
      <div class="book-container">
        <?php while($book = $result->fetch_assoc()): ?>
          <div class="book-card">
            <img src="<?= htmlspecialchars($book['image']) ?>" alt="Book Image">
            <h3><?= htmlspecialchars($book['title']) ?></h3>
            <p>Class: <?= htmlspecialchars($book['class']) ?></p>
          </div>
        <?php endwhile; ?>
      </div>
    <?php endif; ?>
  </main>

  <!-- Footer Section -->
  <footer class="footer">
    <div class="footer-content">
      <p>&copy; 2025 CAROMA COMPREHENSIVE EDUCATION CENTER. All Rights Reserved.</p>
      <p>Powered By <span style="color: goldenrod; opacity: 80%; ">OSIRIS</span> Tech</p>
      <div class="social-icons">
        <a href="https://wa.me/237676763842" target="_blank" title="Chat with us on WhatsApp">
          <i class="fab fa-whatsapp"></i>
        </a>
      </div>
    </div>
  </footer>

  <script>
    function toggleSidebar() {
      const sidebar = document.getElementById('sidebar');
      const isOpen = sidebar.classList.contains('open');
      if (isOpen) {
        sidebar.classList.remove('open');
        sidebar.setAttribute('aria-hidden', 'true');
      } else {
        sidebar.classList.add('open');
        sidebar.setAttribute('aria-hidden', 'false');
      }
    }
    function closeSidebar() {
      const sidebar = document.getElementById('sidebar');
      sidebar.classList.remove('open');
      sidebar.setAttribute('aria-hidden', 'true');
    }

    document.querySelector('.hamburger').addEventListener('keydown', function(e) {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        toggleSidebar();
      }
    });
  </script>

</body>
</html>
<?php
if (isset($stmt)) {
    $stmt->close();
}
$mysqli_conn->close();
?>
