# Database Consolidation - Setup Checklist

## ✅ What Has Been Done

All code has been updated to use a single unified database connection. Here's what was completed:

### 1. **Unified Database Connection Created**
- ✅ `includes/db.php` - Main connection file for entire system
- ✅ Provides both PDO and MySQLi connections
- ✅ Connects to "mercy" database

### 2. **All Files Updated** (40+ files)
- ✅ Root system files (conect.php, manage_students.php, etc.)
- ✅ Payment system files (payment_voucher.php, save_voucher.php, etc.)
- ✅ Report system files (all files in report_system/)
- ✅ All files now use `includes/db.php`

### 3. **Matricule Generation System**
- ✅ SQL script created: `scripts/001_merge_databases.sql`
- ✅ Auto-generates format: CCECYY#### (e.g., CCEC250001)
- ✅ MySQL function and trigger included in script

### 4. **Documentation**
- ✅ Complete guide: `DATABASE_CONSOLIDATION_GUIDE.md`
- ✅ This checklist: `SETUP_CHECKLIST.md`

---

## 🚀 What You Need To Do

### Step 1: Run the Database Migration Script

**Option A: Using phpMyAdmin (Recommended)**
1. Open phpMyAdmin in your browser (usually http://localhost/phpmyadmin)
2. Click on the "mercy" database in the left sidebar
3. Click the "SQL" tab at the top
4. Open the file `scripts/001_merge_databases.sql` in a text editor
5. Copy ALL the contents
6. Paste into the SQL query box in phpMyAdmin
7. Click "Go" button
8. Wait for "Database consolidation completed successfully!" message

**Option B: Using MySQL Command Line**
\`\`\`bash
mysql -u root -p mercy < scripts/001_merge_databases.sql
\`\`\`
(Press Enter, then type your MySQL password if you have one)

### Step 2: Verify the Setup

Run these SQL queries in phpMyAdmin to verify everything is working:

\`\`\`sql
-- Check if the function was created
SHOW FUNCTION STATUS WHERE Name = 'generate_matricule';

-- Check if the trigger was created
SHOW TRIGGERS WHERE `Trigger` = 'before_admission_insert';

-- Check how many students have matricule numbers
SELECT 
    COUNT(*) as total_students,
    COUNT(matricule) as students_with_matricule,
    COUNT(*) - COUNT(matricule) as students_without_matricule
FROM admission;

-- Test the matricule generation function
SELECT generate_matricule() as sample_matricule_1;
SELECT generate_matricule() as sample_matricule_2;
SELECT generate_matricule() as sample_matricule_3;
\`\`\`

**Expected Results:**
- Function and trigger should exist
- All students should have matricule numbers
- Sample matricules should be in format CCEC25#### (for year 2025)

### Step 3: Test Student Registration

1. Go to your student registration page (conect.php)
2. Register a new test student
3. Check the database to see if matricule was auto-generated:

\`\`\`sql
SELECT matricule, fullName, classLevel, registrationDate 
FROM admission 
ORDER BY registrationDate DESC 
LIMIT 5;
\`\`\`

The newest student should have a matricule like `CCEC250001`, `CCEC250002`, etc.

### Step 4: Test Both Systems

**Test Root System:**
- ✅ Student registration (conect.php)
- ✅ Student management (manage_students.php)
- ✅ Payment vouchers (payment_voucher.php)
- ✅ View complaints (view_complaints.php)

**Test Report System:**
- ✅ Login to report system
- ✅ View students (should see students from admission table)
- ✅ Enter scores
- ✅ Generate report cards

---

## 🔧 Troubleshooting

### Problem: "Table doesn't exist" errors
**Solution:** Make sure you ran the migration script on the "mercy" database

### Problem: "Function generate_matricule does not exist"
**Solution:** The migration script didn't run completely. Run it again.

### Problem: "Duplicate entry for key 'matricule'"
**Solution:** This shouldn't happen, but if it does:
\`\`\`sql
-- Find duplicates
SELECT matricule, COUNT(*) 
FROM admission 
GROUP BY matricule 
HAVING COUNT(*) > 1;

-- Fix by setting duplicates to NULL (trigger will regenerate)
UPDATE admission 
SET matricule = NULL 
WHERE id IN (SELECT id FROM (SELECT id FROM admission WHERE matricule = 'DUPLICATE_VALUE') as temp);
\`\`\`

### Problem: Students not showing in report system
**Solution:** Run the sync query:
\`\`\`sql
INSERT INTO students (matricule, full_name, class, date_of_birth, gender, parent_contact, address, photo)
SELECT 
    a.matricule,
    a.fullName,
    a.classLevel,
    a.dob,
    a.sex,
    COALESCE(a.fatherPhone, a.motherPhone, a.guardianPhone),
    a.residence,
    a.photo
FROM admission a
WHERE NOT EXISTS (SELECT 1 FROM students s WHERE s.matricule = a.matricule)
AND a.matricule IS NOT NULL AND a.matricule != '';
\`\`\`

---

## 📊 System Architecture

\`\`\`
┌─────────────────────────────────────────┐
│         UNIFIED DATABASE: mercy         │
├─────────────────────────────────────────┤
│  Tables:                                │
│  • admission (student registration)     │
│  • students (report system records)     │
│  • scores, subjects, classes            │
│  • report_cards, academic_years         │
│  • payment_vouchers, payments           │
│  • complaints, news, users              │
└─────────────────────────────────────────┘
                    ▲
                    │
        ┌───────────┴───────────┐
        │                       │
┌───────┴────────┐    ┌────────┴────────┐
│  Root System   │    │ Report System   │
│  (Admission,   │    │  (Academic      │
│   Payments)    │    │   Records)      │
└────────────────┘    └─────────────────┘
        │                       │
        └───────────┬───────────┘
                    │
            ┌───────┴────────┐
            │ includes/db.php│
            │ (Single Source)│
            └────────────────┘
\`\`\`

---

## ✨ Benefits You Now Have

1. **Single Database** - No more managing two separate databases
2. **Auto Matricule Numbers** - Generated automatically, no manual work
3. **Data Consistency** - Students registered once, available everywhere
4. **Better Performance** - No cross-database queries
5. **Easier Maintenance** - One connection file to update
6. **Data Integrity** - Proper foreign key relationships

---

## 📞 Need Help?

If you encounter any issues:
1. Check the `DATABASE_CONSOLIDATION_GUIDE.md` for detailed explanations
2. Review the troubleshooting section above
3. Verify your database credentials in `includes/db.php`
4. Make sure XAMPP MySQL service is running

---

**Status**: ✅ Code consolidation complete - Ready for database migration  
**Next Step**: Run the migration script (Step 1 above)  
**Estimated Time**: 2-5 minutes
