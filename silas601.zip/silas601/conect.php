<?php
session_start();
require_once 'includes/db.php'; 

$fullName = $_POST['fullName'];
$dob = $_POST['dob'];
$placeOfBirth = $_POST['placeOfBirth'];
$residence = $_POST['residence'];
$fatherName = $_POST['fatherName'];
$fatherPhone = $_POST['fatherPhone'];
$fatherResidence = $_POST['fatherResidence'];
$motherName = $_POST['motherName'];
$motherPhone = $_POST['motherPhone'];
$motherResidence = $_POST['motherResidence'];
$guardianName = $_POST['guardianName'];
$guardianPhone = $_POST['guardianPhone'];
$guardianResidence = $_POST['guardianResidence'];
$classLevel = $_POST['classLevel'];
$password = $_POST['password'];
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);
$sex = $_POST['sex'];

// Handle image upload
$targetDir = "uploads/";
if (!is_dir($targetDir)) {
    mkdir($targetDir, 0755, true);
}

$photoName = basename($_FILES["photo"]["name"]);
$uniqueName = time() . "_" . $photoName;
$targetFile = $targetDir . $uniqueName;

if (!move_uploaded_file($_FILES["photo"]["tmp_name"], $targetFile)) {
    die("Failed to upload photo.");
}

$stmt = $mysqli_conn->prepare("INSERT INTO admission (
    fullName, dob, placeOfBirth, sex, residence,
    fatherName, fatherPhone, fatherResidence,
    motherName, motherPhone, motherResidence,
    guardianName, guardianPhone, guardianResidence,
    photo, classLevel, password
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

if (!$stmt) {
    die("Prepare failed: (" . $mysqli_conn->errno . ") " . $mysqli_conn->error);
}

$stmt->bind_param(
    "sssssssssssssssss",
    $fullName, $dob, $placeOfBirth, $sex, $residence,
    $fatherName, $fatherPhone, $fatherResidence,
    $motherName, $motherPhone, $motherResidence,
    $guardianName, $guardianPhone, $guardianResidence,
    $targetFile, $classLevel, $hashedPassword
);

if ($stmt->execute()) {
    $last_id = $mysqli_conn->insert_id;

    $matricule = "CAROMA" . str_pad((string)$last_id, 3, "0", STR_PAD_LEFT);

    $update = $mysqli_conn->prepare("UPDATE admission SET matricule = ? WHERE id = ?");
    if (!$update) {
        die("Update prepare failed: (" . $mysqli_conn->errno . ") " . $mysqli_conn->error);
    }
    $update->bind_param("si", $matricule, $last_id);
    $update->execute();
    $update->close();

    $_SESSION['registration_success'] = "Registration successful! Your Matricule is: $matricule";
    header("Location: login.php");
    exit();
} else {
    echo "Error during registration: " . $stmt->error;
}

$stmt->close();
$mysqli_conn->close();
?>
