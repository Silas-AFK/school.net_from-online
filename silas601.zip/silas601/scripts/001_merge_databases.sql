-- Database Consolidation Script
-- This script merges the 'samo' database into 'mercy' database
-- Run this script to consolidate both systems into one database

-- ============================================
-- STEP 1: Ensure all tables from 'samo' exist in 'mercy'
-- ============================================

USE mercy;

-- Create students table if it doesn't exist (from samo database)
CREATE TABLE IF NOT EXISTS students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    matricule VARCHAR(50) UNIQUE NOT NULL,
    full_name VARCHAR(255) NOT NULL,
    class VARCHAR(100),
    date_of_birth DATE,
    gender ENUM('Male', 'Female'),
    parent_contact VARCHAR(20),
    address TEXT,
    photo VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_matricule (matricule),
    INDEX idx_class (class)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create scores table if it doesn't exist
CREATE TABLE IF NOT EXISTS scores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    subject_id INT NOT NULL,
    term VARCHAR(50) NOT NULL,
    academic_year VARCHAR(20) NOT NULL,
    score DECIMAL(5,2),
    grade VARCHAR(5),
    remarks TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    INDEX idx_student_term (student_id, term, academic_year)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create subjects table if it doesn't exist
CREATE TABLE IF NOT EXISTS subjects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    subject_name VARCHAR(255) NOT NULL,
    subject_code VARCHAR(50) UNIQUE,
    class_level VARCHAR(100),
    coefficient INT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_class_level (class_level)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create classes table if it doesn't exist
CREATE TABLE IF NOT EXISTS classes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    class_name VARCHAR(100) UNIQUE NOT NULL,
    class_level VARCHAR(50),
    section VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create academic_years table if it doesn't exist
CREATE TABLE IF NOT EXISTS academic_years (
    id INT AUTO_INCREMENT PRIMARY KEY,
    year_name VARCHAR(20) UNIQUE NOT NULL,
    start_date DATE,
    end_date DATE,
    is_current BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create report_cards table if it doesn't exist
CREATE TABLE IF NOT EXISTS report_cards (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    term VARCHAR(50) NOT NULL,
    academic_year VARCHAR(20) NOT NULL,
    total_score DECIMAL(10,2),
    average DECIMAL(5,2),
    rank INT,
    class_size INT,
    conduct VARCHAR(255),
    teacher_remarks TEXT,
    principal_remarks TEXT,
    next_term_begins DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    UNIQUE KEY unique_report (student_id, term, academic_year),
    INDEX idx_term_year (term, academic_year)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create school_info table if it doesn't exist
CREATE TABLE IF NOT EXISTS school_info (
    id INT AUTO_INCREMENT PRIMARY KEY,
    school_name VARCHAR(255) NOT NULL,
    school_address TEXT,
    school_phone VARCHAR(20),
    school_email VARCHAR(255),
    school_logo VARCHAR(255),
    school_motto TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- STEP 2: Add matricule column to admission table if it doesn't exist
-- ============================================

-- Check if matricule column exists in admission table, if not add it
SET @col_exists = (
    SELECT COUNT(*) 
    FROM INFORMATION_SCHEMA.COLUMNS 
    WHERE TABLE_SCHEMA = 'mercy' 
    AND TABLE_NAME = 'admission' 
    AND COLUMN_NAME = 'matricule'
);

SET @sql = IF(@col_exists = 0,
    'ALTER TABLE admission ADD COLUMN matricule VARCHAR(50) UNIQUE AFTER id',
    'SELECT "Column matricule already exists" AS message'
);

PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- ============================================
-- STEP 3: Create function to generate matricule numbers
-- ============================================

DELIMITER $$

DROP FUNCTION IF EXISTS generate_matricule$$

CREATE FUNCTION generate_matricule()
RETURNS VARCHAR(50)
DETERMINISTIC
BEGIN
    DECLARE new_matricule VARCHAR(50);
    DECLARE matricule_exists INT;
    DECLARE counter INT DEFAULT 0;
    DECLARE year_prefix VARCHAR(4);
    DECLARE sequence_num INT;
    
    -- Get current year (last 2 digits)
    SET year_prefix = RIGHT(YEAR(CURDATE()), 2);
    
    -- Get the highest sequence number for this year
    SELECT COALESCE(MAX(CAST(SUBSTRING(matricule, 8) AS UNSIGNED)), 0) + 1
    INTO sequence_num
    FROM admission
    WHERE matricule LIKE CONCAT('CCEC', year_prefix, '%');
    
    -- If no records found, start from 1
    IF sequence_num IS NULL THEN
        SET sequence_num = 1;
    END IF;
    
    -- Generate matricule in format: CCECYY0001
    SET new_matricule = CONCAT('CCEC', year_prefix, LPAD(sequence_num, 4, '0'));
    
    -- Check if matricule already exists (safety check)
    SELECT COUNT(*) INTO matricule_exists
    FROM admission
    WHERE matricule = new_matricule;
    
    -- If exists, increment until we find a unique one
    WHILE matricule_exists > 0 AND counter < 100 DO
        SET sequence_num = sequence_num + 1;
        SET new_matricule = CONCAT('CCEC', year_prefix, LPAD(sequence_num, 4, '0'));
        
        SELECT COUNT(*) INTO matricule_exists
        FROM admission
        WHERE matricule = new_matricule;
        
        SET counter = counter + 1;
    END WHILE;
    
    RETURN new_matricule;
END$$

DELIMITER ;

-- ============================================
-- STEP 4: Create trigger to auto-generate matricule on insert
-- ============================================

DELIMITER $$

DROP TRIGGER IF EXISTS before_admission_insert$$

CREATE TRIGGER before_admission_insert
BEFORE INSERT ON admission
FOR EACH ROW
BEGIN
    -- Only generate matricule if it's not provided or is empty
    IF NEW.matricule IS NULL OR NEW.matricule = '' THEN
        SET NEW.matricule = generate_matricule();
    END IF;
END$$

DELIMITER ;

-- ============================================
-- STEP 5: Update existing records without matricule
-- ============================================

-- Generate matricule for existing students who don't have one
UPDATE admission
SET matricule = generate_matricule()
WHERE matricule IS NULL OR matricule = '';

-- ============================================
-- STEP 6: Sync data from admission table to students table
-- ============================================

-- Insert students from admission table into students table if they don't exist
INSERT INTO students (matricule, full_name, class, date_of_birth, gender, parent_contact, address, photo)
SELECT 
    a.matricule,
    a.fullName,
    a.classLevel,
    a.dob,
    a.sex,
    COALESCE(a.fatherPhone, a.motherPhone, a.guardianPhone),
    a.residence,
    a.photo
FROM admission a
WHERE NOT EXISTS (
    SELECT 1 FROM students s WHERE s.matricule = a.matricule
)
AND a.matricule IS NOT NULL AND a.matricule != '';

-- ============================================
-- STEP 7: Create indexes for better performance
-- ============================================

-- Add index on admission table for faster lookups
CREATE INDEX IF NOT EXISTS idx_admission_matricule ON admission(matricule);
CREATE INDEX IF NOT EXISTS idx_admission_class ON admission(classLevel);
CREATE INDEX IF NOT EXISTS idx_admission_registration_date ON admission(registrationDate);

-- ============================================
-- STEP 8: Insert default school information if not exists
-- ============================================

INSERT INTO school_info (school_name, school_address, school_phone, school_motto)
SELECT 'CAROMA COMPREHENSIVE EDUCATION CENTER', 'BAMENDA', '237676763842', 'Excellence in Education'
WHERE NOT EXISTS (SELECT 1 FROM school_info LIMIT 1);

-- ============================================
-- STEP 9: Create default academic year if not exists
-- ============================================

INSERT INTO academic_years (year_name, start_date, end_date, is_current)
SELECT 
    CONCAT(YEAR(CURDATE()), '/', YEAR(CURDATE()) + 1),
    DATE(CONCAT(YEAR(CURDATE()), '-09-01')),
    DATE(CONCAT(YEAR(CURDATE()) + 1, '-07-31')),
    TRUE
WHERE NOT EXISTS (SELECT 1 FROM academic_years WHERE is_current = TRUE);

-- ============================================
-- COMPLETION MESSAGE
-- ============================================

SELECT 'Database consolidation completed successfully!' AS Status,
       (SELECT COUNT(*) FROM admission) AS total_admission_records,
       (SELECT COUNT(*) FROM students) AS total_student_records,
       (SELECT COUNT(*) FROM admission WHERE matricule IS NOT NULL) AS records_with_matricule;
