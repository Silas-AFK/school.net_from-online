<?php
$zip = new ZipArchive();
$zip_path = __DIR__ . "/../exports/test.zip";

echo "<pre>";
echo "Trying to create ZIP at: $zip_path\n";

if ($zip->open($zip_path, ZipArchive::CREATE) !== TRUE) {
    echo "❌ Failed to create ZIP file.\n";

    // Check folder existence
    $folder = dirname($zip_path);
    if (!is_dir($folder)) {
        echo "⚠️ Folder does not exist: $folder\n";
    } else {
        echo "✅ Folder exists: $folder\n";

        // Check write permission
        if (is_writable($folder)) {
            echo "✅ Folder is writable.\n";
        } else {
            echo "❌ Folder is NOT writable.\n";
        }
    }
    exit;
}

echo "✅ ZIP file created successfully.\n";
$zip->addFromString("test.txt", "This is a test file.");
$zip->close();
echo "✅ ZIP closed and saved.\n";
echo "</pre>";
