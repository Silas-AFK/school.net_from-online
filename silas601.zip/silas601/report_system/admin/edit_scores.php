<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';
requireAnyRole(['admin', 'teacher']);

$classes = $conn->query("SELECT id, name FROM classes ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
$subjects = $conn->query("SELECT id, name FROM subjects ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);

$success = '';
$error = '';

// Handle score update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_scores'])) {
    $subject_id = $_POST['subject_id'];
    $term = $_POST['term'];
    $seq1_scores = $_POST['seq1'] ?? [];
    $seq2_scores = $_POST['seq2'] ?? [];

    try {
        $conn->beginTransaction();
        
        foreach ($seq1_scores as $student_id => $seq1_raw) {
            $seq2_raw = $seq2_scores[$student_id] ?? '0';

            // Cast to numeric values to avoid TypeError
            $seq1 = is_numeric($seq1_raw) ? (float)$seq1_raw : 0;
            $seq2 = is_numeric($seq2_raw) ? (float)$seq2_raw : 0;

            $average = ($seq1 + $seq2) / 2;
            list($grade, $remark) = getGradeAndRemark($average);
            
            $stmt = $conn->prepare("
                UPDATE scores 
                SET seq1 = ?, seq2 = ?, grade = ?, remark = ?
                WHERE student_id = ? AND subject_id = ? AND term = ?
            ");
            $stmt->execute([$seq1, $seq2, $grade, $remark, $student_id, $subject_id, $term]);
        }
        
        $conn->commit();
        $success = '✅ Scores updated successfully!';
    } catch (PDOException $e) {
        $conn->rollBack();
        error_log('Score update error: ' . $e->getMessage());
        $error = '❌ Database error: ' . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Scores</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
        }
        h2 {
            color: #333;
            margin-bottom: 30px;
            font-size: 2em;
        }
        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 500;
        }
        .alert-success {
            background: #d4edda;
            color: #155724;
            border-left: 4px solid #28a745;
        }
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border-left: 4px solid #dc3545;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }
        select, input[type="number"] {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 1em;
        }
        .btn {
            padding: 12px 30px;
            border: none;
            border-radius: 8px;
            font-size: 1em;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        .btn-primary {
            background: #667eea;
            color: white;
        }
        .btn-primary:hover {
            background: #5568d3;
            transform: translateY(-2px);
        }
        .btn-success {
            background: #28a745;
            color: white;
            margin-top: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #e0e0e0;
        }
        th {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            font-weight: 600;
        }
        tr:hover {
            background: #f8f9fa;
        }
        input[type="number"] {
            width: 100px;
            padding: 8px;
        }
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #667eea;
            text-decoration: none;
            font-weight: 600;
        }
        .back-link:hover {
            color: #5568d3;
        }
    </style>
</head>
<body>
<div class="container">
    <a href="<?= getDashboardUrl() ?>" class="back-link">← Back to Dashboard</a>
    <h2>✏️ Edit Scores</h2>

    <?php if ($success): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="GET">
        <div class="form-group">
            <label>Select Class:</label>
            <select name="class_id" required>
                <option value="">-- Choose Class --</option>
                <?php foreach ($classes as $class): ?>
                    <option value="<?= $class['id'] ?>" <?= ($_GET['class_id'] ?? '') == $class['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($class['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label>Select Subject:</label>
            <select name="subject_id" required>
                <option value="">-- Choose Subject --</option>
                <?php foreach ($subjects as $subject): ?>
                    <option value="<?= $subject['id'] ?>" <?= ($_GET['subject_id'] ?? '') == $subject['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($subject['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label>Select Term:</label>
            <select name="term" required>
                <option value="">-- Choose Term --</option>
                <option value="1st" <?= ($_GET['term'] ?? '') == '1st' ? 'selected' : '' ?>>1st Term</option>
                <option value="2nd" <?= ($_GET['term'] ?? '') == '2nd' ? 'selected' : '' ?>>2nd Term</option>
                <option value="3rd" <?= ($_GET['term'] ?? '') == '3rd' ? 'selected' : '' ?>>3rd Term</option>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Load Scores</button>
    </form>

<?php
if (isset($_GET['class_id'], $_GET['subject_id'], $_GET['term'])) {
    $class_id = $_GET['class_id'];
    $subject_id = $_GET['subject_id'];
    $term = $_GET['term'];

    $stmt = $conn->prepare("
        SELECT s.id, s.name, s.admission_no, sc.seq1, sc.seq2, sc.average
        FROM students s
        LEFT JOIN scores sc ON s.id = sc.student_id 
            AND sc.subject_id = ? 
            AND sc.term = ?
        WHERE s.class_id = ?
        ORDER BY s.name
    ");
    $stmt->execute([$subject_id, $term, $class_id]);
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($students):
        $seq_labels = [
            '1st' => ['Seq 1', 'Seq 2'],
            '2nd' => ['Seq 3', 'Seq 4'],
            '3rd' => ['Seq 5', 'Seq 6']
        ];
        $labels = $seq_labels[$term];
?>
    <form method="POST">
        <input type="hidden" name="subject_id" value="<?= htmlspecialchars($subject_id) ?>">
        <input type="hidden" name="term" value="<?= htmlspecialchars($term) ?>">
        
        <h3 style="margin-top: 30px; color: #333;">Edit Scores - Term <?= htmlspecialchars($term) ?></h3>
        
        <table>
            <thead>
                <tr>
                    <th>Admission No</th>
                    <th>Student Name</th>
                    <th><?= $labels[0] ?></th>
                    <th><?= $labels[1] ?></th>
                    <th>Average</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($students as $student): ?>
                    <tr>
                        <td><?= htmlspecialchars($student['admission_no']) ?></td>
                        <td><?= htmlspecialchars($student['name']) ?></td>
                        <td>
                            <input type="number" 
                                   name="seq1[<?= $student['id'] ?>]" 
                                   value="<?= $student['seq1'] ?? '' ?>" 
                                   min="0" 
                                   max="100" 
                                   step="0.01" 
                                   placeholder="0.00">
                        </td>
                        <td>
                            <input type="number" 
                                   name="seq2[<?= $student['id'] ?>]" 
                                   value="<?= $student['seq2'] ?? '' ?>" 
                                   min="0" 
                                   max="100" 
                                   step="0.01" 
                                   placeholder="0.00">
                        </td>
                        <td>
                            <strong style="color: #667eea;">
                                <?= $student['average'] !== null ? number_format($student['average'], 2) : '--' ?>
                            </strong>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        
        <button type="submit" name="update_scores" class="btn btn-success">💾 Update All Scores</button>
    </form>
<?php else: ?>
    <p style="margin-top: 20px; color: #666;">No students found in this class.</p>
<?php endif; } ?>
</div>
</body>
</html>
