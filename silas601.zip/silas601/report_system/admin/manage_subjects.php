<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
requireRole('admin');

// Handle subject creation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_subject'])) {
    $name = trim($_POST['name']);
    $coefficient = intval($_POST['coefficient']);
    $teacher_name = trim($_POST['teacher_name']);

    $stmt = $conn->prepare("INSERT INTO subjects (name, coefficient) VALUES (?, ?)");
    $stmt->execute([$name, $coefficient]);

    $subject_id = $conn->lastInsertId();

    if (!empty($teacher_name)) {
        $stmt = $conn->prepare("INSERT INTO subject_teachers (subject_id, teacher_name) VALUES (?, ?)");
        $stmt->execute([$subject_id, $teacher_name]);
    }

    $success = "✅ Subject added successfully with coefficient $coefficient!";
}

// Handle subject deletion
if (isset($_GET['delete'])) {
    $delete_id = $_GET['delete'];

    // Delete from subject_teachers first to avoid foreign key issues
    $conn->prepare("DELETE FROM subject_teachers WHERE subject_id = ?")->execute([$delete_id]);

    // Then delete the subject
    $conn->prepare("DELETE FROM subjects WHERE id = ?")->execute([$delete_id]);

    $success = "🗑️ Subject deleted successfully!";
}

// Fetch subjects
$subjects = $conn->query("
    SELECT s.*, st.teacher_name 
    FROM subjects s 
    LEFT JOIN subject_teachers st ON s.id = st.subject_id 
    ORDER BY s.name ASC
")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Manage Subjects</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; background: #f5f7fa; }
        .container { max-width: 900px; margin: auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        h2, h3 { color: #333; margin-bottom: 20px; }
        form { background: #f4f4f4; padding: 20px; margin-bottom: 30px; border-radius: 5px; }
        label { display: inline-block; width: 150px; margin: 10px 0; font-weight: bold; }
        input, select, button { padding: 8px; margin: 5px 0; border-radius: 5px; border: 1px solid #ccc; }
        button { background: #007bff; color: white; border: none; cursor: pointer; }
        button:hover { background: #0056b3; }
        .success { background: #d4edda; color: #155724; padding: 12px; border-radius: 8px; margin-bottom: 20px; border-left: 4px solid #28a745; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 12px; text-align: left; border: 1px solid #ddd; }
        th { background: #007bff; color: white; }
        tr:nth-child(even) { background: #f9f9f9; }
        .delete-link { color: #cc0000; text-decoration: none; font-weight: bold; }
        .delete-link:hover { text-decoration: underline; }
        .back-link { display: inline-block; margin-top: 20px; color: #007bff; text-decoration: none; font-weight: bold; }
        .back-link:hover { text-decoration: underline; }
    </style>
</head>
<body>
<div class="container">
    <h2>📚 Manage Subjects</h2>

    <?php if (isset($success)): ?>
        <div class="success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <form method="POST">
        <h3>Add New Subject</h3>
        <div>
            <label>Subject Name:</label>
            <input type="text" name="name" required placeholder="e.g., Mathematics">
        </div>

        <div>
            <label>Coefficient:</label>
            <input type="number" name="coefficient" min="1" max="10" value="1" required>
            <small>(Weight of subject: 1–10)</small>
        </div>

        <div>
            <label>Teacher Name:</label>
            <input type="text" name="teacher_name" placeholder="e.g., John Doe">
        </div>

        <button type="submit" name="add_subject">➕ Add Subject</button>
    </form>

    <h3>📋 Existing Subjects</h3>
    <table>
        <thead>
            <tr>
                <th>Subject Name</th>
                <th>Coefficient</th>
                <th>Teacher</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($subjects as $subject): ?>
                <tr>
                    <td><?= htmlspecialchars($subject['name']) ?></td>
                    <td><strong><?= $subject['coefficient'] ?></strong></td>
                    <td><?= htmlspecialchars($subject['teacher_name'] ?? 'Not Assigned') ?></td>
                    <td>
                        <a href="?delete=<?= $subject['id'] ?>" class="delete-link" onclick="return confirm('Are you sure you want to delete this subject?')">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <a href="dashboard.php" class="back-link">← Back to Dashboard</a>
</div>
</body>
</html>
