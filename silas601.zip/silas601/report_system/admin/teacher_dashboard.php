<?php
// samo/admin/teacher_dashboard.php
declare(strict_types=1);

require_once '../includes/auth.php';
require_once '../includes/config.php';
require_once '../includes/db.php';

requireRole('teacher');

try {
    $student_count = $conn->query("SELECT COUNT(*) FROM students")->fetchColumn();
    $class_count = $conn->query("SELECT COUNT(*) FROM classes")->fetchColumn();
    $subject_count = $conn->query("SELECT COUNT(*) FROM subjects")->fetchColumn();
} catch (PDOException $e) {
    error_log('Dashboard stats error: ' . $e->getMessage());
    $student_count = 0;
    $class_count = 0;
    $subject_count = 0;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Updated title to reflect Teacher Dashboard -->
    <title>Teacher Dashboard - Caroma</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f7fa;
            padding: 20px;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 15px;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        .header h1 {
            font-size: 2em;
            margin-bottom: 10px;
        }
        .header p {
            opacity: 0.9;
        }
        .user-info {
            float: right;
            text-align: right;
        }
        .logout-btn {
            display: inline-block;
            margin-top: 10px;
            padding: 8px 20px;
            background: rgba(255,255,255,0.2);
            color: white;
            text-decoration: none;
            border-radius: 20px;
            font-size: 0.9em;
            transition: background 0.3s;
        }
        .logout-btn:hover {
            background: rgba(255,255,255,0.3);
        }
        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
            transition: transform 0.3s, box-shadow 0.3s;
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0,0,0,0.15);
        }
        .card h3 {
            color: #333;
            font-size: 1.3em;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .card p {
            color: #666;
            margin-bottom: 15px;
            font-size: 1.1em;
        }
        .stat-number {
            font-size: 2em;
            font-weight: bold;
            color: #667eea;
        }
        .button {
            display: inline-block;
            margin: 5px 5px 5px 0;
            padding: 10px 20px;
            background: #667eea;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-size: 0.9em;
            transition: background 0.3s;
        }
        .button:hover {
            background: #5568d3;
        }
        .clearfix::after {
            content: "";
            display: table;
            clear: both;
        }
    </style>
</head>
<body>
    <div class="header clearfix">
        <div>
            <h1>🎓 <?php echo htmlspecialchars($school_name); ?></h1>
            <p><strong>Principal:</strong> <?php echo htmlspecialchars($principal_name); ?></p>
        </div>
        <div class="user-info">
            <p>Welcome, <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong></p>
            <p>Role: <?php echo htmlspecialchars($_SESSION['role'] ?? 'User'); ?></p>
            <p>Sat,Oct 11,2025</p>
            <a href="../public/logout.php" class="logout-btn">Logout</a>
        </div>
    </div>

    <div class="grid">
        <div class="card">
            <h3>📝 Scores</h3>
            <a href="enter_scores.php" class="button">Enter Scores</a>
            <a href="edit_scores.php" class="button">Edit Scores</a>
        </div>

        <div class="card">
            <h3>🔍 Search & Analytics</h3>
            <a href="search_student.php" class="button">Search Student</a>
            <a href="view_students.php" class="button">View All Students</a>
        </div>

        <div class="card">
            <h3>📊 Class Analytics</h3>
            <p>Number of Classes: <span class="stat-number"><?php echo $class_count; ?></span></p>
            <a href="" class="button">View Class Details</a>
        </div>

        <div class="card">
            <h3>📚 Subject Overview</h3>
            <p>Number of Subjects: <span class="stat-number"><?php echo $subject_count; ?></span></p>
            <a href="" class="button">View Subject Details</a>
        </div>
    </div>
</body>
</html>
