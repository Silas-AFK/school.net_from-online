<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';
requireRole('admin');

$classes = $conn->query("SELECT id, name FROM classes ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);

$message = '';
$class_id = $_GET['class_id'] ?? null;
$term = $_GET['term'] ?? null;

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $student_id = $_POST['student_id'];
    $term = $_POST['term'];
    $hours_absence = $_POST['hours_absence'] ?? 0;
    $hours_punishment = $_POST['hours_punishment'] ?? 0;
    $days_suspension = $_POST['days_suspension'] ?? 0;
    $warning = $_POST['warning'] ?? 'No';
    $dismissed = $_POST['dismissed'] ?? 'no';
    
    $stmt = $conn->prepare("
        INSERT INTO report_summary 
        (student_id, term, hours_absence, hours_punishment, days_suspension, warning, dismissed)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
            hours_absence = VALUES(hours_absence),
            hours_punishment = VALUES(hours_punishment),
            days_suspension = VALUES(days_suspension),
            warning = VALUES(warning),
            dismissed = VALUES(dismissed)
    ");
    
    if ($stmt->execute([$student_id, $term, $hours_absence, $hours_punishment, $days_suspension, $warning, $dismissed])) {
        $message = '<div style="padding: 15px; background: #d4edda; color: #155724; border-radius: 8px; margin-bottom: 20px;">✓ Report summary updated successfully!</div>';
    } else {
        $message = '<div style="padding: 15px; background: #f8d7da; color: #721c24; border-radius: 8px; margin-bottom: 20px;">✗ Error updating report summary.</div>';
    }
}

$students = [];
if ($class_id && $term) {
    $students_stmt = $conn->prepare("
        SELECT s.id, s.name, s.admission_no,
               rs.hours_absence, rs.hours_punishment, rs.days_suspension, 
               rs.warning, rs.dismissed
        FROM students s
        LEFT JOIN report_summary rs ON s.id = rs.student_id AND rs.term = ?
        WHERE s.class_id = ?
        ORDER BY s.name
    ");
    $students_stmt->execute([$term, $class_id]);
    $students = $students_stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Report Summary</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .container {
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
        }
        h2 {
            color: #333;
            margin-bottom: 30px;
            font-size: 2em;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }
        select, input {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 1em;
        }
        .btn {
            padding: 12px 30px;
            border: none;
            border-radius: 8px;
            font-size: 1em;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
        }
        .btn-primary {
            background: #667eea;
            color: white;
        }
        .btn-primary:hover {
            background: #5568d3;
            transform: translateY(-2px);
        }
        .btn-success {
            background: #28a745;
            color: white;
            padding: 8px 16px;
            font-size: 0.9em;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #e0e0e0;
        }
        th {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            font-weight: 600;
            font-size: 0.9em;
        }
        tr:hover {
            background: #f8f9fa;
        }
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #667eea;
            text-decoration: none;
            font-weight: 600;
        }
        .form-inline {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
        }
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
        }
        .modal-content {
            background: white;
            margin: 5% auto;
            padding: 30px;
            border-radius: 15px;
            width: 90%;
            max-width: 600px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.3);
        }
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }
        .close:hover {
            color: #000;
        }
    </style>
</head>
<body>
<div class="container">
    <a href="dashboard.php" class="back-link">← Back to Dashboard</a>
    <h2>📝 Edit Report Summary & Discipline</h2>

    <?= $message ?>

    <form method="GET">
        <div class="form-inline">
            <div class="form-group">
                <label>Select Class:</label>
                <select name="class_id" required>
                    <option value="">-- Choose Class --</option>
                    <?php foreach ($classes as $class): ?>
                        <option value="<?= $class['id'] ?>" <?= $class_id == $class['id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($class['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label>Select Term:</label>
                <select name="term" required>
                    <option value="">-- Choose Term --</option>
                    <option value="1st" <?= $term == '1st' ? 'selected' : '' ?>>1st Term</option>
                    <option value="2nd" <?= $term == '2nd' ? 'selected' : '' ?>>2nd Term</option>
                    <option value="3rd" <?= $term == '3rd' ? 'selected' : '' ?>>3rd Term</option>
                </select>
            </div>

            <div class="form-group" style="display: flex; align-items: flex-end;">
                <button type="submit" class="btn btn-primary">Load Students</button>
            </div>
        </div>
    </form>

    <?php if ($students): ?>
        <h3 style="margin-top: 40px; color: #333;">Students in Class - Term <?= htmlspecialchars($term) ?></h3>
        <table>
            <thead>
                <tr>
                    <th>Admission No</th>
                    <th>Student Name</th>
                    <th>Absence (hrs)</th>
                    <th>Punishment (hrs)</th>
                    <th>Suspension (days)</th>
                    <th>Warning</th>
                    <th>Dismissed</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($students as $student): ?>
                    <tr>
                        <td><?= htmlspecialchars($student['admission_no']) ?></td>
                        <td><?= htmlspecialchars($student['name']) ?></td>
                        <td><?= $student['hours_absence'] ?? 0 ?></td>
                        <td><?= $student['hours_punishment'] ?? 0 ?></td>
                        <td><?= $student['days_suspension'] ?? 0 ?></td>
                        <td><?= ucfirst($student['warning'] ?? 'No') ?></td>
                        <td><?= $student['dismissed'] ?? 'no' ?></td>
                        <td>
                            <button class="btn btn-success" onclick="openEditModal(<?= htmlspecialchars(json_encode($student)) ?>, '<?= $term ?>')">
                                ✏️ Edit
                            </button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php elseif ($class_id && $term): ?>
        <p style="margin-top: 20px; color: #666;">No students found in this class.</p>
    <?php endif; ?>
</div>

<!-- Edit Modal -->
<div id="editModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeModal()">&times;</span>
        <h3 style="margin-bottom: 20px; color: #333;">Edit Report Summary</h3>
        <form method="POST">
            <input type="hidden" name="student_id" id="edit_student_id">
            <input type="hidden" name="term" id="edit_term">
            
            <div class="form-group">
                <label>Student Name:</label>
                <input type="text" id="edit_student_name" readonly style="background: #f0f0f0;">
            </div>

            <div class="form-inline">
                <div class="form-group">
                    <label>Hours of Absence:</label>
                    <input type="number" name="hours_absence" id="edit_hours_absence" min="0" value="0">
                </div>

                <div class="form-group">
                    <label>Hours of Punishment:</label>
                    <input type="number" name="hours_punishment" id="edit_hours_punishment" min="0" value="0">
                </div>
            </div>

            <div class="form-inline">
                <div class="form-group">
                    <label>Days of Suspension:</label>
                    <input type="number" name="days_suspension" id="edit_days_suspension" min="0" value="0">
                </div>

                <div class="form-group">
                    <label>Warning:</label>
                    <select name="warning" id="edit_warning">
                        <option value="No">No</option>
                        <option value="Yes">Yes</option>
                    </select>
                </div>
            </div>

            <div class="form-inline">
                <div class="form-group">
                    <label>Dismissed:</label>
                    <select name="dismissed" id="edit_dismissed">
                        <option value="no">No</option>
                        <option value="yes">Yes</option>
                    </select>
                </div>
            </div>

            <div style="margin-top: 20px;">
                <button type="submit" class="btn btn-primary">💾 Save Changes</button>
                <button type="button" class="btn btn-secondary" onclick="closeModal()" style="background: #6c757d; color: white; margin-left: 10px;">Cancel</button>
            </div>
        </form>
    </div>
</div>

<script>
function openEditModal(student, term) {
    document.getElementById('edit_student_id').value = student.id;
    document.getElementById('edit_term').value = term;
    document.getElementById('edit_student_name').value = student.name;
    document.getElementById('edit_hours_absence').value = student.hours_absence || 0;
    document.getElementById('edit_hours_punishment').value = student.hours_punishment || 0;
    document.getElementById('edit_days_suspension').value = student.days_suspension || 0;
    document.getElementById('edit_warning').value = student.warning || 'No';
    document.getElementById('edit_dismissed').value = student.dismissed || 'no';
    
    document.getElementById('editModal').style.display = 'block';
}

function closeModal() {
    document.getElementById('editModal').style.display = 'none';
}

window.onclick = function(event) {
    const modal = document.getElementById('editModal');
    if (event.target == modal) {
        closeModal();
    }
}
</script>
</body>
</html>
