<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';
requireRole('admin');

$classes = $conn->query("SELECT id, name FROM classes")->fetchAll(PDO::FETCH_ASSOC);
$terms = ['1st', '2nd', '3rd'];

$ranking = [];
if (isset($_GET['class_id'], $_GET['term'])) {
    $class_id = $_GET['class_id'];
    $term = $_GET['term'];
    
    $stmt = $conn->prepare("
        SELECT DISTINCT
            s.id,
            s.name, 
            s.admission_no,
            SUM(sc.average * sub.coefficient) / SUM(sub.coefficient) as weighted_average,
            SUM(sc.average * sub.coefficient) as total_weighted,
            rs.position
        FROM students s
        JOIN scores sc ON s.id = sc.student_id
        JOIN subjects sub ON sc.subject_id = sub.id
        LEFT JOIN report_summary rs ON s.id = rs.student_id AND rs.term = ?
        WHERE s.class_id = ? AND sc.term = ?
        GROUP BY s.id, s.name, s.admission_no, rs.position
        ORDER BY weighted_average DESC
    ");
    $stmt->execute([$term, $class_id, $term]);
    $ranking = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $position = 1;
    foreach ($ranking as &$row) {
        $row['position'] = ordinal($position);
        $position++;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Class Ranking</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body { font-family: Arial, sans-serif; background: #f5f7fa; padding: 20px; }
        .container { max-width: 900px; margin: auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        h2 { color: #333; margin-bottom: 20px; }
        label { display: block; margin: 10px 0 5px; font-weight: bold; }
        select, button { padding: 10px; margin-bottom: 15px; width: 100%; border-radius: 5px; border: 1px solid #ccc; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 12px; border: 1px solid #ddd; text-align: left; }
        th { background: #0077cc; color: white; }
        tr:nth-child(even) { background: #f9f9f9; }
        .back-link { display: inline-block; margin-bottom: 20px; color: #0077cc; text-decoration: none; font-weight: bold; }
        .back-link:hover { text-decoration: underline; }
        .gold { background: #ffd700 !important; }
        .silver { background: #c0c0c0 !important; }
        .bronze { background: #cd7f32 !important; }
    </style>
</head>
<body>
<div class="container">
    <a href="dashboard.php" class="back-link">← Back to Dashboard</a>
    <h2>📈 Class Ranking</h2>

    <form method="GET">
        <label>Class:</label>
        <select name="class_id" required>
            <option value="">-- Select Class --</option>
            <?php foreach ($classes as $class): ?>
                <option value="<?= $class['id'] ?>" <?= ($_GET['class_id'] ?? '') == $class['id'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($class['name']) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label>Term:</label>
        <select name="term" required>
            <option value="">-- Select Term --</option>
            <?php foreach ($terms as $t): ?>
                <option value="<?= $t ?>" <?= ($_GET['term'] ?? '') == $t ? 'selected' : '' ?>>
                    <?= $t ?> Term
                </option>
            <?php endforeach; ?>
        </select>

        <button type="submit">Show Ranking</button>
    </form>

    <?php if (!empty($ranking)): ?>
        <table>
            <tr>
                <th>Position</th>
                <th>Admission No</th>
                <th>Student Name</th>
                <th>Weighted Average</th>
                <th>Total Weighted Score</th>
            </tr>
            <?php foreach ($ranking as $index => $row): ?>
                <tr class="<?= $index === 0 ? 'gold' : ($index === 1 ? 'silver' : ($index === 2 ? 'bronze' : '')) ?>">
                    <td><strong><?= $row['position'] ?></strong></td>
                    <td><?= htmlspecialchars($row['admission_no']) ?></td>
                    <td><?= htmlspecialchars($row['name']) ?></td>
                    <td><?= number_format($row['weighted_average'], 2) ?></td>
                    <td><?= number_format($row['total_weighted'] ?? 0, 2) ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php elseif (isset($_GET['class_id'])): ?>
        <p style="text-align: center; color: #666; margin-top: 20px;">No ranking data available for this class and term.</p>
    <?php endif; ?>
</div>
</body>
</html>
