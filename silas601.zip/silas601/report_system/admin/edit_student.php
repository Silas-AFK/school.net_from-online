<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
requireRole('admin');

if (!isset($_GET['id'])) {
    echo "<p style='color:red;'>No student selected.</p>";
    exit;
}

$id = $_GET['id'];
$student = $conn->prepare("SELECT * FROM students WHERE id = ?");
$student->execute([$id]);
$student = $student->fetch(PDO::FETCH_ASSOC);

$classes = $conn->query("SELECT id, name FROM classes")->fetchAll(PDO::FETCH_ASSOC);

$success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name       = $_POST['name'];
    $dob        = $_POST['dob'];
    $sex        = $_POST['sex'];
    $place      = $_POST['place_of_birth'];
    $admission  = $_POST['admission_no'];
    $class_id   = $_POST['class_id'];

    $stmt = $conn->prepare("UPDATE students SET name = ?, dob = ?, sex = ?, place_of_birth = ?, admission_no = ?, class_id = ? WHERE id = ?");
    $stmt->execute([$name, $dob, $sex, $place, $admission, $class_id, $id]);

    $success = "✅ Student updated successfully!";
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Student</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, sans-serif;
            background: #f5f7fa;
            padding: 20px;
        }
        .container {
            max-width: 700px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h2 {
            color: #333;
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin: 10px 0 5px;
            font-weight: bold;
        }
        input[type="text"], input[type="date"], select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 14px;
        }
        button {
            background: #0077cc;
            color: white;
            padding: 10px 25px;
            border: none;
            border-radius: 5px;
            font-weight: bold;
            cursor: pointer;
        }
        button:hover {
            background: #005fa3;
        }
        .success {
            background: #d4edda;
            color: #155724;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #28a745;
        }
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #0077cc;
            text-decoration: none;
            font-weight: bold;
        }
        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<div class="container">
    <a href="search_student.php" class="back-link">← Back to Search</a>
    <h2>📝 Edit Student Info</h2>

    <?php if ($success): ?>
        <div class="success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <form method="POST">
        <label>Name:</label>
        <input type="text" name="name" value="<?= htmlspecialchars($student['name']) ?>" required>

        <label>Date of Birth:</label>
        <input type="date" name="dob" value="<?= htmlspecialchars($student['dob']) ?>" required>

        <label>Sex:</label>
        <select name="sex" required>
            <option value="M" <?= $student['sex'] == 'M' ? 'selected' : '' ?>>Male</option>
            <option value="F" <?= $student['sex'] == 'F' ? 'selected' : '' ?>>Female</option>
        </select>

        <label>Place of Birth:</label>
        <input type="text" name="place_of_birth" value="<?= htmlspecialchars($student['place_of_birth']) ?>" required>

        <label>Admission No:</label>
        <input type="text" name="admission_no" value="<?= htmlspecialchars($student['admission_no']) ?>" required>

        <label>Class:</label>
        <select name="class_id" required>
            <?php foreach ($classes as $class): ?>
                <option value="<?= $class['id'] ?>" <?= $student['class_id'] == $class['id'] ? 'selected' : '' ?>>
                    <?= htmlspecialchars($class['name']) ?>
                </option>
            <?php endforeach; ?>
        </select>

        <button type="submit">Update Student</button>
    </form>
</div>
</body>
</html>
