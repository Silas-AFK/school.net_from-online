<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
requireRole('admin');

$success = '';
$error = '';

// Fetch classes
$classes = $conn->query("SELECT id, name FROM classes ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);

// Handle remarks and discipline submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $term = $_POST['term'];
    $remarks = $_POST['remarks'] ?? [];
    $hours_absence = $_POST['hours_absence'] ?? [];
    $hours_punishment = $_POST['hours_punishment'] ?? [];
    $days_suspension = $_POST['days_suspension'] ?? [];
    $warning = $_POST['warning'] ?? [];
    $dismissed = $_POST['dismissed'] ?? [];

    try {
        $conn->beginTransaction();
        
        foreach ($remarks as $student_id => $remark_text) {
            $stmt = $conn->prepare("
                INSERT INTO report_summary 
                (student_id, term, remarks, hours_absence, hours_punishment, days_suspension, warning, dismissed)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE
                    remarks = VALUES(remarks),
                    hours_absence = VALUES(hours_absence),
                    hours_punishment = VALUES(hours_punishment),
                    days_suspension = VALUES(days_suspension),
                    warning = VALUES(warning),
                    dismissed = VALUES(dismissed)
            ");
            $stmt->execute([
                $student_id,
                $term,
                $remark_text,
                $hours_absence[$student_id] ?? 0,
                $hours_punishment[$student_id] ?? 0,
                $days_suspension[$student_id] ?? 0,
                $warning[$student_id] ?? 'No',
                $dismissed[$student_id] ?? 'no'
            ]);
        }
        
        $conn->commit();
        $success = "✅ Remarks and discipline data saved successfully!";
    } catch (PDOException $e) {
        $conn->rollBack();
        error_log('Remarks save error: ' . $e->getMessage());
        $error = "❌ Error saving data: " . $e->getMessage();
    }
}

// Load students if class and term are selected
$students = [];
if (isset($_GET['class_id'], $_GET['term'])) {
    $class_id = $_GET['class_id'];
    $term = $_GET['term'];

    $stmt = $conn->prepare("
        SELECT s.id, s.name, s.admission_no,
               rs.remarks, rs.hours_absence, rs.hours_punishment, 
               rs.days_suspension, rs.warning, rs.dismissed
        FROM students s
        LEFT JOIN report_summary rs ON s.id = rs.student_id AND rs.term = ?
        WHERE s.class_id = ?
        ORDER BY s.name
    ");
    $stmt->execute([$term, $class_id]);
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enter Remarks & Discipline</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .container {
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
        }
        h2 {
            color: #333;
            margin-bottom: 10px;
            font-size: 2em;
        }
        .subtitle {
            color: #666;
            margin-bottom: 30px;
        }
        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 500;
        }
        .alert-success {
            background: #d4edda;
            color: #155724;
            border-left: 4px solid #28a745;
        }
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border-left: 4px solid #dc3545;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }
        select, textarea, input[type="number"] {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 1em;
        }
        .btn {
            padding: 12px 30px;
            border: none;
            border-radius: 8px;
            font-size: 1em;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        .btn-primary {
            background: #667eea;
            color: white;
        }
        .btn-primary:hover {
            background: #5568d3;
            transform: translateY(-2px);
        }
        .btn-success {
            background: #28a745;
            color: white;
            margin-top: 20px;
        }
        .btn-success:hover {
            background: #218838;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            overflow-x: auto;
            display: block;
        }
        thead, tbody {
            display: table;
            width: 100%;
            table-layout: fixed;
        }
        th, td {
            padding: 12px 8px;
            text-align: left;
            border-bottom: 1px solid #e0e0e0;
        }
        th {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            font-weight: 600;
            font-size: 0.85em;
        }
        tr:hover {
            background: #f8f9fa;
        }
        textarea {
            min-height: 60px;
            resize: vertical;
        }
        input[type="number"] {
            width: 70px;
            padding: 6px;
        }
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #667eea;
            text-decoration: none;
            font-weight: 600;
        }
        .back-link:hover {
            color: #5568d3;
        }
    </style>
</head>
<body>
<div class="container">
    <a href="dashboard.php" class="back-link">← Back to Dashboard</a>
    <h2>🖋️ Enter Remarks & Discipline Data</h2>
    <p class="subtitle">Add teacher remarks and discipline information for report cards</p>

    <?php if ($success): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="GET">
        <div class="form-group">
            <label>Select Class:</label>
            <select name="class_id" required>
                <option value="">-- Choose Class --</option>
                <?php foreach ($classes as $class): ?>
                    <option value="<?= $class['id'] ?>" <?= isset($_GET['class_id']) && $_GET['class_id'] == $class['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($class['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label>Select Term:</label>
            <select name="term" required>
                <option value="">-- Choose Term --</option>
                <option value="1st" <?= isset($_GET['term']) && $_GET['term'] == '1st' ? 'selected' : '' ?>>1st Term</option>
                <option value="2nd" <?= isset($_GET['term']) && $_GET['term'] == '2nd' ? 'selected' : '' ?>>2nd Term</option>
                <option value="3rd" <?= isset($_GET['term']) && $_GET['term'] == '3rd' ? 'selected' : '' ?>>3rd Term</option>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Load Students</button>
    </form>

    <?php if (!empty($students)): ?>
        <form method="POST">
            <input type="hidden" name="term" value="<?= htmlspecialchars($term) ?>">
            <table>
                <thead>
                    <tr>
                        <th style="width: 15%;">Student Name</th>
                        <th style="width: 30%;">Remarks</th>
                        <th style="width: 10%;">Hours Absence</th>
                        <th style="width: 10%;">Hours Punishment</th>
                        <th style="width: 10%;">Days Suspension</th>
                        <th style="width: 10%;">Warning</th>
                        <th style="width: 10%;">Dismissed</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($students as $student): ?>
                        <tr>
                            <td><strong><?= htmlspecialchars($student['name']) ?></strong></td>
                            <td>
                                <textarea name="remarks[<?= $student['id'] ?>]" rows="2" placeholder="Enter teacher remark..."><?= htmlspecialchars($student['remarks'] ?? '') ?></textarea>
                            </td>
                            <td>
                                <input type="number" name="hours_absence[<?= $student['id'] ?>]" min="0" value="<?= $student['hours_absence'] ?? 0 ?>">
                            </td>
                            <td>
                                <input type="number" name="hours_punishment[<?= $student['id'] ?>]" min="0" value="<?= $student['hours_punishment'] ?? 0 ?>">
                            </td>
                            <td>
                                <input type="number" name="days_suspension[<?= $student['id'] ?>]" min="0" value="<?= $student['days_suspension'] ?? 0 ?>">
                            </td>
                            <td>
                                <select name="warning[<?= $student['id'] ?>]">
                                    <option value="No" <?= ($student['warning'] ?? 'No') == 'No' ? 'selected' : '' ?>>No</option>
                                    <option value="Yes" <?= ($student['warning'] ?? 'No') == 'Yes' ? 'selected' : '' ?>>Yes</option>
                                </select>
                            </td>
                            <td>
                                <select name="dismissed[<?= $student['id'] ?>]">
                                    <option value="no" <?= ($student['dismissed'] ?? 'no') == 'no' ? 'selected' : '' ?>>no</option>
                                    <option value="yes" <?= ($student['dismissed'] ?? 'no') == 'yes' ? 'selected' : '' ?>>yes</option>
                                </select>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <button type="submit" class="btn btn-success">💾 Save All Data</button>
        </form>
    <?php endif; ?>
</div>
</body>
</html>
