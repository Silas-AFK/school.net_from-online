<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
requireRole('admin');

// Handle class creation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add'])) {
    $name = trim($_POST['name']);
    $year = $_POST['academic_year'];
    $term = $_POST['term'];

    $stmt = $conn->prepare("INSERT INTO classes (name, academic_year, term) VALUES (?, ?, ?)");
    $stmt->execute([$name, $year, $term]);
    $success = "✅ Class added successfully!";
}

// Handle class deletion
if (isset($_GET['delete'])) {
    $delete_id = $_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM classes WHERE id = ?");
    $stmt->execute([$delete_id]);
    $success = "🗑️ Class deleted successfully!";
}

// Fetch all classes
$classes = $conn->query("SELECT * FROM classes ORDER BY academic_year DESC, name ASC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Manage Classes</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f7fa;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h2, h3 {
            color: #333;
            margin-bottom: 20px;
        }
        .success {
            background: #d4edda;
            color: #155724;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #28a745;
        }
        label {
            display: block;
            margin: 10px 0 5px;
            font-weight: bold;
        }
        input, select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        button {
            background: #0077cc;
            color: white;
            padding: 10px 25px;
            border: none;
            border-radius: 5px;
            font-weight: bold;
            cursor: pointer;
        }
        button:hover {
            background: #005fa3;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background: #0077cc;
            color: white;
        }
        tr:nth-child(even) {
            background: #f9f9f9;
        }
        .delete-link {
            color: #cc0000;
            text-decoration: none;
            font-weight: bold;
        }
        .delete-link:hover {
            text-decoration: underline;
        }
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #0077cc;
            text-decoration: none;
        }
        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<div class="container">
    <a href="dashboard.php" class="back-link">← Back to Dashboard</a>
    <h2>📘 Add New Class</h2>

    <?php if (isset($success)): ?>
        <div class="success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>

    <form method="POST">
        <label>Class Name:</label>
        <input type="text" name="name" required>

        <label>Academic Year:</label>
        <input type="text" name="academic_year" placeholder="2025-2026" required>

        <label>Term:</label>
        <select name="term" required>
            <option value="1st">1st</option>
            <option value="2nd">2nd</option>
            <option value="3rd">3rd</option>
        </select>

        <button type="submit" name="add">Add Class</button>
    </form>

    <h3>📋 Existing Classes</h3>
    <table>
        <tr>
            <th>Class Name</th>
            <th>Academic Year</th>
            <th>Term</th>
            <th>Action</th>
        </tr>
        <?php foreach ($classes as $class): ?>
            <tr>
                <td><?= htmlspecialchars($class['name']) ?></td>
                <td><?= htmlspecialchars($class['academic_year']) ?></td>
                <td><?= htmlspecialchars($class['term']) ?></td>
                <td>
                    <a href="?delete=<?= $class['id'] ?>" class="delete-link" onclick="return confirm('Are you sure you want to delete this class?')">Delete</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
</div>
</body>
</html>
