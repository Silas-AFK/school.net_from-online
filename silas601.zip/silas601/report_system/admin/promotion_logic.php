<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
requireRole('admin');

if (!isset($_GET['class_id']) || !isset($_GET['term'])) {
    echo "<p style='color:red;'>Missing class or term.</p>";
    exit;
}

$class_id = $_GET['class_id'];
$term = $_GET['term'];

$students = $conn->prepare("SELECT id FROM students WHERE class_id = ?");
$students->execute([$class_id]);
$students = $students->fetchAll(PDO::FETCH_COLUMN);

foreach ($students as $student_id) {
    $summary = $conn->prepare("SELECT average FROM report_summary WHERE student_id = ? AND term = ?");
    $summary->execute([$student_id, $term]);
    $average = $summary->fetchColumn();

    // Promotion logic: average >= 10 to pass/promote
    $promoted = ($average >= 10) ? 1 : 0;
    
    // For 3rd term, this determines promotion to next class
    // For 1st and 2nd term, this just indicates pass/fail
    $status = ($term === '3rd') ? ($promoted ? 'Promoted' : 'Repeat') : ($promoted ? 'Pass' : 'Fail');

    $stmt = $conn->prepare("UPDATE report_summary SET promoted = ?, status = ? WHERE student_id = ? AND term = ?");
    $stmt->execute([$promoted, $status, $student_id, $term]);
}

echo "<p style='color:green;'>✅ Promotion logic applied for class $class_id - $term term.</p>";
echo "<p>Students with average ≥ 10: <strong>Pass/Promoted</strong></p>";
echo "<p>Students with average < 10: <strong>Fail/Repeat</strong></p>";
echo "<a href='dashboard.php'>Back to Dashboard</a>";
?>
