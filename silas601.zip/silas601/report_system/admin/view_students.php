<?php
// samo/admin/view_students.php
require_once '../includes/db.php';
require_once '../includes/auth.php';
requireAnyRole(['admin', 'teacher']);

$classes = $conn->query("SELECT id, name FROM classes")->fetchAll(PDO::FETCH_ASSOC);

$students = [];
$class_name = '';
if (isset($_GET['class_id']) && $_GET['class_id'] !== '') {
    $class_id = $_GET['class_id'];
    $class_stmt = $conn->prepare("SELECT name FROM classes WHERE id = ?");
    $class_stmt->execute([$class_id]);
    $class_name = $class_stmt->fetchColumn();
    
    $stmt = $conn->prepare("SELECT * FROM students WHERE class_id = ?");
    $stmt->execute([$class_id]);
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Students by Class</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f4f8;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 900px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h2, h3 {
            color: #003366;
            margin-bottom: 20px;
        }
        form {
            margin-bottom: 30px;
        }
        label {
            font-weight: bold;
            margin-right: 10px;
        }
        select {
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 1em;
        }
        button {
            padding: 10px 20px;
            background-color: #0077cc;
            color: white;
            border: none;
            border-radius: 5px;
            font-weight: bold;
            cursor: pointer;
            margin-left: 10px;
        }
        button:hover {
            background-color: #005fa3;
        }
        .export-btn {
            background-color: #28a745;
            margin-left: 10px;
        }
        .export-btn:hover {
            background-color: #218838;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background-color: #0077cc;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .back-button {
            display: inline-block;
            margin-top: 30px;
            text-decoration: none;
            color: #0077cc;
            font-weight: bold;
        }
        .back-button:hover {
            text-decoration: underline;
        }
        .action-links a {
            margin-right: 10px;
            text-decoration: none;
            font-weight: bold;
        }
        .action-links a.edit {
            color: #0077cc;
        }
        .action-links a.delete {
            color: #cc0000;
        }
        .button-container {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>View Students by Class</h2>
        <form method="GET">
            <label for="class_id">Select Class:</label>
            <select name="class_id" id="class_id" required>
                <option value="">-- Choose Class --</option>
                <?php foreach ($classes as $class): ?>
                    <option value="<?= $class['id'] ?>" <?= isset($_GET['class_id']) && $_GET['class_id'] == $class['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($class['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <button type="submit">View</button>
        </form>

        <?php if (!empty($students)): ?>
            <h3>Students in Selected Class</h3>
            
            <?php if (getCurrentUserRole() === 'admin'): ?>
            <div class="button-container">
                <form method="POST" action="export_class_list.php" style="display: inline;">
                    <input type="hidden" name="class_id" value="<?= $class_id ?>">
                    <button type="submit" class="export-btn">📄 Export Class List as PDF</button>
                </form>
            </div>
            <?php endif; ?>
            
            <table>
                <tr>
                    <th>Name</th>
                    <th>Admission No</th>
                    <th>Sex</th>
                    <th>DOB</th>
                    <?php if (getCurrentUserRole() === 'admin'): ?>
                    <th>Actions</th>
                    <?php endif; ?>
                </tr>
                <?php foreach ($students as $student): ?>
                    <tr>
                        <td><?= htmlspecialchars($student['name']) ?></td>
                        <td><?= htmlspecialchars($student['admission_no']) ?></td>
                        <td><?= htmlspecialchars($student['sex']) ?></td>
                        <td><?= htmlspecialchars($student['dob']) ?></td>
                        <?php if (getCurrentUserRole() === 'admin'): ?>
                        <td class="action-links">
                            <a href="edit_student.php?id=<?= $student['id'] ?>" class="edit">Edit</a>
                            <a href="delete_student.php?id=<?= $student['id'] ?>&class_id=<?= $class_id ?>"
                               class="delete"
                               onclick="return confirm('Are you sure you want to delete this student?')">Delete</a>
                        </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php elseif (isset($_GET['class_id'])): ?>
            <p>No students found in this class.</p>
        <?php endif; ?>

        <a href="<?= getDashboardUrl() ?>" class="back-button">← Back to Dashboard</a>
    </div>
</body>
</html>
