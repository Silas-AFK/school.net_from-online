<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';
requireRole('admin');

if (!isset($_GET['class_id']) || !isset($_GET['term'])) {
    echo "<p style='color:red;'>Missing class or term.</p>";
    exit;
}

$class_id = $_GET['class_id'];
$term = $_GET['term'];

// Get students
$students = $conn->prepare("SELECT id, name FROM students WHERE class_id = ?");
$students->execute([$class_id]);
$students = $students->fetchAll(PDO::FETCH_ASSOC);

$rank_data = [];

foreach ($students as $student) {
    $student_id = $student['id'];

    // Get scores for this term (calculate from sequences)
    $scores = $conn->prepare("
        SELECT AVG((seq1 + seq2) / 2) as subject_avg, coefficient
        FROM scores 
        WHERE student_id = ? AND term = ?
        GROUP BY subject_id
    ");
    $scores->execute([$student_id, $term]);
    $scores = $scores->fetchAll(PDO::FETCH_ASSOC);

    $total_weighted = 0;
    $total_coef = 0;
    
    foreach ($scores as $score) {
        $avg = $score['subject_avg'] ?? 0;
        $coef = $score['coefficient'] ?? 1;
        $total_weighted += ($avg * $coef);
        $total_coef += $coef;
    }

    $average = $total_coef > 0 ? round($total_weighted / $total_coef, 2) : 0;

    $rank_data[] = [
        'id' => $student_id,
        'name' => $student['name'],
        'average' => $average
    ];
}

// Sort by average descending
usort($rank_data, fn($a, $b) => $b['average'] <=> $a['average']);

// Assign positions
foreach ($rank_data as $index => $student) {
    $position = $index + 1;

    $stmt = $conn->prepare("UPDATE report_summary SET position = ? WHERE student_id = ? AND term = ?");
    $stmt->execute([$position, $student['id'], $term]);
}

echo "<p style='color:green;'>✅ Ranking complete for class $class_id - $term term.</p>";
echo "<a href='class_ranking.php'>View Rankings</a>";
?>
