<?php
// samo/admin/delete_student.php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('admin');

$student_id = $_GET['id'] ?? null;
$class_id = $_GET['class_id'] ?? '';

if ($student_id && is_numeric($student_id)) {
    try {
        // Begin transaction
        $conn->beginTransaction();

        // Delete scores first
        $delete_scores = $conn->prepare("DELETE FROM scores WHERE student_id = ?");
        $delete_scores->execute([$student_id]);

        // Delete report summaries
        $delete_summary = $conn->prepare("DELETE FROM report_summary WHERE student_id = ?");
        $delete_summary->execute([$student_id]);

        // Delete student
        $delete_student = $conn->prepare("DELETE FROM students WHERE id = ?");
        $delete_student->execute([$student_id]);

        // Commit changes
        $conn->commit();
    } catch (PDOException $e) {
        // Rollback on error
        $conn->rollBack();
        header("Location: view_students.php?class_id=" . urlencode($class_id) . "&error=delete_failed");
        exit;
    }
}

// Redirect back to class view
header("Location: view_students.php?class_id=" . urlencode($class_id));
exit;
