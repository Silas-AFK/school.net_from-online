-- Add fields for enrollment number and next term begins date to report_summary table
ALTER TABLE report_summary 
ADD COLUMN IF NOT EXISTS next_term_begins DATE DEFAULT NULL;

-- Add enrollment field to classes table if not exists
ALTER TABLE classes 
ADD COLUMN IF NOT EXISTS enrollment INT DEFAULT 0;
