-- Add global next_term_begins field to school_info table
ALTER TABLE school_info 
ADD COLUMN IF NOT EXISTS next_term_begins DATE DEFAULT NULL;
