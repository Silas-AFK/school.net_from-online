<?php
require_once __DIR__ . '/../../includes/db.php';

// Already available from unified db.php
?>
