<?php
require_once 'includes/db.php';
require_once 'includes/functions.php';

if (!isset($_GET['student_id'])) {
    echo "<p style='color:red;'>No student ID provided.</p>";
    exit;
}

$student_id = $_GET['student_id'];
$term = '3rd'; // You can make this dynamic later

// Fetch student info
$stmt = $conn->prepare("SELECT s.name, s.dob, s.sex, s.place_of_birth, s.admission_no, c.name AS class_name
                        FROM students s
                        JOIN classes c ON s.class_id = c.id
                        WHERE s.id = ?");
$stmt->execute([$student_id]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$student) {
    echo "<p style='color:red;'>Student not found.</p>";
    exit;
}

// Fetch scores
$scores = $conn->prepare("SELECT sub.name AS subject, sc.exam_score
                          FROM scores sc
                          JOIN subjects sub ON sc.subject_id = sub.id
                          WHERE sc.student_id = ? AND sc.term = ?");
$scores->execute([$student_id, $term]);
$scores = $scores->fetchAll(PDO::FETCH_ASSOC);

// Fetch summary
$summary = $conn->prepare("SELECT total_marks, average, position, promoted
                           FROM report_summary
                           WHERE student_id = ? AND term = ?");
$summary->execute([$student_id, $term]);
$summary = $summary->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Verify Report Card - Caroma</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f6f9;
            padding: 20px;
        }
        .card {
            background: white;
            padding: 30px;
            max-width: 600px;
            margin: auto;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h2 {
            color: #003366;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        th, td {
            border: 1px solid #ccc;
            padding: 8px;
            text-align: left;
        }
        .verified {
            color: green;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="card">
        <h2>📌 Report Card Verification</h2>
        <p class="verified">✅ Verified: This report card is authentic.</p>

        <p><strong>Name:</strong> <?php echo $student['name']; ?></p>
        <p><strong>Admission No:</strong> <?php echo $student['admission_no']; ?></p>
        <p><strong>Class:</strong> <?php echo $student['class_name']; ?></p>
        <p><strong>DOB:</strong> <?php echo $student['dob']; ?> | <strong>Sex:</strong> <?php echo $student['sex']; ?></p>
        <p><strong>Place of Birth:</strong> <?php echo $student['place_of_birth']; ?></p>
        <p><strong>Term:</strong> <?php echo $term; ?></p>

        <h3>Subject Scores</h3>
        <table>
            <tr>
                <th>Subject</th>
                <th>Exam Score</th>
                <th>Grade</th>
            </tr>
            <?php foreach ($scores as $row): ?>
                <tr>
                    <td><?php echo $row['subject']; ?></td>
                    <td><?php echo $row['exam_score']; ?></td>
                    <td><?php echo getGrade($row['exam_score']); ?></td>
                </tr>
            <?php endforeach; ?>
        </table>

        <h3>Summary</h3>
        <p><strong>Total Marks:</strong> <?php echo $summary['total_marks']; ?></p>
        <p><strong>Average:</strong> <?php echo $summary['average']; ?></p>
        <p><strong>Class Position:</strong> <?php echo $summary['position']; ?></p>
        <p><strong>Promotion Status:</strong> <?php echo $summary['promoted'] ? 'Promoted' : 'Repeat'; ?></p>
    </div>
</body>
</html>
