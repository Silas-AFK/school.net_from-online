<?php
include '../config/db.php';
include 'auth.php';

if (!is_admin_logged_in()) {
    header('Location: login.php');
    exit;
}

$providers = $pdo->query("SELECT sp.*, s.name as skill_name FROM service_providers sp JOIN skills s ON sp.skill_id = s.id ORDER BY sp.created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Providers - Skill Up</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary-dark: #1a472a;
            --primary-medium: #2d5a3d;
            --accent-gold: #d4a574;
            --text-dark: #1a1a1a;
            --text-light: #666;
            --bg-light: #f9f9f9;
            --white: #ffffff;
            --border: #e0e0e0;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: var(--bg-light);
            color: var(--text-dark);
        }

        .admin-container {
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            width: 280px;
            background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary-medium) 100%);
            color: var(--white);
            padding: 30px 20px;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }

        .sidebar-logo {
            text-align: center;
            margin-bottom: 40px;
            font-size: 14px;
            letter-spacing: 1px;
            font-weight: 700;
        }

        .sidebar-logo span {
            font-size: 24px;
            display: block;
            margin-bottom: 8px;
        }

        .sidebar-menu {
            list-style: none;
        }

        .sidebar-menu li {
            margin-bottom: 10px;
        }

        .sidebar-menu a {
            display: flex;
            align-items: center;
            gap: 12px;
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            padding: 12px 15px;
            border-radius: 8px;
            transition: all 0.3s ease;
            font-size: 14px;
            font-weight: 500;
        }

        .sidebar-menu a:hover,
        .sidebar-menu a.active {
            background: rgba(212, 165, 116, 0.2);
            color: var(--accent-gold);
            padding-left: 20px;
        }

        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 30px;
        }

        .dashboard-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            background: var(--white);
            padding: 20px 30px;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }

        .dashboard-header h1 {
            font-size: 28px;
            color: var(--primary-dark);
        }

        .add-btn {
            background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary-medium) 100%);
            color: var(--white);
            padding: 12px 25px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
        }

        .add-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(26, 71, 42, 0.3);
        }

        .content-section {
            background: var(--white);
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table th {
            background: var(--bg-light);
            padding: 15px;
            text-align: left;
            font-weight: 600;
            color: var(--primary-dark);
            border-bottom: 2px solid var(--border);
        }

        table td {
            padding: 15px;
            border-bottom: 1px solid var(--border);
        }

        table tr:hover {
            background: var(--bg-light);
        }

        .action-btns {
            display: flex;
            gap: 8px;
        }

        .btn-small {
            padding: 8px 15px;
            border: none;
            border-radius: 6px;
            font-size: 12px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-weight: 600;
            text-decoration: none;
            display: inline-block;
        }

        .btn-edit {
            background: var(--accent-gold);
            color: var(--primary-dark);
        }

        .btn-delete {
            background: #f5e6e6;
            color: #d32f2f;
        }

        .btn-edit:hover,
        .btn-delete:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .status-active {
            background: #e8f5e9;
            color: #2e7d32;
            padding: 4px 10px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 600;
        }

        .status-inactive {
            background: #ffebee;
            color: #c62828;
            padding: 4px 10px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 600;
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: static;
            }

            .main-content {
                margin-left: 0;
            }

            table {
                font-size: 12px;
            }

            table th,
            table td {
                padding: 8px;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <aside class="sidebar">
            <div class="sidebar-logo">
                <span>⚙️</span>
                SKILL UP
            </div>
            <ul class="sidebar-menu">
                <li><a href="dashboard.php">📊 Dashboard</a></li>
                <li><a href="manage-providers.php" class="active">👥 Manage Providers</a></li>
                <li><a href="manage-skills.php">💼 Manage Skills</a></li>
                <li><a href="manage-messages.php">💬 Messages</a></li>
            </ul>
        </aside>

        <div class="main-content">
            <div class="dashboard-header">
                <h1>Manage Service Providers</h1>
                <a href="add-provider.php" class="add-btn">+ Add Provider</a>
            </div>

            <div class="content-section">
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Skill</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Rating</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($providers as $provider): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($provider['name']); ?></strong></td>
                                <td><?php echo htmlspecialchars($provider['skill_name']); ?></td>
                                <td><?php echo htmlspecialchars($provider['email']); ?></td>
                                <td><?php echo htmlspecialchars($provider['phone']); ?></td>
                                <td>⭐ <?php echo number_format($provider['rating'], 1); ?></td>
                                <td>
                                    <span class="<?php echo $provider['is_active'] ? 'status-active' : 'status-inactive'; ?>">
                                        <?php echo $provider['is_active'] ? 'Active' : 'Inactive'; ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="action-btns">
                                        <a href="edit-provider.php?id=<?php echo $provider['id']; ?>" class="btn-small btn-edit">Edit</a>
                                        <a href="delete-provider.php?id=<?php echo $provider['id']; ?>" class="btn-small btn-delete" onclick="return confirm('Delete this provider?');">Delete</a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
