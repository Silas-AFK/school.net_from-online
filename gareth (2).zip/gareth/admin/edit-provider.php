<?php
include '../config/db.php';
include 'auth.php';

if (!is_admin_logged_in()) {
    header('Location: login.php');
    exit;
}

$id = intval($_GET['id'] ?? 0);
if (!$id) {
    header('Location: manage-providers.php');
    exit;
}

$skills = $pdo->query("SELECT id, name FROM skills ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
$provider = $pdo->prepare("SELECT * FROM service_providers WHERE id = ?");
$provider->execute([$id]);
$provider = $provider->fetch(PDO::FETCH_ASSOC);
if (!$provider) {
    header('Location: manage-providers.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $skill_id = intval($_POST['skill_id'] ?? 0);
    $bio = trim($_POST['bio'] ?? '');
    $location = trim($_POST['location'] ?? '');
    $is_active = isset($_POST['is_active']) ? 1 : 0;

    if (!$name || !$email || !$skill_id) {
        $error = 'Name, email and skill are required.';
    } else {
        $stmt = $pdo->prepare("UPDATE service_providers SET name = ?, email = ?, phone = ?, skill_id = ?, bio = ?, location = ?, is_active = ? WHERE id = ?");
        $stmt->execute([$name, $email, $phone, $skill_id, $bio, $location, $is_active, $id]);
        header('Location: manage-providers.php');
        exit;
    }
}
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Edit Provider</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <h1>Edit Provider</h1>
    <p><a href="manage-providers.php">Back to Providers</a></p>

    <?php if ($error): ?><div style="color:red"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

    <form method="post">
        <input type="text" name="name" value="<?php echo htmlspecialchars($provider['name']); ?>" required>
        <br>
        <input type="email" name="email" value="<?php echo htmlspecialchars($provider['email']); ?>" required>
        <br>
        <input type="text" name="phone" value="<?php echo htmlspecialchars($provider['phone']); ?>">
        <br>
        <select name="skill_id" required>
            <option value="">Select Skill</option>
            <?php foreach ($skills as $s): ?>
                <option value="<?php echo $s['id']; ?>" <?php echo $provider['skill_id']==$s['id']? 'selected': ''; ?>><?php echo htmlspecialchars($s['name']); ?></option>
            <?php endforeach; ?>
        </select>
        <br>
        <input type="text" name="location" value="<?php echo htmlspecialchars($provider['location']); ?>">
        <br>
        <textarea name="bio"><?php echo htmlspecialchars($provider['bio']); ?></textarea>
        <br>
        <label><input type="checkbox" name="is_active" <?php echo $provider['is_active']? 'checked' : ''; ?>> Active</label>
        <br>
        <button type="submit">Save Changes</button>
    </form>
</body>
</html>