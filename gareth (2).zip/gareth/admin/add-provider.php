<?php
include '../config/db.php';
include 'auth.php';

if (!is_admin_logged_in()) {
    header('Location: login.php');
    exit;
}

$skills = $pdo->query("SELECT id, name FROM skills ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $skill_id = intval($_POST['skill_id'] ?? 0);
    $bio = trim($_POST['bio'] ?? '');
    $location = trim($_POST['location'] ?? '');
    $is_active = isset($_POST['is_active']) ? 1 : 0;

    if (!$name || !$email || !$skill_id) {
        $error = 'Name, email and skill are required.';
    } else {
        $stmt = $pdo->prepare("INSERT INTO service_providers (name, email, phone, skill_id, bio, location, is_active) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$name, $email, $phone, $skill_id, $bio, $location, $is_active]);
        $id = $pdo->lastInsertId();
        // Redirect to the provider details page after creating
        header('Location: view-provider.php?id=' . intval($id));
        exit;
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Add Provider - Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="admin-container">
        <aside class="sidebar">
            <div class="sidebar-logo">
                <span>⚙️</span>
                SKILL UP
            </div>
            <ul class="sidebar-menu">
                <li><a href="dashboard.php">📊 Dashboard</a></li>
                <li><a href="manage-providers.php" class="active">👥 Manage Providers</a></li>
                <li><a href="manage-skills.php">💼 Manage Skills</a></li>
                <li><a href="manage-messages.php">💬 Messages</a></li>
            </ul>
            <div class="sidebar-logout">
                <a href="logout.php">🚪 Logout</a>
            </div>
        </aside>

        <div class="main-content">
            <div class="dashboard-header">
                <h1>Add Provider</h1>
                <div>
                    <a href="manage-providers.php" class="add-btn">← Back to Providers</a>
                </div>
            </div>

            <div class="content-section">
                <?php if ($error): ?>
                    <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
                <?php endif; ?>

                <style>
                    /* Scoped admin form styles */
                    .admin-form {
                        max-width: 900px;
                        margin: 0 auto;
                    }
                    .admin-form .form-grid {
                        display: grid;
                        grid-template-columns: repeat(2, 1fr);
                        gap: 16px;
                    }
                    .admin-form .form-group {
                        display: flex;
                        flex-direction: column;
                        gap: 8px;
                    }
                    .admin-form label { font-weight: 600; color: var(--primary-dark); }
                    .admin-form input[type="text"],
                    .admin-form input[type="email"],
                    .admin-form input[type="tel"],
                    .admin-form select,
                    .admin-form textarea {
                        padding: 12px 14px;
                        border: 1px solid var(--border);
                        border-radius: 8px;
                        font-family: inherit;
                        font-size: 14px;
                    }
                    .admin-form textarea { min-height: 120px; resize: vertical; }
                    .admin-form .actions { margin-top: 18px; display:flex; gap:12px; align-items:center; }
                    .help-text { font-size: 13px; color: var(--text-light); }

                    @media (max-width: 768px) {
                        .admin-form .form-grid { grid-template-columns: 1fr; }
                    }
                </style>

                <form method="post" class="admin-form" novalidate>
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="name">Full Name *</label>
                            <input type="text" id="name" name="name" placeholder="Full name" required>
                        </div>

                        <div class="form-group">
                            <label for="email">Email *</label>
                            <input type="email" id="email" name="email" placeholder="Email" required>
                        </div>

                        <div class="form-group">
                            <label for="phone">Phone</label>
                            <input type="tel" id="phone" name="phone" placeholder="e.g., +2376XXXXXXXX">
                            <div class="help-text">Include country code for direct calls/WhatsApp (optional)</div>
                        </div>

                        <div class="form-group">
                            <label for="skill_id">Skill *</label>
                            <select id="skill_id" name="skill_id" required>
                                <option value="">Select Skill</option>
                                <?php foreach ($skills as $s): ?>
                                    <option value="<?php echo $s['id']; ?>"><?php echo htmlspecialchars($s['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="location">Location</label>
                            <input type="text" id="location" name="location" placeholder="City, Region">
                        </div>

                        <div class="form-group">
                            <label for="is_active">Status</label>
                            <select id="is_active" name="is_active">
                                <option value="1" selected>Active</option>
                                <option value="0">Inactive</option>
                            </select>
                        </div>

                        <div class="form-group" style="grid-column: 1 / -1;">
                            <label for="bio">Short Bio</label>
                            <textarea id="bio" name="bio" placeholder="Short bio about the provider"></textarea>
                        </div>
                    </div>

                    <div class="actions">
                        <button type="button" id="previewBtn" class="add-btn">Preview & Add</button>
                        <button type="submit" id="submitBtn" class="add-btn" style="display:none">Add Provider</button>
                        <a href="manage-providers.php" class="btn-small" style="background:transparent;border:1px solid var(--border);">Cancel</a>
                    </div>
                </form>

                <!-- Preview Modal -->
                <div id="previewModal" style="display:none">
                    <div class="modal-overlay"></div>
                    <div class="modal-card">
                        <h3>Preview Provider</h3>
                        <div id="previewContent"></div>
                        <div style="display:flex; gap:12px; margin-top:16px;">
                            <button id="confirmAdd" class="add-btn">Confirm & Add</button>
                            <button id="closePreview" class="btn-small" style="background:transparent;border:1px solid var(--border);">Cancel</button>
                        </div>
                    </div>
                </div>

                <script>
                    // Client-side validation and phone normalization
                    (function(){
                        const form = document.querySelector('.admin-form');
                        const previewBtn = document.getElementById('previewBtn');
                        const submitBtn = document.getElementById('submitBtn');
                        const previewModal = document.getElementById('previewModal');
                        const closePreview = document.getElementById('closePreview');
                        const confirmAdd = document.getElementById('confirmAdd');
                        const previewContent = document.getElementById('previewContent');

                        function showError(el, msg) {
                            let next = el.nextElementSibling;
                            if (next && next.classList && next.classList.contains('field-error')) {
                                next.textContent = msg;
                                return;
                            }
                            const span = document.createElement('div');
                            span.className = 'field-error';
                            span.style.color = '#d32f2f';
                            span.style.fontSize = '13px';
                            span.style.marginTop = '6px';
                            span.textContent = msg;
                            el.parentNode.appendChild(span);
                        }
                        function clearErrors() {
                            document.querySelectorAll('.field-error').forEach(e => e.remove());
                        }

                        function normalizePhone(phone) {
                            if (!phone) return '';
                            let digits = phone.replace(/\D+/g, '');
                            // Remove leading zeros
                            digits = digits.replace(/^0+/, '');
                            // If it already has country code 237 at start, keep
                            if (!digits.startsWith('237')) {
                                if (digits.length === 8 || digits.length === 9) {
                                    digits = '237' + digits;
                                }
                            }
                            return (digits ? '+' + digits : '');
                        }

                        function isValidEmail(email) {
                            return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
                        }

                        function gatherData() {
                            const data = {};
                            data.name = document.getElementById('name').value.trim();
                            data.email = document.getElementById('email').value.trim();
                            data.phone = document.getElementById('phone').value.trim();
                            data.skill = document.getElementById('skill_id').options[document.getElementById('skill_id').selectedIndex].text;
                            data.location = document.getElementById('location').value.trim();
                            data.bio = document.getElementById('bio').value.trim();
                            data.is_active = document.getElementById('is_active') ? document.getElementById('is_active').value : '1';
                            return data;
                        }

                        previewBtn.addEventListener('click', function(){
                            clearErrors();
                            const nameEl = document.getElementById('name');
                            const emailEl = document.getElementById('email');
                            const phoneEl = document.getElementById('phone');
                            const skillEl = document.getElementById('skill_id');

                            let ok = true;
                            if (!nameEl.value.trim()) { showError(nameEl, 'Name is required'); ok = false; }
                            if (!emailEl.value.trim() || !isValidEmail(emailEl.value.trim())) { showError(emailEl, 'Valid email is required'); ok = false; }
                            if (!skillEl.value) { showError(skillEl, 'Please select a skill'); ok = false; }

                            // Normalize phone for display
                            const norm = normalizePhone(phoneEl.value);

                            if (!ok) return;

                            const data = gatherData();
                            data.phone = norm || '(not provided)';

                            // Fill preview content
                            previewContent.innerHTML = `
                                <p><strong>Name:</strong> ${escapeHtml(data.name)}</p>
                                <p><strong>Email:</strong> ${escapeHtml(data.email)}</p>
                                <p><strong>Phone:</strong> ${escapeHtml(data.phone)}</p>
                                <p><strong>Skill:</strong> ${escapeHtml(data.skill)}</p>
                                <p><strong>Location:</strong> ${escapeHtml(data.location || '(not provided)')}</p>
                                <p><strong>Bio:</strong> ${escapeHtml(data.bio || '(not provided)')}</p>
                            `;

                            // show modal
                            previewModal.style.display = 'block';
                        });

                        closePreview.addEventListener('click', function(){ previewModal.style.display = 'none'; });

                        confirmAdd.addEventListener('click', function(){
                            // Before submit, set phone to normalized format to server
                            const phoneEl = document.getElementById('phone');
                            phoneEl.value = normalizePhone(phoneEl.value);
                            // actually submit
                            document.getElementById('submitBtn').click();
                        });

                        // Simple on-the-fly formatting for phone input
                        const phoneInput = document.getElementById('phone');
                        phoneInput.addEventListener('blur', function(){
                            this.value = normalizePhone(this.value);
                        });

                        function escapeHtml(unsafe) {
                            return (unsafe || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
                        }

                    })();
                </script>

                <style>
                    /* Modal styles */
                    #previewModal { position: fixed; inset: 0; display: none; align-items: center; justify-content: center; z-index: 2000; }
                    #previewModal .modal-overlay { position: absolute; inset: 0; background: rgba(0,0,0,0.5); }
                    #previewModal .modal-card { position: relative; background: var(--white); padding: 24px; border-radius: 12px; width: 540px; max-width: 92%; z-index: 2; box-shadow: 0 10px 40px rgba(0,0,0,0.2); }
                    .field-error { margin-top: 6px; }
                </style>
            </div>
        </div>
    </div>
</body>
</html>