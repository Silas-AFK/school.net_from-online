<?php
include '../config/db.php';
include 'auth.php';

if (!is_admin_logged_in()) {
    header('Location: login.php');
    exit;
}

$id = intval($_GET['id'] ?? 0);
if ($id) {
    $stmt = $pdo->prepare("DELETE FROM service_providers WHERE id = ?");
    $stmt->execute([$id]);
}
header('Location: manage-providers.php');
exit;
?>