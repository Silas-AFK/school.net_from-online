<?php
include '../config/db.php';
include 'auth.php';

if (!is_admin_logged_in()) {
    header('Location: login.php');
    exit;
}

$id = intval($_GET['id'] ?? 0);
if (!$id) {
    header('Location: manage-providers.php');
    exit;
}

$stmt = $pdo->prepare("SELECT sp.*, s.name as skill_name FROM service_providers sp JOIN skills s ON sp.skill_id = s.id WHERE sp.id = ?");
$stmt->execute([$id]);
$provider = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$provider) {
    header('Location: manage-providers.php');
    exit;
}

function normalize_phone_for_links($phone) {
    $digits = preg_replace('/\D+/', '', $phone);
    $digits = preg_replace('/^0+/', '', $digits);
    if (!$digits) return '';
    if (!preg_match('/^237/', $digits)) {
        if (strlen($digits) <= 9) $digits = '237' . $digits;
    }
    return '+' . $digits;
}
$phone_link = normalize_phone_for_links($provider['phone'] ?? '');
$wa_link = $phone_link ? 'https://wa.me/' . preg_replace('/\D+/', '', $phone_link) : '';
$tel_link = $phone_link ? 'tel:' . $phone_link : '';
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Provider Details - Admin</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="admin-container">
        <aside class="sidebar">
            <div class="sidebar-logo">
                <span>⚙️</span>
                SKILL UP
            </div>
            <ul class="sidebar-menu">
                <li><a href="dashboard.php">📊 Dashboard</a></li>
                <li><a href="manage-providers.php">👥 Manage Providers</a></li>
                <li><a href="manage-skills.php">💼 Manage Skills</a></li>
                <li><a href="manage-messages.php">💬 Messages</a></li>
            </ul>
            <div class="sidebar-logout">
                <a href="logout.php">🚪 Logout</a>
            </div>
        </aside>

        <div class="main-content">
            <div class="dashboard-header">
                <h1>Provider Details</h1>
                <div>
                    <a href="manage-providers.php" class="add-btn">← Back to Providers</a>
                </div>
            </div>

            <div class="content-section">
                <div style="display:flex; gap:20px; align-items:flex-start; flex-wrap:wrap;">
                    <div style="width:140px; height:140px; border-radius:12px; background:var(--accent-gold); display:flex; align-items:center; justify-content:center; font-size:44px; color:var(--primary-dark);">
                        <?php
                        $skill_icons = [
                            'Carpentry' => '🔨',
                            'Cleaning' => '🧹',
                            'Electricity' => '⚡',
                            'Plumbing' => '🔧',
                            'Tiles & Craft' => '🎨',
                            'Hair Dressing' => '✂️'
                        ];
                        echo $skill_icons[$provider['skill_name']] ?? '👤';
                        ?>
                    </div>

                    <div style="flex:1; min-width:260px;">
                        <h2 style="margin-bottom:6px"><?php echo htmlspecialchars($provider['name']); ?></h2>
                        <div style="color:var(--text-light); margin-bottom:14px;"><?php echo htmlspecialchars($provider['skill_name']); ?> • <?php echo htmlspecialchars($provider['location'] ?? ''); ?></div>

                        <p style="margin-bottom:12px;"><?php echo nl2br(htmlspecialchars($provider['bio'] ?? '')); ?></p>

                        <div style="display:flex; gap:10px; flex-wrap:wrap; margin-top:12px;">
                            <?php if ($wa_link): ?><a href="<?php echo $wa_link; ?>" target="_blank" class="add-btn">WhatsApp</a><?php endif; ?>
                            <?php if ($tel_link): ?><a href="<?php echo $tel_link; ?>" class="add-btn">Call</a><?php endif; ?>
                            <?php if (!empty($provider['email'])): ?><a href="mailto:<?php echo htmlspecialchars($provider['email']); ?>" class="btn-small" style="background:transparent;border:1px solid var(--border);">Email</a><?php endif; ?>
                        </div>

                        <div style="margin-top:18px; font-size:13px; color:var(--text-light);">Added: <?php echo htmlspecialchars($provider['created_at']); ?></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>