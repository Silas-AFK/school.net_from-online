<?php
include '../config/db.php';
include 'auth.php';

if (!is_admin_logged_in()) {
    header('Location: login.php');
    exit;
}

// Handle add skill
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_skill'])) {
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    if ($name && $description) {
        $stmt = $pdo->prepare("INSERT INTO skills (name, description) VALUES (?, ?)");
        $stmt->execute([$name, $description]);
        header('Location: manage-skills.php');
        exit;
    }
}

// Handle delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $stmt = $pdo->prepare("DELETE FROM skills WHERE id = ?");
    $stmt->execute([$id]);
    header('Location: manage-skills.php');
    exit;
}

$skills = $pdo->query("SELECT * FROM skills ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Manage Skills - Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="admin-container">
        <aside class="sidebar">
            <div class="sidebar-logo">
                <span>⚙️</span>
                SKILL UP
            </div>
            <ul class="sidebar-menu">
                <li><a href="dashboard.php">📊 Dashboard</a></li>
                <li><a href="manage-providers.php">👥 Manage Providers</a></li>
                <li><a href="manage-skills.php" class="active">💼 Manage Skills</a></li>
                <li><a href="manage-messages.php">💬 Messages</a></li>
            </ul>
            <div class="sidebar-logout">
                <a href="logout.php">🚪 Logout</a>
            </div>
        </aside>

        <div class="main-content">
            <div class="dashboard-header">
                <h1>Manage Skills</h1>
                <div>
                    <a href="dashboard.php" class="add-btn">← Back to Dashboard</a>
                </div>
            </div>

            <div class="content-grid">
                <div class="content-section">
                    <h3 class="section-title">Add Skill</h3>
                    <form method="post" id="addSkillForm" class="admin-form" novalidate>
                        <div class="form-grid" style="grid-template-columns:1fr;">
                            <div class="form-group">
                                <label for="name">Skill Name *</label>
                                <input type="text" id="name" name="name" placeholder="Skill name" required>
                            </div>

                            <div class="form-group">
                                <label for="description">Description *</label>
                                <textarea id="description" name="description" placeholder="Description" required></textarea>
                            </div>
                        </div>

                        <div style="margin-top:12px; display:flex; gap:12px; align-items:center;">
                            <button type="submit" name="add_skill" class="add-btn">Add Skill</button>
                            <span class="help-text">Skills help categorize providers; keep names short and clear.</span>
                        </div>
                    </form>
                </div>

                <div class="content-section">
                    <h3 class="section-title">Existing Skills</h3>
                    <div style="overflow-x:auto;">
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th style="width:80px">ID</th>
                                <th>Name</th>
                                <th>Description</th>
                                <th style="width:140px">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($skills as $s): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($s['id']); ?></td>
                                    <td><?php echo htmlspecialchars($s['name']); ?></td>
                                    <td><?php echo htmlspecialchars($s['description']); ?></td>
                                    <td>
                                        <div class="table-actions">
                                            <!--<a href="edit-skill.php?id=<?php echo $s['id']; ?>" class="btn-small btn-edit">Edit</a>-->
                                            <a href="manage-skills.php?delete=<?php echo $s['id']; ?>" class="btn-small btn-delete delete-skill" data-name="<?php echo htmlspecialchars($s['name']); ?>">Delete</a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    </div>
                </div>
            </div>

            <!-- Delete confirmation modal -->
            <div id="deleteModal" style="display:none">
                <div class="modal-overlay"></div>
                <div class="modal-card">
                    <h3>Delete Skill</h3>
                    <p>Are you sure you want to delete <strong id="skillToDelete"></strong>?</p>
                    <div style="display:flex; gap:12px; margin-top:12px;">
                        <button id="confirmDelete" class="btn-small btn-delete">Delete</button>
                        <button id="cancelDelete" class="btn-small" style="background:transparent;border:1px solid var(--border);">Cancel</button>
                    </div>
                </div>
            </div>

            <style>
                /* modal styles scoped for this page */
                #deleteModal { position: fixed; inset:0; display:none; align-items:center; justify-content:center; z-index:2000; }
                #deleteModal .modal-overlay { position:absolute; inset:0; background:rgba(0,0,0,0.5); }
                #deleteModal .modal-card { position:relative; background:var(--white); padding:20px; border-radius:10px; width:460px; max-width:92%; z-index:2; box-shadow:0 10px 30px rgba(0,0,0,0.15); }
            </style>

            <script>
                (function(){
                    // Add skill client-side validation
                    const form = document.getElementById('addSkillForm');
                    form.addEventListener('submit', function(e){
                        // clear existing errors
                        form.querySelectorAll('.field-error').forEach(n => n.remove());
                        let ok = true;
                        const name = document.getElementById('name');
                        const desc = document.getElementById('description');
                        if (!name.value.trim()) { showError(name, 'Name is required'); ok = false; }
                        if (!desc.value.trim()) { showError(desc, 'Description is required'); ok = false; }
                        if (!ok) e.preventDefault();
                    });
                    function showError(el, msg) {
                        const span = document.createElement('div');
                        span.className = 'field-error';
                        span.style.color = '#d32f2f';
                        span.style.fontSize = '13px';
                        span.style.marginTop = '6px';
                        span.textContent = msg;
                        el.parentNode.appendChild(span);
                    }

                    // Delete confirmation modal
                    const deleteLinks = document.querySelectorAll('.delete-skill');
                    const modal = document.getElementById('deleteModal');
                    const skillNameEl = document.getElementById('skillToDelete');
                    const confirmBtn = document.getElementById('confirmDelete');
                    const cancelBtn = document.getElementById('cancelDelete');
                    let deleteHref = null;

                    deleteLinks.forEach(link => {
                        link.addEventListener('click', function(e){
                            e.preventDefault();
                            deleteHref = this.getAttribute('href');
                            const name = this.dataset.name || 'this skill';
                            skillNameEl.textContent = name;
                            modal.style.display = 'flex';
                        });
                    });

                    cancelBtn.addEventListener('click', function(){ modal.style.display = 'none'; deleteHref = null; });
                    confirmBtn.addEventListener('click', function(){ if (deleteHref) window.location.href = deleteHref; });
                })();
            </script>
        </div>
    </div>
</body>
</html>