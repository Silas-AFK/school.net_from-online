<?php
include '../config/db.php';
include 'auth.php';

if (!is_admin_logged_in()) {
    header('Location: login.php');
    exit;
}

// Get dashboard statistics
$providers_count = $pdo->query("SELECT COUNT(*) FROM service_providers")->fetchColumn();
$skills_count = $pdo->query("SELECT COUNT(*) FROM skills")->fetchColumn();
$messages_count = $pdo->query("SELECT COUNT(*) FROM contacts")->fetchColumn();

// Get recent messages
$recent_messages = $pdo->query("SELECT * FROM contacts ORDER BY created_at DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);

// Get recent providers
$recent_providers = $pdo->query("SELECT sp.*, s.name as skill_name FROM service_providers sp JOIN skills s ON sp.skill_id = s.id ORDER BY sp.created_at DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Skill Up</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary-dark: #1a472a;
            --primary-medium: #2d5a3d;
            --accent-gold: #d4a574;
            --text-dark: #1a1a1a;
            --text-light: #666;
            --bg-light: #f9f9f9;
            --white: #ffffff;
            --border: #e0e0e0;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: var(--bg-light);
            color: var(--text-dark);
        }

        .admin-container {
            display: flex;
            min-height: 100vh;
        }

        /* SIDEBAR */
        .sidebar {
            width: 280px;
            background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary-medium) 100%);
            color: var(--white);
            padding: 30px 20px;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            animation: slideDown 0.5s ease-out;
        }

        .sidebar-logo {
            text-align: center;
            margin-bottom: 40px;
            font-size: 14px;
            letter-spacing: 1px;
            font-weight: 700;
        }

        .sidebar-logo span {
            font-size: 24px;
            display: block;
            margin-bottom: 8px;
        }

        .sidebar-menu {
            list-style: none;
        }

        .sidebar-menu li {
            margin-bottom: 10px;
        }

        .sidebar-menu a {
            display: flex;
            align-items: center;
            gap: 12px;
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            padding: 12px 15px;
            border-radius: 8px;
            transition: all 0.3s ease;
            font-size: 14px;
            font-weight: 500;
        }

        .sidebar-menu a:hover,
        .sidebar-menu a.active {
            background: rgba(212, 165, 116, 0.2);
            color: var(--accent-gold);
            padding-left: 20px;
        }

        .sidebar-logout {
            position: absolute;
            bottom: 30px;
            left: 20px;
            right: 20px;
            width: calc(100% - 40px);
        }

        .sidebar-logout a {
            background: rgba(212, 165, 116, 0.2);
            justify-content: center;
            color: var(--accent-gold);
        }

        .sidebar-logout a:hover {
            background: var(--accent-gold);
            color: var(--primary-dark);
        }

        /* MAIN CONTENT */
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 30px;
        }

        .dashboard-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 40px;
            background: var(--white);
            padding: 20px 30px;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }

        .dashboard-header h1 {
            font-size: 28px;
            color: var(--primary-dark);
        }

        .admin-user {
            display: flex;
            align-items: center;
            gap: 12px;
            color: var(--text-light);
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary-medium) 100%);
            color: var(--white);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 18px;
        }

        /* STATS GRID */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }

        .stat-card {
            background: var(--white);
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            border-left: 4px solid var(--accent-gold);
            transition: all 0.3s ease;
            animation: slideUp 0.6s ease-out both;
        }

        .stat-card:nth-child(1) { animation-delay: 0.1s; }
        .stat-card:nth-child(2) { animation-delay: 0.2s; }
        .stat-card:nth-child(3) { animation-delay: 0.3s; }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
        }

        .stat-icon {
            font-size: 32px;
            margin-bottom: 10px;
        }

        .stat-label {
            color: var(--text-light);
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 5px;
            font-weight: 600;
        }

        .stat-value {
            font-size: 36px;
            color: var(--primary-dark);
            font-weight: 800;
        }

        /* CONTENT GRID */
        .content-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 25px;
        }

        .content-section {
            background: var(--white);
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
        }

        .section-title {
            font-size: 20px;
            color: var(--primary-dark);
            margin-bottom: 20px;
            font-weight: 700;
            border-bottom: 2px solid var(--border);
            padding-bottom: 15px;
        }

        /* TABLE STYLES */
        table {
            width: 100%;
            border-collapse: collapse;
        }

        table th {
            background: var(--bg-light);
            padding: 12px;
            text-align: left;
            font-weight: 600;
            color: var(--primary-dark);
            font-size: 13px;
            border-bottom: 2px solid var(--border);
        }

        table td {
            padding: 15px 12px;
            border-bottom: 1px solid var(--border);
            font-size: 13px;
        }

        table tr:hover {
            background: var(--bg-light);
        }

        .action-btns {
            display: flex;
            gap: 8px;
        }

        .btn-small {
            padding: 6px 12px;
            border: none;
            border-radius: 6px;
            font-size: 12px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-weight: 600;
            text-decoration: none;
            display: inline-block;
        }

        .btn-edit {
            background: var(--accent-gold);
            color: var(--primary-dark);
        }

        .btn-delete {
            background: #f5e6e6;
            color: #d32f2f;
        }

        .btn-edit:hover,
        .btn-delete:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .empty-state {
            text-align: center;
            padding: 30px;
            color: var(--text-light);
        }

        .empty-state p {
            font-size: 14px;
        }

        /* RESPONSIVE */
        @media (max-width: 1200px) {
            .content-grid {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: static;
            }

            .main-content {
                margin-left: 0;
                padding: 20px;
            }

            .dashboard-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }

            .sidebar-logout {
                position: static;
                width: auto;
                margin-top: 20px;
            }

            .sidebar-menu {
                display: flex;
                flex-wrap: wrap;
                gap: 10px;
            }

            .sidebar-menu li {
                margin-bottom: 0;
            }

            .stats-grid {
                grid-template-columns: 1fr;
            }

            table {
                font-size: 12px;
            }

            table th,
            table td {
                padding: 8px;
            }
        }

        @keyframes slideUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: translateY(-20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- SIDEBAR -->
        <aside class="sidebar">
            <div class="sidebar-logo">
                <span>⚙️</span>
                SKILL UP
            </div>
            <ul class="sidebar-menu">
                <li><a href="dashboard.php" class="active">📊 Dashboard</a></li>
                <li><a href="manage-providers.php">👥 Manage Providers</a></li>
                <li><a href="manage-skills.php">💼 Manage Skills</a></li>
                <li><a href="manage-messages.php">💬 Messages</a></li>
            </ul>
            <div class="sidebar-logout">
                <a href="logout.php">🚪 Logout</a>
            </div>
        </aside>

        <!-- MAIN CONTENT -->
        <div class="main-content">
            <!-- HEADER -->
            <div class="dashboard-header">
                <h1>Dashboard</h1>
                <div class="admin-user">
                    <div class="user-avatar">G</div>
                    <div>
                        <strong><?php echo htmlspecialchars($_SESSION['admin_username']); ?></strong>
                        <p style="font-size: 12px;">Administrator</p>
                    </div>
                </div>
            </div>

            <!-- STATS -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon">👥</div>
                    <div class="stat-label">Service Providers</div>
                    <div class="stat-value"><?php echo $providers_count; ?></div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">💼</div>
                    <div class="stat-label">Skills Available</div>
                    <div class="stat-value"><?php echo $skills_count; ?></div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">💬</div>
                    <div class="stat-label">Total Messages</div>
                    <div class="stat-value"><?php echo $messages_count; ?></div>
                </div>
            </div>

            <!-- CONTENT GRID -->
            <div class="content-grid">
                <!-- RECENT PROVIDERS -->
                <div class="content-section">
                    <h3 class="section-title">Recent Providers</h3>
                    <?php if (empty($recent_providers)): ?>
                        <div class="empty-state">
                            <p>No service providers yet</p>
                        </div>
                    <?php else: ?>
                        <table>
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Skill</th>
                                    <th>Email</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent_providers as $provider): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($provider['name']); ?></td>
                                        <td><?php echo htmlspecialchars($provider['skill_name']); ?></td>
                                        <td><?php echo htmlspecialchars($provider['email']); ?></td>
                                        <td>
                                            <div class="action-btns">
                                                <a href="edit-provider.php?id=<?php echo $provider['id']; ?>" class="btn-small btn-edit">Edit</a>
                                                <a href="delete-provider.php?id=<?php echo $provider['id']; ?>" class="btn-small btn-delete" onclick="return confirm('Delete this provider?');">Delete</a>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>

                <!-- RECENT MESSAGES -->
                <div class="content-section">
                    <h3 class="section-title">Recent Messages</h3>
                    <?php if (empty($recent_messages)): ?>
                        <div class="empty-state">
                            <p>No messages yet</p>
                        </div>
                    <?php else: ?>
                        <div style="max-height: 400px; overflow-y: auto;">
                            <?php foreach ($recent_messages as $msg): ?>
                                <div style="padding: 12px; border-bottom: 1px solid var(--border); font-size: 13px;">
                                    <strong style="color: var(--primary-dark);"><?php echo htmlspecialchars($msg['name']); ?></strong>
                                    <p style="color: var(--text-light); margin: 5px 0; font-size: 12px;"><?php echo htmlspecialchars(substr($msg['message'], 0, 60)) . '...'; ?></p>
                                    <small style="color: #aaa;"><?php echo date('M d, Y', strtotime($msg['created_at'])); ?></small>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
