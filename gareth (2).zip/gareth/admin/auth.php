<?php
// Admin authentication handler
session_start();

// Hardcoded admin credentials
$ADMIN_USERNAME = 'gareth';
$ADMIN_PASSWORD = 'gareth123';

function authenticate_admin($username, $password) {
    global $ADMIN_USERNAME, $ADMIN_PASSWORD;
    
    if ($username === $ADMIN_USERNAME && $password === $ADMIN_PASSWORD) {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_username'] = $username;
        return true;
    }
    return false;
}

function is_admin_logged_in() {
    return isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
}

function logout_admin() {
    session_destroy();
    header('Location: login.php');
    exit;
}

// Handle login form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    if (authenticate_admin($username, $password)) {
        header('Location: dashboard.php');
        exit;
    } else {
        $error = 'Invalid credentials';
    }
}
?>
