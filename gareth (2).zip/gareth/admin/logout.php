<?php
include 'auth.php';
logout_admin();
?>
