<?php
include '../config/db.php';
include 'auth.php';

if (!is_admin_logged_in()) {
    header('Location: login.php');
    exit;
}

if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $stmt = $pdo->prepare("DELETE FROM contacts WHERE id = ?");
    $stmt->execute([$id]);
    header('Location: manage-messages.php');
    exit;
}

$messages = $pdo->query("SELECT * FROM contacts ORDER BY created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Manage Messages - Admin</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <div class="admin-container">
        <aside class="sidebar">
            <div class="sidebar-logo">
                <span>⚙️</span>
                SKILL UP
            </div>
            <ul class="sidebar-menu">
                <li><a href="dashboard.php">📊 Dashboard</a></li>
                <li><a href="manage-providers.php">👥 Manage Providers</a></li>
                <li><a href="manage-skills.php">💼 Manage Skills</a></li>
                <li><a href="manage-messages.php" class="active">💬 Messages</a></li>
            </ul>
            <div class="sidebar-logout">
                <a href="logout.php">🚪 Logout</a>
            </div>
        </aside>

        <div class="main-content">
            <div class="dashboard-header">
                <h1>Contact Messages</h1>
                <div>
                    <a href="dashboard.php" class="add-btn">← Dashboard</a>
                </div>
            </div>

            <div class="content-section">
                <h3 class="section-title">All Messages</h3>
                <div style="overflow-x:auto;">
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Subject</th>
                                <th>Message</th>
                                <th>Time</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($messages as $m): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($m['id']); ?></td>
                                    <td><?php echo htmlspecialchars($m['name']); ?></td>
                                    <td><?php echo htmlspecialchars($m['email']); ?></td>
                                    <td><?php echo htmlspecialchars($m['subject']); ?></td>
                                    <td><?php echo nl2br(htmlspecialchars($m['message'])); ?></td>
                                    <td><?php echo htmlspecialchars($m['created_at']); ?></td>
                                    <td><a href="manage-messages.php?delete=<?php echo $m['id']; ?>" class="btn-small btn-delete" onclick="return confirm('Delete message?');">Delete</a></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>