<?php
include '../config/db.php';

$selected_skill = intval($_GET['skill'] ?? 0);

$providers = [];

if ($selected_skill) {
    $stmt = $pdo->prepare("SELECT sp.*, s.name as skill_name FROM service_providers sp JOIN skills s ON sp.skill_id = s.id WHERE sp.is_active = 1 AND sp.skill_id = ? ORDER BY sp.created_at DESC");
    $stmt->execute([$selected_skill]);
    $providers = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// helper to normalize phone numbers for tel: and wa.me links
function normalize_phone($phone) {
    $digits = preg_replace('/\D+/', '', $phone);
    $digits = preg_replace('/^0+/', '', $digits);
    if (!$digits) return '';
    // If local number (short), prepend Cameroon country code
    if (strlen($digits) <= 8) {
        $digits = '237' . $digits;
    }
    return $digits;
}

// Get all skills for filter
$skills_stmt = $pdo->query("SELECT id, name FROM skills ORDER BY name");
$skills = $skills_stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Find Service Providers - Skill Up</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .provider-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 40px 50px;
            min-height: calc(100vh - 200px);
        }

        .filters-section {
            background: var(--white);
            padding: 30px;
            border-radius: 12px;
            margin-bottom: 40px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            animation: slideUp 0.6s ease-out;
        }

        .filter-group {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }

        .filter-input {
            display: flex;
            flex-direction: column;
        }

        .filter-input label {
            color: var(--primary-dark);
            font-weight: 600;
            margin-bottom: 8px;
            font-size: 14px;
        }

        .filter-input input,
        .filter-input select {
            padding: 12px 15px;
            border: 2px solid var(--border);
            border-radius: 8px;
            font-family: 'Poppins', sans-serif;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .filter-input input:focus,
        .filter-input select:focus {
            outline: none;
            border-color: var(--accent-gold);
            box-shadow: 0 0 0 3px rgba(212, 165, 116, 0.1);
        }

        .filter-buttons {
            display: flex;
            gap: 12px;
        }

        .filter-btn {
            flex: 1;
            padding: 12px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            font-family: 'Poppins', sans-serif;
        }

        .filter-btn-search {
            background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary-medium) 100%);
            color: var(--white);
        }

        .filter-btn-search:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(26, 71, 42, 0.3);
        }

        .filter-btn-reset {
            background: var(--bg-light);
            color: var(--primary-dark);
            border: 2px solid var(--primary-dark);
        }

        .filter-btn-reset:hover {
            background: var(--primary-dark);
            color: var(--white);
        }

        .providers-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
            gap: 30px;
            animation: fadeIn 0.8s ease-out;
        }

        .provider-card {
            background: var(--white);
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
            transition: all 0.3s ease;
            border: 2px solid transparent;
        }

        .provider-card:hover {
            border-color: var(--accent-gold);
            transform: translateY(-10px);
            box-shadow: 0 15px 40px rgba(0,0,0,0.15);
        }

        .provider-header {
            background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary-medium) 100%);
            color: var(--white);
            padding: 20px;
            text-align: center;
        }

        .provider-image {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: var(--accent-gold);
            margin: 0 auto 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 36px;
            border: 3px solid var(--white);
        }

        .provider-header h3 {
            font-size: 20px;
            margin: 0;
        }

        .provider-skill {
            background: rgba(255,255,255,0.2);
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 12px;
            display: inline-block;
            margin-top: 8px;
        }

        .provider-body {
            padding: 25px;
        }

        .provider-info {
            display: flex;
            flex-direction: column;
            gap: 12px;
            margin-bottom: 15px;
        }

        .info-item {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 14px;
            color: var(--text-light);
        }

        .info-item strong {
            color: var(--text-dark);
        }

        .rating {
            color: var(--accent-gold);
            font-weight: 600;
        }

        .provider-bio {
            color: var(--text-light);
            font-size: 13px;
            line-height: 1.6;
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--border);
        }

        .contact-btn {
            width: 100%;
            padding: 12px;
            background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary-medium) 100%);
            color: var(--white);
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            font-family: 'Poppins', sans-serif;
        }

        .contact-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(26, 71, 42, 0.3);
        }

        .no-results {
            text-align: center;
            padding: 60px 30px;
            color: var(--text-light);
        }

        .no-results h3 {
            color: var(--primary-dark);
            font-size: 24px;
            margin-bottom: 10px;
        }

        @media (max-width: 768px) {
            .provider-container {
                padding: 20px;
            }

            .filter-group {
                grid-template-columns: 1fr;
            }

            .providers-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <!-- HEADER -->
    <header>
        <nav class="navbar">
            <a href="../index.html" class="logo">
                <span class="logo-icon">⚙️</span>
                <span>SKILL UP</span>
            </a>
            <ul class="nav-links">
                <li><a href="../index.html">Home</a></li>
                <li><a href="#skills">Skills</a></li>
                <li><a href="providers.php">Find Provider</a></li>
                <li><a href="about.html">About</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="../admin/login.php" class="nav-btn">Admin</a></li>
            </ul>
            <div class="hamburger">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </nav>
    </header>

    <!-- PROVIDERS SECTION -->
    <div class="provider-container">
        <div class="section-header" style="margin-bottom: 40px;">
            <h2>Find Service Providers</h2>
            <p>Browse our network of skilled professionals ready to help</p>
        </div>

        <!-- FILTERS -->
        <div class="filters-section">
            <form method="GET" action="" id="skill-search-form">
                <div class="filter-group">
                    <div class="filter-input" style="grid-column: 1 / -1;">
                        <label>Search By Skill</label>
                        <select name="skill" id="skill-select" required>
                            <option value="">Select a skill</option>
                            <?php foreach ($skills as $skill): ?>
                                <option value="<?php echo $skill['id']; ?>" <?php echo $selected_skill == $skill['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($skill['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="filter-buttons">
                    <button type="submit" class="filter-btn filter-btn-search">Find Providers</button>
                    <a href="providers.php" class="filter-btn filter-btn-reset">Clear</a>
                </div>
            </form>
            <script>
                document.getElementById('skill-select').addEventListener('change', function() {
                    if (this.value) document.getElementById('skill-search-form').submit();
                });
            </script>
        </div>

        <!-- PROVIDERS GRID -->
        <?php if (!$selected_skill): ?>
            <div class="no-results">
                <h3>Please select a skill to view providers</h3>
                <p>Choose a skill from the dropdown above to see available professionals</p>
            </div>
        <?php elseif (empty($providers)): ?>
            <div class="no-results">
                <h3>No Service Providers Found for this skill</h3>
                <p>Try another skill or check back later</p>
            </div>
        <?php else: ?>
            <div class="providers-grid">
                <?php foreach ($providers as $provider): ?>
                    <div class="provider-card">
                        <div class="provider-header">
                            <div class="provider-image">
                                <?php
                                $skill_icons = [
                                    'Carpentry' => '🔨',
                                    'Cleaning' => '🧹',
                                    'Electricity' => '⚡',
                                    'Plumbing' => '🔧',
                                    'Tiles & Craft' => '🎨',
                                    'Hair Dressing' => '✂️'
                                ];
                                echo $skill_icons[$provider['skill_name']] ?? '👤';
                                ?>
                            </div>
                            <h3><?php echo htmlspecialchars($provider['name']); ?></h3>
                            <div class="provider-skill"><?php echo htmlspecialchars($provider['skill_name']); ?></div>
                        </div>
                        <?php
                            $phone_raw = $provider['phone'] ?? '';
                            $phone_digits = normalize_phone($phone_raw);
                            $tel_link = $phone_digits ? 'tel:+' . $phone_digits : '';
                            $wa_link = $phone_digits ? 'https://wa.me/' . $phone_digits : '';
                        ?>
                        <div class="provider-body">
                            <div class="provider-info">
                                <div class="info-item">
                                    <strong>Rating:</strong>
                                    <span class="rating">★ <?php echo number_format($provider['rating'], 1); ?>/5.0 (<?php echo $provider['reviews_count']; ?> reviews)</span>
                                </div>
                                <div class="info-item">
                                    <strong>Location:</strong>
                                    <span><?php echo htmlspecialchars($provider['location'] ?? 'Bamenda, Cameroon'); ?></span>
                                </div>
                            </div>
                            <div class="provider-bio">
                                <?php echo htmlspecialchars($provider['bio'] ?? 'Professional service provider'); ?>
                            </div>

                            <div style="display:flex; gap:10px; margin-top:15px; flex-wrap:wrap;">
                                <?php if ($phone_digits): ?>
                                    <a href="<?php echo $wa_link; ?>" target="_blank" rel="noopener" class="contact-btn">WhatsApp</a>
                                    <a href="<?php echo $tel_link; ?>" class="contact-btn">Call</a>
                                <?php endif; ?>

                                <?php if (!empty($provider['email'])): ?>
                                    <a href="mailto:<?php echo htmlspecialchars($provider['email']); ?>" class="contact-btn">Email</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- FOOTER -->
    <footer>
        <div class="footer-content">
            <div class="footer-section">
                <h4>Skill Up</h4>
                <p style="color: rgba(255,255,255,0.8); font-size: 14px; line-height: 1.8;">Your trusted marketplace for professional skills in Bamenda.</p>
            </div>
            <div class="footer-section">
                <h4>Quick Links</h4>
                <ul>
                    <li><a href="../index.html">Home</a></li>
                    <li><a href="providers.php">Find Provider</a></li>
                    <li><a href="about.html">About Us</a></li>
                    <li><a href="contact.php">Contact</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h4>Contact Info</h4>
                <div class="footer-contact">
                    <p><strong>Phone:</strong> +237 673 646 451</p>
                    <p><strong>Email:</strong> Ngyakugareth44@gmail.com</p>
                    <p><strong>Location:</strong> Bamenda, Cameroon</p>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2026 Skill Up. All rights reserved.</p>
        </div>
    </footer>

    <script src="../js/main.js"></script>
</body>
</html>
