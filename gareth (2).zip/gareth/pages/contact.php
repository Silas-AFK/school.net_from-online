<?php
include '../config/db.php';

$success = false;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $subject = $_POST['subject'] ?? '';
    $message = $_POST['message'] ?? '';

    if (!$name || !$email || !$subject || !$message) {
        $error = 'Please fill in all required fields.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO contacts (name, email, phone, subject, message) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$name, $email, $phone, $subject, $message]);
            $success = true;
        } catch (Exception $e) {
            $error = 'Error sending message. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - Skill Up</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .contact-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 60px 50px;
        }

        .contact-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 50px;
            align-items: start;
        }

        .contact-info h3 {
            color: var(--primary-dark);
            font-size: 24px;
            margin-bottom: 30px;
            font-weight: 700;
        }

        .contact-item {
            display: flex;
            gap: 20px;
            margin-bottom: 30px;
            animation: slideUp 0.6s ease-out both;
        }

        .contact-item:nth-child(2) {
            animation-delay: 0.1s;
        }

        .contact-item:nth-child(3) {
            animation-delay: 0.2s;
        }

        .contact-item:nth-child(4) {
            animation-delay: 0.3s;
        }

        .contact-icon {
            font-size: 32px;
            min-width: 50px;
            height: 50px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: var(--accent-light);
            border-radius: 10px;
            color: var(--primary-dark);
        }

        .contact-details h4 {
            color: var(--primary-dark);
            margin-bottom: 5px;
            font-weight: 600;
        }

        .contact-details p {
            color: var(--text-light);
            font-size: 14px;
        }

        .contact-form {
            background: var(--white);
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.08);
            animation: slideUp 0.6s ease-out 0.2s both;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            color: var(--primary-dark);
            font-weight: 600;
            margin-bottom: 8px;
            font-size: 14px;
        }

        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid var(--border);
            border-radius: 8px;
            font-family: 'Poppins', sans-serif;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .form-group input:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: var(--accent-gold);
            box-shadow: 0 0 0 3px rgba(212, 165, 116, 0.1);
        }

        .form-group textarea {
            resize: vertical;
            min-height: 120px;
        }

        .submit-btn {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, var(--primary-dark) 0%, var(--primary-medium) 100%);
            color: var(--white);
            border: none;
            border-radius: 8px;
            font-weight: 600;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-family: 'Poppins', sans-serif;
        }

        .submit-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(26, 71, 42, 0.3);
        }

        .success-message {
            background: #e8f5e9;
            border-left: 4px solid #2e7d32;
            color: #2e7d32;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            animation: slideUp 0.3s ease-out;
        }

        .error-message {
            background: #ffebee;
            border-left: 4px solid #d32f2f;
            color: #d32f2f;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            animation: shake 0.3s ease;
        }

        @keyframes shake {
            0%,
            100% {
                transform: translateX(0);
            }
            25% {
                transform: translateX(-10px);
            }
            75% {
                transform: translateX(10px);
            }
        }

        @media (max-width: 768px) {
            .contact-container {
                padding: 40px 20px;
            }

            .contact-grid {
                grid-template-columns: 1fr;
                gap: 30px;
            }

            .contact-form {
                padding: 30px 20px;
            }
        }
    </style>
</head>
<body>
    <!-- HEADER -->
    <header>
        <nav class="navbar">
            <a href="../index.html" class="logo">
                <span class="logo-icon">⚙️</span>
                <span>SKILL UP</span>
            </a>
            <ul class="nav-links">
                <li><a href="../index.html">Home</a></li>
                <li><a href="../index.html#skills">Skills</a></li>
                <li><a href="providers.php">Find Provider</a></li>
                <li><a href="about.html">About</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="../admin/login.php" class="nav-btn">Admin</a></li>
            </ul>
            <div class="hamburger">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </nav>
    </header>

    <!-- CONTACT SECTION -->
    <div class="contact-container">
        <div class="section-header" style="margin-bottom: 60px;">
            <h2>Get In Touch</h2>
            <p>We'd love to hear from you. Send us a message and we'll respond as soon as possible.</p>
        </div>

        <div class="contact-grid">
            <!-- CONTACT INFO -->
            <div class="contact-info">
                <h3>Contact Information</h3>

                <div class="contact-item">
                    <div class="contact-icon">📍</div>
                    <div class="contact-details">
                        <h4>Location</h4>
                        <p>Bamenda, Cameroon</p>
                    </div>
                </div>

                <div class="contact-item">
                    <div class="contact-icon">📞</div>
                    <div class="contact-details">
                        <h4>Phone</h4>
                        <p>+237 673 646 451</p>
                    </div>
                </div>

                <div class="contact-item">
                    <div class="contact-icon">📧</div>
                    <div class="contact-details">
                        <h4>Email</h4>
                        <p>Ngyakugareth44@gmail.com</p>
                    </div>
                </div>

                <div class="contact-item">
                    <div class="contact-icon">⏰</div>
                    <div class="contact-details">
                        <h4>Hours</h4>
                        <p>Mon - Fri: 8:00 AM - 6:00 PM<br>Sat: 9:00 AM - 4:00 PM<br>Sun: Closed</p>
                    </div>
                </div>
            </div>

            <!-- CONTACT FORM -->
            <form method="POST" action="" class="contact-form">
                <?php if ($success): ?>
                    <div class="success-message">
                        Thank you for your message! We will get back to you soon.
                    </div>
                <?php endif; ?>

                <?php if ($error): ?>
                    <div class="error-message">
                        <?php echo htmlspecialchars($error); ?>
                    </div>
                <?php endif; ?>

                <div class="form-group">
                    <label for="name">Full Name *</label>
                    <input type="text" id="name" name="name" required>
                </div>

                <div class="form-group">
                    <label for="email">Email *</label>
                    <input type="email" id="email" name="email" required>
                </div>

                <div class="form-group">
                    <label for="phone">Phone (Optional)</label>
                    <input type="tel" id="phone" name="phone">
                </div>

                <div class="form-group">
                    <label for="subject">Subject *</label>
                    <input type="text" id="subject" name="subject" required>
                </div>

                <div class="form-group">
                    <label for="message">Message *</label>
                    <textarea id="message" name="message" required></textarea>
                </div>

                <button type="submit" class="submit-btn">Send Message</button>
            </form>
        </div>
    </div>

    <!-- FOOTER -->
    <footer>
        <div class="footer-content">
            <div class="footer-section">
                <h4>Skill Up</h4>
                <p style="color: rgba(255,255,255,0.8); font-size: 14px; line-height: 1.8;">Your trusted marketplace for professional skills in Bamenda.</p>
            </div>
            <div class="footer-section">
                <h4>Quick Links</h4>
                <ul>
                    <li><a href="../index.html">Home</a></li>
                    <li><a href="providers.php">Find Provider</a></li>
                    <li><a href="about.html">About Us</a></li>
                    <li><a href="contact.php">Contact</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h4>Contact Info</h4>
                <div class="footer-contact">
                    <p><strong>Phone:</strong> +237 673 646 451</p>
                    <p><strong>Email:</strong> Ngyakugareth44@gmail.com</p>
                    <p><strong>Location:</strong> Bamenda, Cameroon</p>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2026 Skill Up. All rights reserved.</p>
        </div>
    </footer>

    <script src="../js/main.js"></script>
</body>
</html>
