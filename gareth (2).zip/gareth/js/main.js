// Mobile menu toggle
const hamburger = document.querySelector(".hamburger")
const navLinks = document.querySelector(".nav-links")

if (hamburger) {
  hamburger.addEventListener("click", () => {
    hamburger.classList.toggle("active")
    navLinks.classList.toggle("active")
  })

  // Close menu when a link is clicked
  document.querySelectorAll(".nav-links a").forEach((link) => {
    link.addEventListener("click", () => {
      hamburger.classList.remove("active")
      navLinks.classList.remove("active")
    })
  })
}

// Scroll animations
const observerOptions = {
  threshold: 0.1,
  rootMargin: "0px 0px -100px 0px",
}

const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.style.opacity = "1"
      entry.target.style.transform = "translateY(0)"
    }
  })
}, observerOptions)

// Observe skill cards and feature items
document.querySelectorAll(".skill-card, .feature-item, .provider-card").forEach((el) => {
  el.style.opacity = "0"
  el.style.transform = "translateY(20px)"
  el.style.transition = "opacity 0.6s ease, transform 0.6s ease"
  observer.observe(el)
})

// Smooth scroll for navigation links
document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
  anchor.addEventListener("click", function (e) {
    const href = this.getAttribute("href")
    if (href !== "#" && document.querySelector(href)) {
      e.preventDefault()
      document.querySelector(href).scrollIntoView({
        behavior: "smooth",
      })
    }
  })
})

// Add animation to stat cards on page load
window.addEventListener("load", () => {
  const stats = document.querySelectorAll(".stat-card")
  stats.forEach((stat, index) => {
    setTimeout(() => {
      stat.style.animation = `slideUp 0.6s ease-out forwards`
    }, index * 100)
  })
})

// Counter animation for stats
function animateCounter(element, target, duration = 1000) {
  let current = 0
  const increment = target / (duration / 16)

  const timer = setInterval(() => {
    current += increment
    if (current >= target) {
      element.textContent = target
      clearInterval(timer)
    } else {
      element.textContent = Math.floor(current)
    }
  }, 16)
}

// Animate stat values when they come into view
const statValues = document.querySelectorAll(".stat-value")
const statsObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting && !entry.target.classList.contains("animated")) {
        const value = Number.parseInt(entry.target.textContent)
        animateCounter(entry.target, value)
        entry.target.classList.add("animated")
      }
    })
  },
  { threshold: 0.5 },
)

statValues.forEach((stat) => statsObserver.observe(stat))

// Form validation and submission feedback
const forms = document.querySelectorAll("form")
forms.forEach((form) => {
  form.addEventListener("submit", function (e) {
    const inputs = this.querySelectorAll("input[required], textarea[required]")
    let isValid = true

    inputs.forEach((input) => {
      if (!input.value.trim()) {
        isValid = false
        input.style.borderColor = "#d32f2f"
        input.style.boxShadow = "0 0 0 3px rgba(211, 47, 47, 0.1)"
      } else {
        input.style.borderColor = ""
        input.style.boxShadow = ""
      }
    })

    if (!isValid) {
      e.preventDefault()
    }
  })

  // Clear error styles on input
  form.querySelectorAll("input, textarea").forEach((input) => {
    input.addEventListener("focus", function () {
      this.style.borderColor = ""
      this.style.boxShadow = ""
    })
  })
})

// Parallax effect on hero section
window.addEventListener("scroll", () => {
  const hero = document.querySelector(".hero")
  if (hero) {
    const scrolled = window.pageYOffset
    hero.style.backgroundPosition = `0 ${scrolled * 0.5}px`
  }
})

// Add active state to navigation links based on scroll position
window.addEventListener("scroll", () => {
  const sections = document.querySelectorAll("section[id]")
  const navLinks = document.querySelectorAll('.nav-links a[href^="#"]')

  let current = ""
  sections.forEach((section) => {
    const sectionTop = section.offsetTop
    const sectionHeight = section.clientHeight
    if (pageYOffset >= sectionTop - 200) {
      current = section.getAttribute("id")
    }
  })

  navLinks.forEach((link) => {
    link.classList.remove("active")
    if (link.getAttribute("href").slice(1) === current) {
      link.classList.add("active")
    }
  })
})

// Stagger animation for grid items
function staggerAnimation(selector, delayIncrement = 100) {
  const items = document.querySelectorAll(selector)
  items.forEach((item, index) => {
    item.style.animationDelay = `${index * delayIncrement}ms`
  })
}

staggerAnimation(".skill-card")
staggerAnimation(".feature-item")
staggerAnimation(".provider-card")
