<?php
$src = __DIR__ . '/../greem.jfif';
$dstDir = __DIR__ . '/../assets';
$dst = $dstDir . '/hero-bg.jpg';

if (!file_exists($src)) {
    echo "Source file not found: $src\n";
    exit(1);
}
if (!is_dir($dstDir)) {
    mkdir($dstDir, 0755, true);
}

$info = getimagesize($src);
if ($info === false) {
    echo "Unrecognized image format.\n";
    exit(1);
}

$width = $info[0];
$height = $info[1];

// Load image (JFIF is JPEG)
$img = @imagecreatefromjpeg($src);
if (!$img) {
    echo "Failed to load image with GD.\n";
    exit(1);
}

$maxW = 1920;
$maxH = 1080;
$ratio = min($maxW / $width, $maxH / $height, 1);
$newW = (int)($width * $ratio);
$newH = (int)($height * $ratio);

$dstImg = imagecreatetruecolor($newW, $newH);
imagecopyresampled($dstImg, $img, 0, 0, 0, 0, $newW, $newH, $width, $height);

// Save as JPEG with quality 85
if (imagejpeg($dstImg, $dst, 85)) {
    echo "Converted and saved to: $dst\n";
    imagedestroy($img);
    imagedestroy($dstImg);
    exit(0);
} else {
    echo "Failed to save optimized image.\n";
    imagedestroy($img);
    imagedestroy($dstImg);
    exit(1);
}
