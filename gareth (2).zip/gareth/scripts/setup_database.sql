-- Create database and tables for Skill Up
CREATE DATABASE IF NOT EXISTS skillup_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE skillup_db;

-- Create database tables for Skill Up
CREATE TABLE IF NOT EXISTS skills (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(100) NOT NULL UNIQUE,
  description TEXT NOT NULL,
  icon_class VARCHAR(50),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS service_providers (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  phone VARCHAR(20) NOT NULL,
  skill_id INT NOT NULL,
  bio TEXT,
  rating DECIMAL(3, 2) DEFAULT 0,
  reviews_count INT DEFAULT 0,
  image_url VARCHAR(255),
  location VARCHAR(100),
  is_active BOOLEAN DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (skill_id) REFERENCES skills(id)
);

CREATE TABLE IF NOT EXISTS contacts (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL,
  phone VARCHAR(20),
  subject VARCHAR(200),
  message TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS admin_logs (
  id INT PRIMARY KEY AUTO_INCREMENT,
  action VARCHAR(100),
  details TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert sample skills
INSERT INTO skills (name, description, icon_class) VALUES
('Carpentry', 'Professional carpentry and woodworking services', 'hammer'),
('Cleaning', 'Expert cleaning and sanitation services', 'broom'),
('Electricity', 'Electrical installation and repair services', 'bolt'),
('Plumbing', 'Professional plumbing and water system services', 'wrench'),
('Tiles & Craft', 'Tile laying and decorative craft work', 'cube'),
('Hair Dressing', 'Professional hair styling and grooming', 'scissors');
