<?php
include 'config.php';
session_start();

// Fetch all products from database
$products_result = $conn->query("SELECT * FROM products ORDER BY created_at DESC");
$products = [];
if ($products_result) {
    while ($row = $products_result->fetch_assoc()) {
        $products[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Princewill - Electronic shop</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        /* Basic navbar styling */
        .navbar {
            background: #333;
            color: #fff;
            padding: 0.5rem 1rem;
        }
        .navbar .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .nav-brand {
            font-weight: bold;
        }
        .nav-links {
            list-style: none;
            display: flex;
            gap: 1rem;
        }
        .nav-links li a {
            color: #fff;
            text-decoration: none;
        }
        .cart-icon {
            cursor: pointer;
            font-size: 1.2rem;
        }

        /* Hamburger button */
        .hamburger {
            display: none;
            flex-direction: column;
            cursor: pointer;
        }
        .hamburger span {
            height: 3px;
            width: 25px;
            background: #fff;
            margin: 4px 0;
            transition: 0.4s;
        }

        /* Responsive styles */
        @media (max-width: 768px) {
            .nav-links {
                position: absolute;
                top: 60px;
                right: 0;
                background: #333;
                flex-direction: column;
                width: 200px;
                display: none;
                padding: 1rem;
            }
            .nav-links.active {
                display: flex;
            }
            .hamburger {
                display: flex;
            }
        }
        .see-all-container {
    text-align: center;
    margin-top: 30px;
}

.see-all-btn {
    display: inline-block;
    padding: 12px 25px;
    background: #111827;
    color: #fff;
    text-decoration: none;
    border-radius: 8px;
    transition: 0.3s;
    font-weight: bold;
}

.see-all-btn:hover {
    background: #2563eb;
    transform: translateY(-3px);
}
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="container">
            <div class="nav-brand">
                <div class="logo-placeholder">Princewill - Electronic shop</div>
                <span class="shop-location"><?php echo SHOP_LOCATION; ?></span>
            </div>
            
            <!-- Hamburger Menu -->
            <div class="hamburger" onclick="toggleMenu()">
                <span></span>
                <span></span>
                <span></span>
            </div>

            <ul class="nav-links" id="navLinks">
                <li><a href="#home">Home</a></li>
                <li><a href="#products">Products</a></li>
                <li><a href="#about">About</a></li>
                <li><a href="products.php">Shop</a></li>
                <li><a href="contact.html">Contact</a></li>
                <li><a href="admin/login.php" class="admin-link">Admin</a></li>
            </ul>
            
            <div class="cart-icon" onclick="openCart()">
                <span class="cart-count" id="cartCount">0</span>
                🛒
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section id="home" class="hero">
        <div class="hero-content">
            <h1 class="hero-title">Welcome to Princewill - Electronic shop</h1>
            <p class="hero-subtitle">Shop Quality Products at Best Prices</p>
            <a href="#products" class="btn btn-primary">Shop Now</a>
        </div>
    </section>

    <!-- Products Section -->
    <section id="products" class="products">
        <div class="container">
            <h2 class="section-title">Our Products</h2>
            <div class="products-grid">
                <?php if (count($products) > 0): ?>
                    <?php foreach ($products as $product): ?>
                        <div class="product-card">
                            <div class="product-image">
                                <?php if (!empty($product['image']) && file_exists('uploads/' . $product['image'])): ?>
                                    <img src="uploads/<?php echo htmlspecialchars($product['image']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                                <?php else: ?>
                                    <div class="image-placeholder">📦</div>
                                <?php endif; ?>
                            </div>
                            <div class="product-info">
                                <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                                <p><?php echo substr(htmlspecialchars($product['description']), 0, 50) . '...'; ?></p>
                                <div class="product-footer">
                                    <span class="price"><?php echo number_format($product['price']); ?> <?php echo CURRENCY; ?></span>
                                    <button class="btn btn-small" onclick="addToCart(<?php echo $product['id']; ?>, '<?php echo htmlspecialchars($product['name']); ?>', <?php echo $product['price']; ?>)">Add to Cart</button>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p class="no-products">No products available. Please check back soon!</p>
                <?php endif; ?>
            </div>
        </div>
        <div class="products-grid">
            <div class="see-all-container">
    <a href="products.php" class="see-all-btn">See All Products →</a>
</div>
             </div>
    </section>

    <!-- About Section -->
    <section id="about" class="about">
        <div class="container">
            <h2 class="section-title">About Princewill - Electronic shop</h2>
            <p>Welcome to Princewill - Electronic shop, your trusted online shopping destination. We offer quality products at competitive prices with excellent customer service.</p>
        </div>
    </section>

    <!-- Contact Section -->
    <section id="contact" class="contact">
        <div class="container">
             <h2 class="section-title">🐸</h2>
            <h2 class="section-title">Contact Us</h2>
            <div class="contact-info">
                <div class="contact-item">
                    <span class="contact-icon">📞</span>
                    <div>
                        <h3>Phone</h3>
                        <p><?php echo SHOP_PHONE; ?></p>
                    </div>
                </div>
                <div class="contact-item">
                    <span class="contact-icon">📧</span>
                    <div>
                        <h3>Email</h3>
                        <p><?php echo SHOP_EMAIL; ?></p>
                    </div>
                </div>
                <div class="contact-item">
                    <span class="contact-icon">📍</span>
                    <div>
                        <h3>Location</h3>
                        <p><?php echo SHOP_LOCATION; ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <p>&copy; 2025 Princewill - Electronic shop. All rights reserved. | <?php echo SHOP_LOCATION; ?></p>
        </div>
    </footer>

    <!-- Cart Modal -->
    <div id="cartModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeCart()">&times;</span>
            <h2>Shopping Cart</h2>
            <div id="cartItems"></div>
            <div class="cart-summary">
                <h3>Total: <span id="cartTotal">0</span> <?php echo CURRENCY; ?></h3>
                <button class="btn btn-primary" onclick="goToCheckout()">Proceed to Checkout</button>
            </div>
        </div>
    </div>

    <script src="js/script.js"></script>
    <script src="js/cart.js"></script>
    <script>
        function toggleMenu() {
            document.getElementById('navLinks').classList.toggle('active');
        }
    </script>
</body>
</html>
