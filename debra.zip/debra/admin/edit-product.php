<?php
include '../config.php';
session_start();

if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit;
}

$product_id = intval($_GET['id'] ?? 0);
$product = $conn->query("SELECT * FROM products WHERE id = $product_id")->fetch_assoc();

if (!$product) {
    die("Product not found");
}

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = htmlspecialchars($_POST['name'] ?? '');
    $description = htmlspecialchars($_POST['description'] ?? '');
    $price = floatval($_POST['price'] ?? 0);
    $quantity = intval($_POST['quantity'] ?? 0);
    $image = $product['image'];

    // Handle new image upload
    if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
        $allowed = ['jpg', 'jpeg', 'png', 'gif'];
        $filename = $_FILES['image']['name'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

        if (in_array($ext, $allowed)) {
            $new_filename = time() . '_' . uniqid() . '.' . $ext;
            $upload_path = '../uploads/' . $new_filename;

            if (move_uploaded_file($_FILES['image']['tmp_name'], $upload_path)) {
                if (!empty($product['image']) && file_exists('../uploads/' . $product['image'])) {
                    unlink('../uploads/' . $product['image']);
                }
                $image = $new_filename;
            }
        }
    }

    if ($name && $price > 0) {
        $stmt = $conn->prepare("UPDATE products SET name = ?, description = ?, price = ?, quantity = ?, image = ? WHERE id = ?");
        $stmt->bind_param("ssdisi", $name, $description, $price, $quantity, $image, $product_id);

        if ($stmt->execute()) {
            $success = "Product updated successfully!";
            $product = $conn->query("SELECT * FROM products WHERE id = $product_id")->fetch_assoc();
        } else {
            $error = "Error updating product: " . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product - Princewill - Electronic shop Admin</title>
    <link rel="stylesheet" href="../css/admin.css">
</head>
<body class="admin-body">
    <nav class="admin-navbar">
        <div class="admin-nav-brand">Princewill - Electronic shop Admin</div>
        <a href="logout.php" class="btn btn-danger">Logout</a>
    </nav>

    <div class="admin-container">
        <div class="admin-sidebar">
            <a href="dashboard.php" class="nav-link">Dashboard</a>
            <a href="add-product.php" class="nav-link">Add Product</a>
            <a href="dashboard.php#products" class="nav-link active">Manage Products</a>
        </div>

        <div class="admin-content">
            <h1>Edit Product</h1>

            <?php if ($success): ?>
                <div class="success-message"><?php echo $success; ?></div>
            <?php endif; ?>

            <?php if ($error): ?>
                <div class="error-message"><?php echo $error; ?></div>
            <?php endif; ?>

            <form method="POST" enctype="multipart/form-data" class="product-form">
                <div class="form-group">
                    <label for="name">Product Name</label>
                    <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($product['name']); ?>" required>
                </div>

                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea id="description" name="description"><?php echo htmlspecialchars($product['description']); ?></textarea>
                </div>

                <div class="form-group">
                    <label for="price">Price (<?php echo CURRENCY; ?>)</label>
                    <input type="number" id="price" name="price" value="<?php echo $product['price']; ?>" min="0" step="0.01" required>
                </div>

                <div class="form-group">
                    <label for="quantity">Quantity</label>
                    <input type="number" id="quantity" name="quantity" value="<?php echo $product['quantity']; ?>" min="0">
                </div>

                <div class="form-group">
                    <label for="image">Product Image</label>
                    <?php if (!empty($product['image']) && file_exists('../uploads/' . $product['image'])): ?>
                        <div class="current-image">
                            <img src="../uploads/<?php echo htmlspecialchars($product['image']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                            <p>Current image</p>
                        </div>
                    <?php endif; ?>
                    <input type="file" id="image" name="image" accept="image/*">
                </div>

                <button type="submit" class="btn btn-primary">Update Product</button>
                <a href="dashboard.php" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
    </div>
</body>
</html>