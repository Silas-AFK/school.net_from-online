<?php
include '../config.php';
session_start();

// Ensure only logged-in admins can delete
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit;
}

// Get product ID from query string
$id = intval($_GET['id'] ?? 0);

if ($id > 0) {
    // First, fetch product to check if it exists and get image filename
    $stmt = $conn->prepare("SELECT image FROM products WHERE id = ?");
    if ($stmt) {
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result && $result->num_rows > 0) {
            $product = $result->fetch_assoc();
            $image = $product['image'] ?? '';

            // Delete product record
            $deleteStmt = $conn->prepare("DELETE FROM products WHERE id = ?");
            if ($deleteStmt) {
                $deleteStmt->bind_param("i", $id);
                if ($deleteStmt->execute()) {
                    // Remove image file if it exists
                    if ($image && file_exists("../uploads/" . $image)) {
                        unlink("../uploads/" . $image);
                    }
                    $_SESSION['message'] = "Product deleted successfully!";
                } else {
                    $_SESSION['message'] = "Error deleting product: " . $deleteStmt->error;
                }
                $deleteStmt->close();
            }
        } else {
            $_SESSION['message'] = "Product not found.";
        }
        $stmt->close();
    } else {
        $_SESSION['message'] = "SQL prepare failed: " . $conn->error;
    }
} else {
    $_SESSION['message'] = "Invalid product ID.";
}

// Redirect back to dashboard
header("Location: dashboard.php#products");
exit;
?>
