<?php
include '../config.php';
session_start();

if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit;
}

// Helper function to safely run queries
function safeQuery($conn, $sql) {
    $result = $conn->query($sql);
    if ($result === false) {
        error_log("SQL Error: " . $conn->error);
        return false;
    }
    return $result;
}

// Get statistics
$products_count = 0;
$orders_count = 0;
$total_revenue = 0;

if ($res = safeQuery($conn, "SELECT COUNT(*) as count FROM products")) {
    $products_count = $res->fetch_assoc()['count'];
}
if ($res = safeQuery($conn, "SELECT COUNT(*) as count FROM orders")) {
    $orders_count = $res->fetch_assoc()['count'];
}
if ($res = safeQuery($conn, "SELECT SUM(total_amount) as total FROM orders")) {
    $row = $res->fetch_assoc();
    $total_revenue = $row['total'] ?? 0;
}

// Get recent products
$products = safeQuery($conn, "SELECT id, name, price, quantity, created_at FROM products ORDER BY created_at DESC LIMIT 10");

// Get recent orders
$orders = safeQuery($conn, "SELECT * FROM orders ORDER BY created_at DESC LIMIT 10");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard - Princewill - Electronic shop</title>
  <link rel="stylesheet" href="../css/admin.css">
  <style>
    /* Navbar */
    .admin-navbar {
      background: #333;
      color: #fff;
      padding: 0.5rem 1rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .admin-nav-brand {
      font-weight: bold;
    }
    .hamburger {
      display: none;
      flex-direction: column;
      cursor: pointer;
    }
    .hamburger span {
      height: 3px;
      width: 25px;
      background: #fff;
      margin: 4px 0;
      transition: 0.4s;
    }

    /* Sidebar */
    .admin-sidebar {
      background: #f4f4f4;
      width: 220px;
      min-height: 100vh;
      padding: 1rem;
    }
    .admin-sidebar .nav-link {
      display: block;
      padding: 0.5rem;
      color: #333;
      text-decoration: none;
    }
    .admin-sidebar .nav-link.active {
      background: #ddd;
      font-weight: bold;
    }

    /* Responsive */
    @media (max-width: 768px) {
      .admin-container {
        display: flex;
        flex-direction: column;
      }
      .admin-sidebar {
        position: absolute;
        top: 60px;
        left: -240px;
        width: 200px;
        transition: left 0.3s ease;
        z-index: 1000;
      }
      .admin-sidebar.active {
        left: 0;
      }
      .hamburger {
        display: flex;
      }
    }
  </style>
</head>
<body class="admin-body">
  <nav class="admin-navbar">
    <div class="admin-nav-brand">Princewill - Electronic shop Admin</div>
    <div class="hamburger" onclick="toggleSidebar()">
      <span></span>
      <span></span>
      <span></span>
    </div>
    <a href="logout.php" class="btn btn-danger">Logout</a>
  </nav>

  <div class="admin-container">
    <div class="admin-sidebar" id="sidebar">
      <a href="dashboard.php" class="nav-link active">Dashboard</a>
      <a href="add-product.php" class="nav-link">Add Product</a>
      <a href="#products" class="nav-link">Manage Products</a>
      <a href="#orders" class="nav-link">View Orders</a>
    </div>

    <div class="admin-content">
      <h1>Dashboard</h1>

      <!-- Statistics -->
      <div class="stats-grid">
        <div class="stat-card">
          <h3>Total Products</h3>
          <p class="stat-number"><?php echo $products_count; ?></p>
        </div>
        <div class="stat-card">
          <h3>Total Orders</h3>
          <p class="stat-number"><?php echo $orders_count; ?></p>
        </div>
        <div class="stat-card">
          <h3>Total Revenue</h3>
          <p class="stat-number"><?php echo number_format($total_revenue); ?> <?php echo CURRENCY; ?></p>
        </div>
      </div>

      <!-- Products Section -->
      <section id="products" class="admin-section">
        <h2>Recent Products</h2>
        <a href="add-product.php" class="btn btn-primary">Add New Product</a>
        
        <table class="admin-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Price</th>
              <th>Quantity</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php if ($products && $products->num_rows > 0): ?>
              <?php while ($product = $products->fetch_assoc()): ?>
                <tr>
                  <td><?php echo $product['id']; ?></td>
                  <td><?php echo htmlspecialchars($product['name']); ?></td>
                  <td><?php echo number_format($product['price']); ?> <?php echo CURRENCY; ?></td>
                  <td><?php echo isset($product['quantity']) ? $product['quantity'] : 'N/A'; ?></td>
                  <td>
                    <a href="edit-product.php?id=<?php echo $product['id']; ?>" class="btn btn-small btn-info">Edit</a>
                    <a href="delete-product.php?id=<?php echo $product['id']; ?>" class="btn btn-small btn-danger" onclick="return confirm('Are you sure?')">Delete</a>
                  </td>
                </tr>
              <?php endwhile; ?>
            <?php else: ?>
              <tr><td colspan="5">No products found.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </section>

      <!-- Orders Section -->
      <section id="orders" class="admin-section">
        <h2>Recent Orders</h2>
        <table class="admin-table">
          <thead>
            <tr>
              <th>Order ID</th>
              <th>Customer</th>
              <th>Amount</th>
              <th>Status</th>
              <th>Date</th>
            </tr>
          </thead>
          <tbody>
            <?php if ($orders && $orders->num_rows > 0): ?>
              <?php while ($order = $orders->fetch_assoc()): ?>
                <tr>
                  <td>#<?php echo $order['id']; ?></td>
                  <td><?php echo htmlspecialchars($order['customer_name']); ?></td>
                  <td><?php echo number_format($order['total_amount']); ?> <?php echo CURRENCY; ?></td>
                  <td><span class="status"><?php echo $order['status']; ?></span></td>
                  <td><?php echo date('d/m/Y', strtotime($order['created_at'])); ?></td>
                </tr>
              <?php endwhile; ?>
            <?php else: ?>
              <tr><td colspan="5">No orders found.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </section>
    </div>
  </div>

  <script>
    function toggleSidebar() {
      document.getElementById('sidebar').classList.toggle('active');
    }
  </script>
</body>
</html>
