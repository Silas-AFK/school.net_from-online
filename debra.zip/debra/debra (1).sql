-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 23, 2026 at 10:39 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `debra`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`) VALUES
(1, 'Fruits'),
(2, 'Vegetables'),
(3, 'Dairy'),
(4, 'Bakery');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `customer_email` varchar(255) NOT NULL,
  `customer_phone` varchar(20) NOT NULL,
  `customer_address` text DEFAULT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `items_json` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`items_json`)),
  `status` varchar(50) DEFAULT 'pending',
  `whatsapp_sent` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `customer_name`, `customer_email`, `customer_phone`, `customer_address`, `total_amount`, `items_json`, `status`, `whatsapp_sent`, `created_at`) VALUES
(1, 'Afanwi Silas Shu', 'silasafanwi6@gmail.com', '676763842', 'Bamenda town', 2.00, '[{\"id\":1,\"name\":\"Sample Apples\",\"price\":2.5,\"quantity\":1}]', 'pending', 1, '2025-12-08 13:56:12'),
(2, 'Afanwi Silas Shu', 'silasafanwi6@gmail.com', '676763842', 'Bamenda town', 5000.00, '[{\"id\":5,\"name\":\"SMCC\",\"price\":5000,\"quantity\":1}]', 'pending', 1, '2025-12-08 18:08:12'),
(3, 'Afanwi Silas Shu', 'silasafanwi6@gmail.com', '676763842', 'Bamenda town', 2000.00, '[{\"id\":4,\"name\":\"Afanwi Silas Shu\",\"price\":2000,\"quantity\":1}]', 'pending', 1, '2025-12-16 23:01:50'),
(4, 'Afanwi Silas Shu', 'silasafanwi6@gmail.com', '676763842', 'Bamenda town', 5000.00, '[{\"id\":5,\"name\":\"SMCC\",\"price\":5000,\"quantity\":1}]', 'pending', 1, '2025-12-16 23:03:56'),
(5, 'Afanwi Silas Shu', 'silasafanwi6@gmail.com', '676763842', 'Bamenda town', 260000.00, '[{\"id\":6,\"name\":\"CARS\",\"price\":260000,\"quantity\":1}]', 'pending', 1, '2025-12-16 23:10:29'),
(6, 'blessing', 'bleesing10@gmail.com', '678987954', 'town', 260000.00, '[{\"id\":6,\"name\":\"CARS\",\"price\":260000,\"quantity\":1}]', 'pending', 1, '2026-01-13 08:37:33'),
(7, 'blessing', 'bleesing10@gmail.com', '678734575', 'new bell', 267000.00, '[{\"id\":4,\"name\":\"Afanwi Silas Shu\",\"price\":2000,\"quantity\":1},{\"id\":5,\"name\":\"SMCC\",\"price\":5000,\"quantity\":1},{\"id\":6,\"name\":\"CARS\",\"price\":260000,\"quantity\":1}]', 'pending', 1, '2026-01-13 08:39:20'),
(8, 'blessing', 'bleesing10@gmail.com', '678734575', 'gjjhh', 260000.00, '[{\"id\":6,\"name\":\"CARS\",\"price\":260000,\"quantity\":1}]', 'pending', 1, '2026-01-20 11:25:28'),
(9, 'blessing', 'bleesing10@gmail.com', '678734575', 'Bamenda town', 490000.00, '[{\"id\":7,\"name\":\"ferary\",\"price\":240000,\"quantity\":1},{\"id\":5,\"name\":\"SMCC\",\"price\":5000,\"quantity\":4},{\"id\":8,\"name\":\"electronics\",\"price\":230000,\"quantity\":1}]', 'pending', 1, '2026-01-20 11:34:18'),
(10, 'blessing', 'bleesing10@gmail.com', '678734575', 'Bamenda town', 720000.00, '[{\"id\":7,\"name\":\"ferary\",\"price\":240000,\"quantity\":1},{\"id\":5,\"name\":\"SMCC\",\"price\":5000,\"quantity\":4},{\"id\":8,\"name\":\"electronics\",\"price\":230000,\"quantity\":2}]', 'pending', 1, '2026-01-20 11:38:58'),
(11, 'Afanwi Silas Shu', 'silasafanwi6@gmail.com', '67678877', 'Bamenda town', 240000.00, '[{\"id\":7,\"name\":\"ferary\",\"price\":240000,\"quantity\":1}]', 'pending', 1, '2026-02-23 07:35:34'),
(12, 'Afanwi Silas Shu', 'silasafanwi6@gmail.com', '67678877', 'Bamenda town', 240000.00, '[{\"id\":7,\"name\":\"ferary\",\"price\":240000,\"quantity\":1}]', 'pending', 1, '2026-02-23 07:43:24'),
(13, 'Afanwi Silas Shu', 'silasafanwi6@gmail.com', '676763842', 'Bamenda town', 240000.00, '[{\"id\":7,\"name\":\"ferary\",\"price\":240000,\"quantity\":1}]', 'pending', 1, '2026-02-23 09:03:09');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `description` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `quantity` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category_id`, `name`, `price`, `description`, `image`, `created_at`, `quantity`) VALUES
(4, NULL, 'Afanwi Silas Shu', 2000.00, 'djftggh', '1765206068_6936e8348181f.jpg', '2025-12-08 15:01:08', 4),
(5, NULL, 'SMCC', 5000.00, 'books', '1765217150_6937137e355cd.jpg', '2025-12-08 18:05:50', 40),
(6, NULL, 'CARS', 260000.00, 'High quality', '1765926537_6941e68925baf.jpeg', '2025-12-16 23:08:57', 1),
(7, NULL, 'ferary', 240000.00, 'highly afordable', '1768293867_696605eb6ef50.jpeg', '2026-01-13 08:44:27', 5),
(8, NULL, 'electronics', 230000.00, 'cercuit', '1768478460_6968d6fc1fc56.jpg', '2026-01-15 12:01:00', 8);

-- --------------------------------------------------------

--
-- Table structure for table `silas`
--

CREATE TABLE `silas` (
  `name` varchar(20) DEFAULT NULL,
  `number` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
