<?php
include 'config.php';
session_start();

$products_result = $conn->query("SELECT * FROM products ORDER BY created_at DESC");
$products = [];

if ($products_result) {
    while ($row = $products_result->fetch_assoc()) {
        $products[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>All Products - Princewill Shop</title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>

<!-- NAVBAR (Same Structure As Parent) -->
<nav class="navbar">
    <div class="container">
        <div class="nav-brand">
            <h2>All Products</h2>
        </div>

        <a href="index.php" class="btn btn-small">← Back to Home</a>

        <div class="cart-icon" onclick="openCart()">
            <span class="cart-count" id="cartCount">0</span>
            🛒
        </div>
    </div>
</nav>

<!-- PRODUCTS -->
<section class="products">
    <div class="container">
        <div class="products-grid">

            <?php if(count($products) > 0): ?>
                <?php foreach($products as $product): ?>
                    <div class="product-card">
                        <div class="product-image">
                            <?php if (!empty($product['image']) && file_exists('uploads/' . $product['image'])): ?>
                                <img src="uploads/<?php echo htmlspecialchars($product['image']); ?>">
                            <?php else: ?>
                                <div class="image-placeholder">📦</div>
                            <?php endif; ?>
                        </div>

                        <div class="product-info">
                            <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                            <p><?php echo substr(htmlspecialchars($product['description']),0,70); ?>...</p>

                            <div class="product-footer">
                                <span class="price">
                                    <?php echo number_format($product['price']); ?> <?php echo CURRENCY; ?>
                                </span>

                                <!-- SAME addToCart FUNCTION -->
                                <button class="btn btn-small"
                                    onclick="addToCart(
                                        <?php echo $product['id']; ?>,
                                        '<?php echo htmlspecialchars($product['name']); ?>',
                                        <?php echo $product['price']; ?>
                                    )">
                                    Add to Cart
                                </button>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>No products available.</p>
            <?php endif; ?>

        </div>
    </div>
</section>

<!-- CART MODAL (EXACT SAME STRUCTURE AS INDEX) -->
<div id="cartModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeCart()">&times;</span>
        <h2>Shopping Cart</h2>
        <div id="cartItems"></div>

        <div class="cart-summary">
            <h3>Total: <span id="cartTotal">0</span> <?php echo CURRENCY; ?></h3>
            <button class="btn btn-primary" onclick="goToCheckout()">
                Proceed to Checkout
            </button>
        </div>
    </div>
</div>

<!-- IMPORTANT: Must be at bottom -->
<script src="js/cart.js"></script>
<script src="js/script.js"></script>
</body>
</html>