<?php
include 'config.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $customer_name = htmlspecialchars($_POST['name'] ?? '');
    $customer_email = htmlspecialchars($_POST['email'] ?? '');
    $customer_phone = htmlspecialchars($_POST['phone'] ?? '');
    $customer_address = htmlspecialchars($_POST['address'] ?? '');
    $cart_json = $_POST['cart'] ?? '[]';
    $total_amount = floatval($_POST['total'] ?? 0);

    // Insert order into database
    $stmt = $conn->prepare("INSERT INTO orders (customer_name, customer_email, customer_phone, customer_address, items_json, total_amount) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssi", $customer_name, $customer_email, $customer_phone, $customer_address, $cart_json, $total_amount);

    if ($stmt->execute()) {
        $order_id = $conn->insert_id;

        // Format message for WhatsApp
        $cart_data = json_decode($cart_json, true);
        $items_text = "";
        foreach ($cart_data as $item) {
            $items_text .= "\n• " . $item['name'] . " x" . $item['quantity'] . " = " . number_format($item['price'] * $item['quantity']) . " " . CURRENCY;
        }

        $message = "Order #$order_id from Princewill Electronic Shop\n\n";
        $message .= "Customer: $customer_name\n";
        $message .= "Email: $customer_email\n";
        $message .= "Phone: $customer_phone\n";
        $message .= "Address: $customer_address\n\n";
        $message .= "Items:$items_text\n\n";
        $message .= "Total: " . number_format($total_amount) . " " . CURRENCY;

        // Update order with WhatsApp sent status
        $whatsapp_url = "https://wa.me/" . WHATSAPP_NUMBER . "?text=" . urlencode($message);

        $update_stmt = $conn->prepare("UPDATE orders SET whatsapp_sent = 1 WHERE id = ?");
        $update_stmt->bind_param("i", $order_id);
        $update_stmt->execute();

        $success = true;
        $whatsapp_link = $whatsapp_url;
    } else {
        $error = "Failed to place order. Please try again.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - Princewill - Electronic shop</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="container">
            <div class="nav-brand">
                <div class="logo-placeholder">Princewill - Electronic shop</div>
            </div>
            <a href="index.php" class="btn btn-small">Back to Shop</a>
        </div>
    </nav>

    <section class="checkout">
        <div class="container">
            <h1>Checkout</h1>

            <?php if (isset($success) && $success): ?>
                <div class="success-message">
                    <h2>Order Placed Successfully!</h2>
                    <p>Order #<?php echo $order_id; ?> has been created.</p>
                    <p>Click the button below to send your order via WhatsApp:</p>
                    <a href="<?php echo $whatsapp_link; ?>" target="_blank" class="btn btn-primary" style="margin-top: 20px;">Send Order via WhatsApp</a>
                    <a href="index.php" class="btn btn-secondary" style="margin-top: 10px;">Continue Shopping</a>
                </div>
            <?php else: ?>
                <div class="checkout-form">
                    <form method="POST">
                        <h2>Customer Information</h2>
                        <input type="text" name="name" placeholder="Full Name" required>
                        <input type="email" name="email" placeholder="Email" required>
                        <input type="tel" name="phone" placeholder="Phone Number" required>
                        <textarea name="address" placeholder="Delivery Address" required></textarea>

                        <h2>Order Summary</h2>
                        <div id="orderSummary"></div>

                        <input type="hidden" id="cartInput" name="cart" value="">
                        <input type="hidden" id="totalInput" name="total" value="">

                        <button type="submit" class="btn btn-primary">Place Order</button>
                    </form>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <footer class="footer">
        <p>&copy; 2025 Princewill - Electronic shop. All rights reserved.</p>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const cart = JSON.parse(localStorage.getItem('cart') || '[]');
            let total = 0;

            let summaryHTML = '<ul>';
            cart.forEach(item => {
                const itemTotal = item.price * item.quantity;
                total += itemTotal;
                summaryHTML += `<li>${item.name} x${item.quantity} = ${number_format(itemTotal)} FCFA</li>`;
            });
            summaryHTML += '</ul>';
            summaryHTML += `<h3>Total: ${number_format(total)} FCFA</h3>`;

            document.getElementById('orderSummary').innerHTML = summaryHTML;
            document.getElementById('cartInput').value = JSON.stringify(cart);
            document.getElementById('totalInput').value = total;
        });

        function number_format(num) {
            return new Intl.NumberFormat('fr-CM').format(num);
        }
    </script>
</body>
</html>