<?php
// Database Configuration for Princewill - Electronic shop Store
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'debra');

// Store Configuration
define('SHOP_NAME', 'Princewill - Electronic shop');
define('SHOP_LOCATION', 'Bamenda, Cameroon');
define('SHOP_PHONE', '237 683 350 286');
define('SHOP_EMAIL', 'tichaprincewill0@gmail.com');
define('WHATSAPP_NUMBER', '237683350286');
define('CURRENCY', 'FCFA');

// Admin Credentials (Hardcoded)
define('ADMIN_USERNAME', 'admin');
define('ADMIN_PASSWORD', 'admin123');

// Create Database Connection
try {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    $conn->set_charset("utf8");
} catch (Exception $e) {
    die("Database connection error: " . $e->getMessage());
}
?>