<?php
session_start();
if (empty($_SESSION['admin']) && empty($_SESSION['main_admin'])) {
    header('Location: admin_login.php');
    exit();
}

require 'includes/db.php';
require 'fpdf/fpdf.php';

$class = $_GET['class'] ?? '';

if (empty($class)) {
    die('No class specified');
}

$stmt = $pdo->prepare("SELECT * FROM admission WHERE classLevel LIKE ? ORDER BY fullName ASC");
$stmt->execute(["%$class%"]);
$students = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (count($students) === 0) {
    die('No students found for this class');
}

// Create PDF
class PDF extends FPDF {
    function Header() {
        if (file_exists('joys.jpg')) {
            $this->Image('joys.jpg', 10, 6, 25);
        }
        
        $this->SetFont('Arial', 'B', 16);
        $this->SetTextColor(46, 134, 222);
        $this->Cell(0, 10, 'CAROMA COMPREHENSIVE EDUCATION CENTER', 0, 1, 'C');
        $this->SetFont('Arial', '', 10);
        $this->SetTextColor(100, 100, 100);
        $this->Cell(0, 5, 'CAROMA COMPREHENSIVE EDUCATION CENTER (CCEC) BAMENDA', 0, 1, 'C');
        $this->Ln(5);
    }
    
    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->SetTextColor(128, 128, 128);
        $this->Cell(0, 10, 'Page ' . $this->PageNo() . ' | Generated on ' . date('F j, Y'), 0, 0, 'C');
    }
}

$pdf = new PDF();
$pdf->AddPage();

$pdf->SetFont('Arial', 'B', 14);
$pdf->SetTextColor(46, 134, 222);
$pdf->Cell(0, 10, 'Class List: ' . $class, 0, 1, 'C');
$pdf->Ln(5);

$pdf->SetFont('Arial', 'B', 10);
$pdf->SetFillColor(46, 134, 222);
$pdf->SetTextColor(255, 255, 255);
$pdf->Cell(10, 10, '#', 1, 0, 'C', true);
$pdf->Cell(35, 10, 'Matricule', 1, 0, 'C', true);
$pdf->Cell(60, 10, 'Full Name', 1, 0, 'C', true);
$pdf->Cell(15, 10, 'Gender', 1, 0, 'C', true);
$pdf->Cell(35, 10, 'Father Phone', 1, 0, 'C', true);
$pdf->Cell(35, 10, 'Mother Phone', 1, 1, 'C', true);

$pdf->SetFont('Arial', '', 9);
$pdf->SetTextColor(0, 0, 0);
$i = 1;
$fill = false;

foreach ($students as $row) {
    $pdf->SetFillColor(240, 240, 240);
    $pdf->Cell(10, 8, $i++, 1, 0, 'C', $fill);
    $pdf->Cell(35, 8, $row['matricule'], 1, 0, 'L', $fill);
    $pdf->Cell(60, 8, substr($row['fullName'], 0, 30), 1, 0, 'L', $fill);
    $pdf->Cell(15, 8, $row['sex'], 1, 0, 'C', $fill);
    $pdf->Cell(35, 8, $row['fatherPhone'], 1, 0, 'L', $fill);
    $pdf->Cell(35, 8, $row['motherPhone'], 1, 1, 'L', $fill);
    $fill = !$fill;
}

$pdf->Ln(10);
$pdf->SetFont('Arial', 'B', 11);
$pdf->SetTextColor(46, 134, 222);
$pdf->Cell(0, 10, 'Total Students: ' . ($i - 1), 0, 1, 'L');

$filename = 'Class_List_' . str_replace(' ', '_', $class) . '_' . date('Y-m-d') . '.pdf';
$pdf->Output('D', $filename);
?>
