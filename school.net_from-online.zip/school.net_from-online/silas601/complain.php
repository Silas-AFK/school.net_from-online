<?php
session_start();
require 'includes/db.php';

if (!isset($_SESSION['student'])) {
  header("Location: login.php");
  exit();
}

$student = $_SESSION['student'];
$success = '';
$error = '';

// Handle complaint submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_complaint'])) {
    $complaint_text = trim($_POST['complaint_text']);
    
    if (!empty($complaint_text)) {
        $stmt = $mysqli_conn->prepare("INSERT INTO complaints (student_matricule, student_name, complaint_text) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $student['matricule'], $student['fullName'], $complaint_text);
        
        if ($stmt->execute()) {
            $success = "Complaint submitted successfully!";
        } else {
            $error = "Failed to submit complaint. Please try again.";
        }
        $stmt->close();
    } else {
        $error = "Please enter your complaint.";
    }
}

// Handle complaint deletion
if (isset($_GET['delete'])) {
    $complaint_id = intval($_GET['delete']);
    $stmt = $mysqli_conn->prepare("DELETE FROM complaints WHERE id = ? AND student_matricule = ?");
    $stmt->bind_param("is", $complaint_id, $student['matricule']);
    $stmt->execute();
    $stmt->close();
    header("Location: complain.php?deleted=1");
    exit();
}

// Handle complaint editing
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_complaint'])) {
    $complaint_id = intval($_POST['complaint_id']);
    $complaint_text = trim($_POST['complaint_text']);
    
    if (!empty($complaint_text)) {
        $stmt = $mysqli_conn->prepare("UPDATE complaints SET complaint_text = ? WHERE id = ? AND student_matricule = ?");
        $stmt->bind_param("sis", $complaint_text, $complaint_id, $student['matricule']);
        
        if ($stmt->execute()) {
            $success = "Complaint updated successfully!";
        } else {
            $error = "Failed to update complaint.";
        }
        $stmt->close();
    }
}

// Fetch student's complaints
$stmt = $mysqli_conn->prepare("SELECT * FROM complaints WHERE student_matricule = ? ORDER BY complaint_date DESC");
$stmt->bind_param("s", $student['matricule']);
$stmt->execute();
$complaints = $stmt->get_result();
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Submit Complaint | CAROMA</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
      padding: 20px;
    }

    .container {
      max-width: 900px;
      margin: 0 auto;
      background: white;
      border-radius: 15px;
      box-shadow: 0 10px 40px rgba(0,0,0,0.2);
      padding: 30px;
      animation: fadeIn 0.5s ease-in;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }

    h1 {
      color: #667eea;
      text-align: center;
      margin-bottom: 10px;
      font-size: 2rem;
    }

    .subtitle {
      text-align: center;
      color: #666;
      margin-bottom: 30px;
    }

    .alert {
      padding: 15px;
      border-radius: 8px;
      margin-bottom: 20px;
      font-weight: 500;
    }

    .alert-success {
      background: #d4edda;
      color: #155724;
      border: 1px solid #c3e6cb;
    }

    .alert-error {
      background: #f8d7da;
      color: #721c24;
      border: 1px solid #f5c6cb;
    }

    .form-group {
      margin-bottom: 20px;
    }

    label {
      display: block;
      font-weight: 600;
      margin-bottom: 8px;
      color: #333;
    }

    textarea {
      width: 100%;
      padding: 12px;
      border: 2px solid #e0e0e0;
      border-radius: 8px;
      font-size: 15px;
      font-family: inherit;
      resize: vertical;
      min-height: 120px;
      transition: border-color 0.3s ease;
    }

    textarea:focus {
      outline: none;
      border-color: #667eea;
    }

    .btn {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      padding: 12px 30px;
      border: none;
      border-radius: 8px;
      font-size: 16px;
      font-weight: 600;
      cursor: pointer;
      transition: transform 0.2s ease, box-shadow 0.2s ease;
    }

    .btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
    }

    .btn-secondary {
      background: #6c757d;
      margin-left: 10px;
    }

    .btn-danger {
      background: #dc3545;
      padding: 8px 15px;
      font-size: 14px;
    }

    .btn-edit {
      background: #ffc107;
      padding: 8px 15px;
      font-size: 14px;
      margin-right: 10px;
    }

    .complaints-section {
      margin-top: 40px;
    }

    .complaints-section h2 {
      color: #667eea;
      margin-bottom: 20px;
      font-size: 1.5rem;
    }

    .complaint-card {
      background: #f8f9fa;
      border-left: 4px solid #667eea;
      padding: 20px;
      margin-bottom: 15px;
      border-radius: 8px;
      transition: transform 0.2s ease;
    }

    .complaint-card:hover {
      transform: translateX(5px);
    }

    .complaint-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 10px;
    }

    .complaint-date {
      color: #666;
      font-size: 14px;
    }

    .complaint-status {
      padding: 5px 12px;
      border-radius: 20px;
      font-size: 12px;
      font-weight: 600;
    }

    .status-pending {
      background: #fff3cd;
      color: #856404;
    }

    .status-resolved {
      background: #d4edda;
      color: #155724;
    }

    .complaint-text {
      color: #333;
      line-height: 1.6;
      margin-bottom: 15px;
    }

    .complaint-actions {
      display: flex;
      gap: 10px;
    }

    .back-link {
      display: inline-block;
      margin-top: 20px;
      color: #667eea;
      text-decoration: none;
      font-weight: 600;
    }

    .back-link:hover {
      text-decoration: underline;
    }

    .edit-form {
      display: none;
      margin-top: 15px;
      padding: 15px;
      background: white;
      border-radius: 8px;
    }

    .edit-form.active {
      display: block;
    }

    @media (max-width: 768px) {
      .container {
        padding: 20px;
      }
      
      h1 {
        font-size: 1.5rem;
      }
      
      .complaint-header {
        flex-direction: column;
        align-items: flex-start;
        gap: 10px;
      }
    }
  </style>
</head>
<body>

<div class="container">
  <h1>Submit a Complaint</h1>
  <p class="subtitle">Welcome, <?= htmlspecialchars($student['fullName']) ?> (<?= htmlspecialchars($student['matricule']) ?>)</p>

  <?php if ($success): ?>
    <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
  <?php endif; ?>

  <?php if ($error): ?>
    <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <?php if (isset($_GET['deleted'])): ?>
    <div class="alert alert-success">Complaint deleted successfully!</div>
  <?php endif; ?>

  <form method="POST">
    <div class="form-group">
      <label for="complaint_text">Your Complaint</label>
      <textarea name="complaint_text" id="complaint_text" placeholder="Describe your issue or concern..." required></textarea>
    </div>
    
    <button type="submit" name="submit_complaint" class="btn">Submit Complaint</button>
    <a href="student_dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
  </form>

  <div class="complaints-section">
    <h2>Your Previous Complaints</h2>
    
    <?php if ($complaints->num_rows > 0): ?>
      <?php while ($complaint = $complaints->fetch_assoc()): ?>
        <div class="complaint-card">
          <div class="complaint-header">
            <span class="complaint-date">
              <i class="far fa-calendar"></i> <?= date("F j, Y g:i A", strtotime($complaint['complaint_date'])) ?>
            </span>
            <span class="complaint-status status-<?= $complaint['status'] ?>">
              <?= ucfirst($complaint['status']) ?>
            </span>
          </div>
          
          <div class="complaint-text" id="text-<?= $complaint['id'] ?>">
            <?= nl2br(htmlspecialchars($complaint['complaint_text'])) ?>
          </div>
          
          <?php if ($complaint['admin_response']): ?>
            <div style="background: #e7f3ff; padding: 10px; border-radius: 5px; margin-top: 10px;">
              <strong>Admin Response:</strong><br>
              <?= nl2br(htmlspecialchars($complaint['admin_response'])) ?>
            </div>
          <?php endif; ?>
          
          <div class="complaint-actions">
            <button onclick="toggleEdit(<?= $complaint['id'] ?>)" class="btn btn-edit">Edit</button>
            <a href="?delete=<?= $complaint['id'] ?>" 
               onclick="return confirm('Are you sure you want to delete this complaint?')" 
               class="btn btn-danger">Delete</a>
          </div>
          
          <div id="edit-form-<?= $complaint['id'] ?>" class="edit-form">
            <form method="POST">
              <input type="hidden" name="complaint_id" value="<?= $complaint['id'] ?>">
              <textarea name="complaint_text" required><?= htmlspecialchars($complaint['complaint_text']) ?></textarea>
              <button type="submit" name="edit_complaint" class="btn" style="margin-top: 10px;">Update</button>
              <button type="button" onclick="toggleEdit(<?= $complaint['id'] ?>)" class="btn btn-secondary" style="margin-top: 10px;">Cancel</button>
            </form>
          </div>
        </div>
      <?php endwhile; ?>
    <?php else: ?>
      <p style="text-align: center; color: #666;">You haven't submitted any complaints yet.</p>
    <?php endif; ?>
  </div>
</div>

<script>
  function toggleEdit(id) {
    const editForm = document.getElementById('edit-form-' + id);
    const textDiv = document.getElementById('text-' + id);
    
    if (editForm.classList.contains('active')) {
      editForm.classList.remove('active');
      textDiv.style.display = 'block';
    } else {
      editForm.classList.add('active');
      textDiv.style.display = 'none';
    }
  }
</script>

</body>
</html>
