<?php
require_once 'includes/db.php';

if (!isset($conn)) {
    $conn = $mysqli_conn;
}
?>
