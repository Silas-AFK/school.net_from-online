<?php
session_start();
if (empty($_SESSION['admin'])) {
  header('Location: admin_login.php');
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Admin Panel - CAROMA</title>
  <style>
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body {
      font-family: 'Segoe UI', sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      display: flex;
      flex-direction: column;
      min-height: 100vh;
      justify-content: space-between;
    }

    header {
      text-align: center;
      padding: 30px 10px 10px;
    }

    .logo {
      width: 100px;
      height: 100px;
      border-radius: 50%;
      object-fit: cover;
      animation: fadeIn 2s ease-in-out;
      border: 3px solid white;
      box-shadow: 0 5px 15px rgba(0,0,0,0.3);
    }

    @keyframes fadeIn {
      from {
        opacity: 0;
        transform: scale(0.8);
      }
      to {
        opacity: 1;
        transform: scale(1);
      }
    }

    h1 {
      text-align: center;
      color: white;
      margin: 20px 0;
      font-size: 28px;
      text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
    }

    ul {
      list-style: none;
      max-width: 600px;
      margin: 20px auto;
      padding: 0;
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 15px;
    }

    li {
      background: white;
      padding: 20px;
      border-radius: 12px;
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
      text-align: center;
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    li:hover {
      transform: translateY(-5px);
      box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
    }

    a {
      text-decoration: none;
      color: #667eea;
      font-weight: bold;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 10px;
      font-size: 16px;
    }

    .icon {
      font-size: 24px;
    }

    .home-link {
      text-align: center;
      margin-top: 20px;
    }

    .home-link a {
      text-decoration: none;
      color: white;
      font-weight: bold;
      background: rgba(255,255,255,0.2);
      padding: 10px 20px;
      border-radius: 8px;
      transition: background 0.3s ease;
    }

    .home-link a:hover {
      background: rgba(255,255,255,0.3);
    }

    footer {
      background-color: rgba(14, 0, 0, 0.97);
      color: white;
      text-align: center;
      padding: 15px 0;
      margin-top: 40px;
    }

    @media (max-width: 600px) {
      h1 {
        font-size: 24px;
      }

      li {
        padding: 15px;
      }

      .logo {
        width: 80px;
        height: 80px;
      }

      ul {
        grid-template-columns: 1fr;
        max-width: 90%;
      }
    }
  </style>
</head>
<body>

  <header>
    <img src="joys.jpg" alt="School Logo" class="logo" />
  </header>

  
  <h1>CAROMA Admin Panel</h1>

  <ul>
    <li><a href="upload_news.php"><span class="icon">📰</span> Upload News</a></li>
    <li><a href="upload_book.php"><span class="icon">📚</span> Upload Book to E-Library</a></li>
     
    <li><a href="manage_students.php"><span class="icon">👥</span> Manage Students</a></li>
    <li><a href="view_complaints.php"><span class="icon">📋</span> View Complaints</a></li>
    <li><a href="manage_administrative.php"><span class="icon">👔</span> Manage Staff</a></li>
     <li><a href="admission.html"><span class="icon"></span> Admission</a></li>
    <li><a href="admin_payment_form.php"><span class="icon"></span> Payment Voucher</a></li>
    <li><a href="admin_logout.php"><span class="icon">🚪</span> Logout</a></li>
  </ul>

  <div class="home-link">
    <a href="index.html">← Back to Home</a>
  </div>

  <footer>
     
    <p>&copy; <?= date('Y') ?> CAROMA COMPREHENSIVE EDUCATION CENTER. All Rights Reserved.</p>
    <p>Powered by <span style="color: goldenrod;">OSIRIS</span> Tech</p>
  </footer>

</body>
</html>
