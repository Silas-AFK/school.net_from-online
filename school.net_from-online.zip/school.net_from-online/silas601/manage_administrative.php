<?php
session_start();
if (empty($_SESSION['admin']) && empty($_SESSION['main_admin'])) {
    header('Location: admin_login.php');
    exit();
}

require 'includes/db.php';

$success = '';
$error = '';

// Ensure connection is valid
if (!isset($mysqli_conn) || $mysqli_conn->connect_error) {
    die("Database connection failed: " . $mysqli_conn->connect_error);
}

// Handle staff addition
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_staff'])) {
    $name = trim($_POST['name']);
    $position = trim($_POST['position']);
    $bio = trim($_POST['bio']);
    $display_order = intval($_POST['display_order']);
    
    // Handle photo upload
    $photo = 'joys.jpg'; // default
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = 'uploads/staff/';
        if (!is_dir($upload_dir)) {
            if (!mkdir($upload_dir, 0777, true)) {
                $error = "Failed to create upload directory.";
            }
        }
        
        if (empty($error)) {
            $file_ext = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
            $new_filename = time() . '_' . uniqid() . '.' . $file_ext;
            $upload_path = $upload_dir . $new_filename;
            
            if (move_uploaded_file($_FILES['photo']['tmp_name'], $upload_path)) {
                $photo = $upload_path;
            } else {
                $error = "Failed to upload photo. Check file permissions.";
            }
        }
    } else if (isset($_FILES['photo']) && $_FILES['photo']['error'] !== UPLOAD_ERR_NO_FILE) {
        $error = "Photo upload error: " . $_FILES['photo']['error'];
    }
    
    if (empty($error)) {
        try {
            // Escape reserved keyword `position`
            $sql = "INSERT INTO administrative_staff (`name`, `position`, `bio`, `photo`, `display_order`) 
                    VALUES (?, ?, ?, ?, ?)";
            $stmt = $mysqli_conn->prepare($sql);
            if (!$stmt) {
                throw new Exception("Prepare failed: " . $mysqli_conn->error);
            }
            $stmt->bind_param("ssssi", $name, $position, $bio, $photo, $display_order);
            
            if ($stmt->execute()) {
                $success = "Staff member added successfully!";
            } else {
                $error = "Failed to add staff member: " . $stmt->error;
            }
            $stmt->close();
        } catch (Exception $e) {
            $error = "Database error: " . $e->getMessage();
            error_log("Staff addition error: " . $e->getMessage());
        }
    }
}

// Handle staff update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_staff'])) {
    $id = intval($_POST['staff_id']);
    $name = trim($_POST['name']);
    $position = trim($_POST['position']);
    $bio = trim($_POST['bio']);
    $display_order = intval($_POST['display_order']);
    
    // Check if new photo uploaded
    $photo_update = '';
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = 'uploads/staff/';
        if (!is_dir($upload_dir)) {
            if (!mkdir($upload_dir, 0777, true)) {
                $error = "Failed to create upload directory.";
            }
        }
        
        if (empty($error)) {
            $file_ext = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
            $new_filename = time() . '_' . uniqid() . '.' . $file_ext;
            $upload_path = $upload_dir . $new_filename;
            
            if (move_uploaded_file($_FILES['photo']['tmp_name'], $upload_path)) {
                $photo_update = ", photo = '$upload_path'";
            } else {
                $error = "Failed to upload photo. Check file permissions.";
            }
        }
    } else if (isset($_FILES['photo']) && $_FILES['photo']['error'] !== UPLOAD_ERR_NO_FILE) {
        $error = "Photo upload error: " . $_FILES['photo']['error'];
    }
    
    if (empty($error)) {
        try {
            // Escape reserved keyword `position`
            $sql = "UPDATE administrative_staff 
                    SET `name` = ?, `position` = ?, `bio` = ?, `display_order` = ? $photo_update 
                    WHERE id = ?";
            $stmt = $mysqli_conn->prepare($sql);
            if (!$stmt) {
                throw new Exception("Prepare failed: " . $mysqli_conn->error);
            }
            $stmt->bind_param("sssii", $name, $position, $bio, $display_order, $id);
            
            if ($stmt->execute()) {
                $success = "Staff member updated successfully!";
            } else {
                $error = "Failed to update staff member: " . $stmt->error;
            }
            $stmt->close();
        } catch (Exception $e) {
            $error = "Database error: " . $e->getMessage();
            error_log("Staff update error: " . $e->getMessage());
        }
    }
}

// Handle staff deletion
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $stmt = $mysqli_conn->prepare("DELETE FROM administrative_staff WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
    header("Location: manage_administrative.php?deleted=1");
    exit();
}

// Fetch all staff
$result = $mysqli_conn->query("SELECT * FROM administrative_staff ORDER BY display_order ASC, id ASC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Manage Administrative Staff | CAROMA</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
      padding: 20px;
    }

    .container {
      max-width: 1200px;
      margin: 0 auto;
      background: white;
      border-radius: 15px;
      box-shadow: 0 10px 40px rgba(0,0,0,0.3);
      padding: 30px;
      animation: fadeIn 0.5s ease-in;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }

    h1 {
      color: #667eea;
      text-align: center;
      margin-bottom: 10px;
      font-size: 2rem;
    }

    .subtitle {
      text-align: center;
      color: #666;
      margin-bottom: 30px;
    }

    .alert {
      padding: 15px;
      border-radius: 8px;
      margin-bottom: 20px;
      font-weight: 500;
    }

    .alert-success {
      background: #d4edda;
      color: #155724;
      border: 1px solid #c3e6cb;
    }

    .alert-error {
      background: #f8d7da;
      color: #721c24;
      border: 1px solid #f5c6cb;
    }

    .add-section {
      background: #f8f9fa;
      padding: 25px;
      border-radius: 10px;
      margin-bottom: 30px;
      border: 2px solid #667eea;
    }

    .add-section h2 {
      color: #667eea;
      margin-bottom: 20px;
      font-size: 1.5rem;
    }

    .form-row {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 15px;
      margin-bottom: 15px;
    }

    .form-group {
      margin-bottom: 15px;
    }

    .form-group label {
      display: block;
      font-weight: 600;
      margin-bottom: 8px;
      color: #333;
    }

    .form-group input, .form-group textarea, .form-group select {
      width: 100%;
      padding: 12px;
      border: 2px solid #e0e0e0;
      border-radius: 8px;
      font-size: 15px;
      font-family: inherit;
    }

    .form-group textarea {
      resize: vertical;
      min-height: 100px;
    }

    .form-group input:focus, .form-group textarea:focus, .form-group select:focus {
      outline: none;
      border-color: #667eea;
    }

    .btn {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      padding: 12px 30px;
      border: none;
      border-radius: 8px;
      font-size: 16px;
      font-weight: 600;
      cursor: pointer;
      transition: transform 0.2s ease, box-shadow 0.2s ease;
    }

    .btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
    }

    .btn-secondary {
      background: #6c757d;
      margin-left: 10px;
    }

    .staff-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
      gap: 25px;
      margin-bottom: 30px;
    }

    .staff-card {
      background: white;
      border: 2px solid #e0e0e0;
      border-radius: 12px;
      overflow: hidden;
      transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .staff-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 10px 25px rgba(0,0,0,0.15);
      border-color: #667eea;
    }

    .staff-photo {
      width: 100%;
      height: 250px;
      object-fit: cover;
      background: #f0f0f0;
    }

    .staff-info {
      padding: 20px;
    }

    .staff-name {
      font-size: 1.3rem;
      font-weight: 700;
      color: #333;
      margin-bottom: 5px;
    }

    .staff-position {
      color: #667eea;
      font-weight: 600;
      margin-bottom: 15px;
      font-size: 15px;
    }

    .staff-bio {
      color: #666;
      line-height: 1.6;
      margin-bottom: 15px;
      font-size: 14px;
    }

    .staff-order {
      color: #999;
      font-size: 13px;
      margin-bottom: 15px;
    }

    .staff-actions {
      display: flex;
      gap: 10px;
    }

    .btn-edit {
      background: #ffc107;
      padding: 8px 15px;
      font-size: 14px;
      flex: 1;
    }

    .btn-delete {
      background: #dc3545;
      padding: 8px 15px;
      font-size: 14px;
      flex: 1;
    }

    .modal {
      display: none;
      position: fixed;
      z-index: 1000;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      background: rgba(0,0,0,0.7);
      overflow-y: auto;
    }

    .modal-content {
      background: white;
      margin: 50px auto;
      padding: 30px;
      border-radius: 15px;
      width: 90%;
      max-width: 600px;
      box-shadow: 0 10px 40px rgba(0,0,0,0.3);
      animation: slideDown 0.3s ease;
    }

    @keyframes slideDown {
      from { opacity: 0; transform: translateY(-50px); }
      to { opacity: 1; transform: translateY(0); }
    }

    .close {
      color: #aaa;
      float: right;
      font-size: 28px;
      font-weight: bold;
      cursor: pointer;
      transition: color 0.2s ease;
    }

    .close:hover { color: #000; }

    .back-link {
      display: inline-block;
      margin-top: 20px;
      color: #667eea;
      text-decoration: none;
      font-weight: 600;
      padding: 10px 20px;
      border: 2px solid #667eea;
      border-radius: 8px;
      transition: all 0.3s ease;
    }

    .back-link:hover {
      background: #667eea;
      color: white;
    }

    @media (max-width: 768px) {
      .container {
        padding: 20px;
      }
      
      h1 {
        font-size: 1.5rem;
      }

      .staff-grid {
        grid-template-columns: 1fr;
      }

      .form-row {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>

<div class="container">
  <h1><i class="fas fa-users-cog"></i> Manage Administrative Staff</h1>
  <p class="subtitle">Add, edit, and manage your school's administrative structure</p>

  <?php if ($success): ?>
    <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
  <?php endif; ?>

  <?php if ($error): ?>
    <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <?php if (isset($_GET['deleted'])): ?>
    <div class="alert alert-success">Staff member deleted successfully!</div>
  <?php endif; ?>

  <div class="add-section">
    <h2><i class="fas fa-plus-circle"></i> Add New Staff Member</h2>
    <form method="POST" enctype="multipart/form-data">
      <div class="form-row">
        <div class="form-group">
          <label>Full Name *</label>
          <input type="text" name="name" required>
        </div>
        
        <div class="form-group">
          <label>Position/Title *</label>
          <input type="text" name="position" placeholder="e.g., Principal, Vice Principal" required>
        </div>
      </div>

      <div class="form-group">
        <label>Biography</label>
        <textarea name="bio" placeholder="Brief description of the staff member's role and background..."></textarea>
      </div>

      <div class="form-row">
        <div class="form-group">
          <label>Photo</label>
          <input type="file" name="photo" accept="image/*">
        </div>
        
        <div class="form-group">
          <label>Display Order</label>
          <input type="number" name="display_order" value="0" min="0">
          <small style="color: #666;">Lower numbers appear first</small>
        </div>
      </div>

      <button type="submit" name="add_staff" class="btn">
        <i class="fas fa-user-plus"></i> Add Staff Member
      </button>
    </form>
  </div>

  <h2 style="color: #667eea; margin-bottom: 20px; font-size: 1.5rem;">
    <i class="fas fa-users"></i> Current Staff Members
  </h2>

  <?php if ($result && $result->num_rows > 0): ?>
    <div class="staff-grid">
      <?php while ($staff = $result->fetch_assoc()): ?>
        <div class="staff-card">
          <img src="<?= htmlspecialchars($staff['photo']) ?>" alt="<?= htmlspecialchars($staff['name']) ?>" class="staff-photo">
          <div class="staff-info">
            <div class="staff-name"><?= htmlspecialchars($staff['name']) ?></div>
            <div class="staff-position"><?= htmlspecialchars($staff['position']) ?></div>
            <div class="staff-bio"><?= nl2br(htmlspecialchars($staff['bio'])) ?></div>
            <div class="staff-order">Display Order: <?= $staff['display_order'] ?></div>
            
            <div class="staff-actions">
              <button onclick="editStaff(<?= $staff['id'] ?>, '<?= htmlspecialchars($staff['name'], ENT_QUOTES) ?>', '<?= htmlspecialchars($staff['position'], ENT_QUOTES) ?>', '<?= htmlspecialchars($staff['bio'], ENT_QUOTES) ?>', <?= $staff['display_order'] ?>)" 
                      class="btn btn-edit">
                <i class="fas fa-edit"></i> Edit
              </button>
              <a href="?delete=<?= $staff['id'] ?>" 
                 onclick="return confirm('Delete this staff member?')" 
                 class="btn btn-delete">
                <i class="fas fa-trash"></i> Delete
              </a>
            </div>
          </div>
        </div>
      <?php endwhile; ?>
    </div>
  <?php else: ?>
    <p style="text-align: center; color: #666; padding: 40px;">No staff members added yet.</p>
  <?php endif; ?>

  <a href="admin_panel.php" class="back-link">
    <i class="fas fa-arrow-left"></i> Back to Admin Panel
  </a>
</div>

<!-- Edit Staff Modal -->
<div id="editModal" class="modal">
  <div class="modal-content">
    <span class="close" onclick="closeModal()">&times;</span>
    <h2 style="color: #667eea; margin-bottom: 20px;">Edit Staff Member</h2>
    <form method="POST" enctype="multipart/form-data">
      <input type="hidden" name="staff_id" id="edit_staff_id">
      
      <div class="form-group">
        <label>Full Name *</label>
        <input type="text" name="name" id="edit_name" required>
      </div>
      
      <div class="form-group">
        <label>Position/Title *</label>
        <input type="text" name="position" id="edit_position" required>
      </div>
      
      <div class="form-group">
        <label>Biography</label>
        <textarea name="bio" id="edit_bio"></textarea>
      </div>
      
      <div class="form-group">
        <label>New Photo (leave empty to keep current)</label>
        <input type="file" name="photo" accept="image/*">
      </div>
      
      <div class="form-group">
        <label>Display Order</label>
        <input type="number" name="display_order" id="edit_display_order" min="0">
      </div>
      
      <button type="submit" name="update_staff" class="btn">
        <i class="fas fa-save"></i> Update Staff Member
      </button>
      <button type="button" onclick="closeModal()" class="btn btn-secondary">
        Cancel
      </button>
    </form>
  </div>
</div>

<script>
  function editStaff(id, name, position, bio, displayOrder) {
    document.getElementById('edit_staff_id').value = id;
    document.getElementById('edit_name').value = name;
    document.getElementById('edit_position').value = position;
    document.getElementById('edit_bio').value = bio;
    document.getElementById('edit_display_order').value = displayOrder;
    document.getElementById('editModal').style.display = 'block';
  }

  function closeModal() {
    document.getElementById('editModal').style.display = 'none';
  }

  // Close modal when clicking outside
  window.onclick = function(event) {
    const modal = document.getElementById('editModal');
    if (event.target == modal) {
      modal.style.display = 'none';
    }
  }
</script>

</body>
</html>
