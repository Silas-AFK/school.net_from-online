<?php
session_start();
if (!isset($_SESSION['student'])) {
  header("Location: login.php");
  exit();
}

$student = $_SESSION['student'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Student Dashboard | CAROMA</title>

  <!-- Font Awesome for social icons -->
  <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"
  />

  <style>
    /* Reset */
    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: #e9eff4;
      color: #222;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }

    /* NAVBAR */
    .navbar {
      background-color: #00050a;
      color: white;
      padding: 15px 30px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      position: sticky;
      top: 0;
      z-index: 1000;
      box-shadow: 0 2px 8px rgb(0 0 0 / 0.2);
    }

    .navbar .logo {
      display: flex;
      align-items: center;
      gap: 12px;
      font-weight: 700;
      font-size: 1.4rem;
      letter-spacing: 1px;
    }

    .navbar .logo img {
      height: 42px;
      border-radius: 50%;
      border: 2px solid white;
      box-shadow: 0 0 10px rgba(255 255 255 / 0.2);
    }

    .navbar nav {
      display: flex;
      gap: 25px;
      font-weight: 600;
      font-size: 1rem;
    }

    .navbar nav a {
      color: white;
      text-decoration: none;
      padding: 6px 12px;
      border-radius: 6px;
      transition: background-color 0.3s ease;
    }

    .navbar nav a:hover,
    .navbar nav a:focus {
      background-color: #0b3a7a;
      outline: none;
    }

    .hamburger {
      display: none;
      flex-direction: column;
      cursor: pointer;
      gap: 5px;
    }

    .hamburger div {
      width: 25px;
      height: 3px;
      background: white;
      border-radius: 2px;
    }

    @media (max-width: 768px) {
      .navbar nav {
        display: none;
        flex-direction: column;
        background: #00050a;
        position: absolute;
        top: 60px;
        left: 0;
        width: 100%;
        padding: 15px 0;
        box-shadow: 0 2px 10px rgb(0 0 0 / 0.4);
      }
      .navbar nav.active {
        display: flex;
      }
      .hamburger {
        display: flex;
      }
    }

    /* Main content container */
    .container {
      flex: 1;
      max-width: 900px;
      margin: 30px auto 40px;
      padding: 0 20px;
      display: flex;
      flex-wrap: wrap;
      gap: 30px;
      justify-content: center;
    }

    /* Profile card */
    .profile-card {
      background: white;
      border-radius: 15px;
      box-shadow: 0 6px 20px rgb(0 0 0 / 0.1);
      width: 350px;
      padding: 25px 30px;
      text-align: center;
      animation: fadeInUp 0.8s ease forwards;
    }

    .profile-card img {
      width: 130px;
      height: 130px;
      border-radius: 50%;
      object-fit: cover;
      border: 4px solid #2e86de;
      margin-bottom: 20px;
      box-shadow: 0 0 15px rgba(46, 134, 222, 0.4);
    }

    .profile-card h2 {
      font-size: 24px;
      margin-bottom: 10px;
      color: #0b3a7a;
    }

    .profile-card p {
      font-size: 15px;
      margin: 6px 0;
      color: #444;
    }

    /* Info card */
    .info-card {
      background: white;
      border-radius: 15px;
      box-shadow: 0 6px 20px rgb(0 0 0 / 0.1);
      width: 480px;
      padding: 25px 30px;
      animation: fadeInUp 0.8s ease forwards;
      animation-delay: 0.3s;
    }

    .info-card h3 {
      color: #0b3a7a;
      font-weight: 700;
      font-size: 22px;
      margin-bottom: 20px;
      border-bottom: 2px solid #2e86de;
      padding-bottom: 8px;
    }

    .info-card p {
      font-size: 15px;
      margin-bottom: 12px;
      color: #333;
    }

    /* Footer */
    footer {
      background-color: #00050a;
      color: white;
      text-align: center;
      padding: 18px 20px;
      font-size: 0.9rem;
      user-select: none;
      box-shadow: 0 -2px 8px rgb(0 0 0 / 0.2);
    }

    .footer-content {
      max-width: 900px;
      margin: auto;
      display: flex;
      justify-content: space-between;
      align-items: center;
      flex-wrap: wrap;
      gap: 15px;
    }

    .footer-content p {
      margin: 0;
    }

    .social-icons a {
      color: white;
      font-size: 24px;
      margin-left: 12px;
      transition: color 0.3s ease;
      text-decoration: none;
    }

    .social-icons a:hover,
    .social-icons a:focus {
      color: #2e86de;
      outline: none;
    }

    /* Animations */
    @keyframes fadeInUp {
      from {
        opacity: 0;
        transform: translateY(20px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    /* Responsive */
    @media (max-width: 800px) {
      .container {
        flex-direction: column;
        align-items: center;
      }
      .info-card,
      .profile-card {
        width: 100%;
        max-width: 400px;
      }
      .footer-content {
        flex-direction: column;
        gap: 10px;
      }
    }
  </style>
</head>
<body>

  <!-- NAVBAR -->
  <header class="navbar" role="banner">
    <div class="logo" role="heading" aria-level="1">
      <img src="joys.jpg" alt="CAROMA Logo" />
      CAROMA
    </div>
    <nav id="navLinks" role="navigation" aria-label="Primary navigation">
      <a href="index.html">Home</a>
      <a href="complain.php">Submit Complain</a>
      <a href="index.html">Log Out</a>
    </nav>
    <div class="hamburger" onclick="toggleMenu()" aria-label="Toggle navigation menu" role="button" tabindex="0">
      <div></div>
      <div></div>
      <div></div>
    </div>
  </header>

  <!-- Main dashboard content -->
  <main class="container" role="main">
    <section class="profile-card" aria-label="Student Profile">
      <?php
        $photoFile = isset($student['photo']) ? basename($student['photo']) : 'default.jpg';
        $photoPath = "uploads/" . $photoFile;
        if (!file_exists($photoPath) || empty($photoFile)) {
          $photoPath = "uploads/default.jpg"; // fallback image
        }
      ?>
      <img src="<?php echo htmlspecialchars($photoPath); ?>" alt="Student Photo" />
      <h2>Welcome, <?php echo htmlspecialchars($student['fullName']); ?></h2>
      <p><strong>Matricule:</strong> <?php echo htmlspecialchars($student['matricule']); ?></p>
      <p><strong>Class Level:</strong> <?php echo htmlspecialchars($student['classLevel']); ?></p>
      <p><strong>Gender:</strong> <?php echo htmlspecialchars($student['sex']); ?></p>
    </section>

    <section class="info-card" aria-label="Student Contact Information">
      <h3>Basic Information</h3>
      <p><strong>Place of Birth:</strong> <?php echo htmlspecialchars($student['placeOfBirth']); ?></p>
      <p><strong>Date of Birth:</strong> <?php 
        $regDate = htmlspecialchars($student['dob']);
        echo date("F j, Y", strtotime($regDate));
      ?></p>
      <p><strong>Registration Date:</strong> <?php
        $regDate = htmlspecialchars($student['registrationDate']);
        echo $regDate ? date("F j, Y", strtotime($regDate)) : "N/A";
      ?></p>

      <h3>Contact Information</h3>
      <p><strong>Father's Name:</strong> <?php echo htmlspecialchars($student['fatherName']); ?></p>
      <p><strong>Father's Phone:</strong> <?php echo htmlspecialchars($student['fatherPhone']); ?></p>
      <p><strong>Father's Residence:</strong> <?php echo htmlspecialchars($student['fatherResidence']); ?></p>
      <p><strong>Mother's Name:</strong> <?php echo htmlspecialchars($student['motherName']); ?></p>
      <p><strong>Mother's Phone:</strong> <?php echo htmlspecialchars($student['motherPhone']); ?></p>
    </section>
  </main>

  <!-- Footer -->
  <footer>
    <div class="footer-content">
      <p>&copy; <?= date("Y") ?> CAROMA COMPREHENSIVE EDUCATION CENTER. All Rights Reserved.</p>
      <p>Powered By <span style="color: goldenrod; opacity: 0.8;">OSIRIS</span> Tech</p>
      <div class="social-icons" aria-label="Social media links">
        <a href="https://wa.me/237676763842" target="_blank" rel="noopener" title="Chat with us on WhatsApp">
          <i class="fab fa-whatsapp" aria-hidden="true"></i><span class="sr-only">WhatsApp</span>
        </a>
      </div>
    </div>
  </footer>

  <script>
    function toggleMenu() {
      const nav = document.getElementById("navLinks");
      nav.classList.toggle("active");
    }
  </script>
</body>
</html>
