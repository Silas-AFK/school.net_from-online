<?php
session_start();
if (empty($_SESSION['admin']) && empty($_SESSION['main_admin'])) {
    header('Location: admin_login.php');
    exit();
}

require 'includes/db.php';

$success = '';
$error = '';

// Handle admin response
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['respond_complaint'])) {
    $complaint_id = intval($_POST['complaint_id']);
    $admin_response = trim($_POST['admin_response']);
    $status = $_POST['status'];
    
    if (!empty($admin_response)) {
        $stmt = $pdo->prepare("UPDATE complaints SET admin_response = ?, status = ? WHERE id = ?");
        
        if ($stmt->execute([$admin_response, $status, $complaint_id])) {
            $success = "Response submitted successfully!";
        } else {
            $error = "Failed to submit response.";
        }
    }
}

// Handle complaint deletion
if (isset($_GET['delete'])) {
    $complaint_id = intval($_GET['delete']);
    $stmt = $pdo->prepare("DELETE FROM complaints WHERE id = ?");
    $stmt->execute([$complaint_id]);
    header("Location: view_complaints.php?deleted=1");
    exit();
}

// Fetch all complaints
$filter = $_GET['filter'] ?? 'all';
$search = $_GET['search'] ?? '';

$sql = "SELECT * FROM complaints WHERE 1=1";
$params = [];

if ($filter === 'pending') {
    $sql .= " AND status = ?";
    $params[] = 'pending';
} elseif ($filter === 'resolved') {
    $sql .= " AND status = ?";
    $params[] = 'resolved';
}

if (!empty($search)) {
    $sql .= " AND (student_matricule LIKE ? OR student_name LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

$sql .= " ORDER BY complaint_date DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get complaint statistics
$stats_stmt = $pdo->query("SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
    SUM(CASE WHEN status = 'resolved' THEN 1 ELSE 0 END) as resolved
    FROM complaints");
$stats = $stats_stmt->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>View Complaints | CAROMA Admin</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      min-height: 100vh;
      padding: 20px;
    }

    .container {
      max-width: 1200px;
      margin: 0 auto;
      background: white;
      border-radius: 15px;
      box-shadow: 0 10px 40px rgba(0,0,0,0.3);
      padding: 30px;
      animation: fadeIn 0.5s ease-in;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }

    h1 {
      color: #667eea;
      text-align: center;
      margin-bottom: 10px;
      font-size: 2rem;
    }

    .subtitle {
      text-align: center;
      color: #666;
      margin-bottom: 30px;
    }

    .stats-container {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 20px;
      margin-bottom: 30px;
    }

    .stat-card {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      padding: 20px;
      border-radius: 10px;
      text-align: center;
      box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    }

    .stat-number {
      font-size: 2.5rem;
      font-weight: 700;
      margin-bottom: 5px;
    }

    .stat-label {
      font-size: 14px;
      opacity: 0.9;
    }

    .filters {
      display: flex;
      gap: 15px;
      margin-bottom: 25px;
      flex-wrap: wrap;
      align-items: center;
    }

    .filter-btn {
      padding: 10px 20px;
      border: 2px solid #667eea;
      background: white;
      color: #667eea;
      border-radius: 8px;
      cursor: pointer;
      font-weight: 600;
      transition: all 0.3s ease;
      text-decoration: none;
    }

    .filter-btn:hover, .filter-btn.active {
      background: #667eea;
      color: white;
    }

    .search-box {
      flex: 1;
      min-width: 250px;
    }

    .search-box input {
      width: 100%;
      padding: 10px 15px;
      border: 2px solid #e0e0e0;
      border-radius: 8px;
      font-size: 15px;
    }

    .search-box input:focus {
      outline: none;
      border-color: #667eea;
    }

    .alert {
      padding: 15px;
      border-radius: 8px;
      margin-bottom: 20px;
      font-weight: 500;
    }

    .alert-success {
      background: #d4edda;
      color: #155724;
      border: 1px solid #c3e6cb;
    }

    .alert-error {
      background: #f8d7da;
      color: #721c24;
      border: 1px solid #f5c6cb;
    }

    .complaint-card {
      background: #f8f9fa;
      border-left: 4px solid #667eea;
      padding: 25px;
      margin-bottom: 20px;
      border-radius: 8px;
      transition: transform 0.2s ease, box-shadow 0.2s ease;
    }

    .complaint-card:hover {
      transform: translateX(5px);
      box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }

    .complaint-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 15px;
      flex-wrap: wrap;
      gap: 10px;
    }

    .student-info {
      flex: 1;
    }

    .student-name {
      font-size: 1.2rem;
      font-weight: 700;
      color: #333;
      margin-bottom: 5px;
    }

    .student-matricule {
      color: #666;
      font-size: 14px;
    }

    .complaint-meta {
      display: flex;
      gap: 15px;
      align-items: center;
    }

    .complaint-date {
      color: #666;
      font-size: 14px;
    }

    .complaint-status {
      padding: 6px 15px;
      border-radius: 20px;
      font-size: 13px;
      font-weight: 600;
    }

    .status-pending {
      background: #fff3cd;
      color: #856404;
    }

    .status-resolved {
      background: #d4edda;
      color: #155724;
    }

    .complaint-text {
      color: #333;
      line-height: 1.8;
      margin-bottom: 20px;
      padding: 15px;
      background: white;
      border-radius: 8px;
    }

    .admin-response-section {
      background: #e7f3ff;
      padding: 15px;
      border-radius: 8px;
      margin-top: 15px;
    }

    .admin-response-section h4 {
      color: #667eea;
      margin-bottom: 10px;
      font-size: 16px;
    }

    .response-form {
      display: none;
      margin-top: 15px;
      padding: 20px;
      background: white;
      border-radius: 8px;
      border: 2px solid #667eea;
    }

    .response-form.active {
      display: block;
    }

    .form-group {
      margin-bottom: 15px;
    }

    .form-group label {
      display: block;
      font-weight: 600;
      margin-bottom: 8px;
      color: #333;
    }

    .form-group textarea {
      width: 100%;
      padding: 12px;
      border: 2px solid #e0e0e0;
      border-radius: 8px;
      font-size: 15px;
      font-family: inherit;
      resize: vertical;
      min-height: 100px;
    }

    .form-group select {
      width: 100%;
      padding: 12px;
      border: 2px solid #e0e0e0;
      border-radius: 8px;
      font-size: 15px;
    }

    .form-group textarea:focus, .form-group select:focus {
      outline: none;
      border-color: #667eea;
    }

    .btn {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      padding: 10px 25px;
      border: none;
      border-radius: 8px;
      font-size: 15px;
      font-weight: 600;
      cursor: pointer;
      transition: transform 0.2s ease, box-shadow 0.2s ease;
    }

    .btn:hover {
      transform: translateY(-2px);
      box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
    }

    .btn-secondary {
      background: #6c757d;
      margin-left: 10px;
    }

    .btn-danger {
      background: #dc3545;
      padding: 8px 15px;
      font-size: 14px;
    }

    .btn-respond {
      background: #28a745;
      padding: 8px 15px;
      font-size: 14px;
      margin-right: 10px;
    }

    .complaint-actions {
      display: flex;
      gap: 10px;
      margin-top: 15px;
    }

    .back-link {
      display: inline-block;
      margin-top: 20px;
      color: #667eea;
      text-decoration: none;
      font-weight: 600;
      padding: 10px 20px;
      border: 2px solid #667eea;
      border-radius: 8px;
      transition: all 0.3s ease;
    }

    .back-link:hover {
      background: #667eea;
      color: white;
    }

    .no-complaints {
      text-align: center;
      padding: 60px 20px;
      color: #666;
    }

    .no-complaints i {
      font-size: 4rem;
      color: #ccc;
      margin-bottom: 20px;
    }

    @media (max-width: 768px) {
      .container {
        padding: 20px;
      }
      
      h1 {
        font-size: 1.5rem;
      }
      
      .complaint-header {
        flex-direction: column;
      }

      .complaint-meta {
        flex-direction: column;
        align-items: flex-start;
      }

      .stats-container {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>

<div class="container">
  <h1><i class="fas fa-comments"></i> Student Complaints Management</h1>
  <p class="subtitle">View and respond to student complaints</p>

  <?php if ($success): ?>
    <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
  <?php endif; ?>

  <?php if ($error): ?>
    <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <?php if (isset($_GET['deleted'])): ?>
    <div class="alert alert-success">Complaint deleted successfully!</div>
  <?php endif; ?>

  <div class="stats-container">
    <div class="stat-card">
      <div class="stat-number"><?= $stats['total'] ?></div>
      <div class="stat-label">Total Complaints</div>
    </div>
    <div class="stat-card" style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);">
      <div class="stat-number"><?= $stats['pending'] ?></div>
      <div class="stat-label">Pending</div>
    </div>
    <div class="stat-card" style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);">
      <div class="stat-number"><?= $stats['resolved'] ?></div>
      <div class="stat-label">Resolved</div>
    </div>
  </div>

  <div class="filters">
    <a href="?filter=all" class="filter-btn <?= $filter === 'all' ? 'active' : '' ?>">
      <i class="fas fa-list"></i> All
    </a>
    <a href="?filter=pending" class="filter-btn <?= $filter === 'pending' ? 'active' : '' ?>">
      <i class="fas fa-clock"></i> Pending
    </a>
    <a href="?filter=resolved" class="filter-btn <?= $filter === 'resolved' ? 'active' : '' ?>">
      <i class="fas fa-check-circle"></i> Resolved
    </a>
    
    <div class="search-box">
      <form method="GET" style="display: flex; gap: 10px;">
        <input type="hidden" name="filter" value="<?= htmlspecialchars($filter) ?>">
        <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" 
               placeholder="Search by matricule or name...">
        <button type="submit" class="btn"><i class="fas fa-search"></i></button>
      </form>
    </div>
  </div>

  <?php if (count($result) > 0): ?>
    <?php foreach ($result as $complaint): ?>
      <div class="complaint-card">
        <div class="complaint-header">
          <div class="student-info">
            <div class="student-name">
              <i class="fas fa-user"></i> <?= htmlspecialchars($complaint['student_name']) ?>
            </div>
            <div class="student-matricule">
              Matricule: <?= htmlspecialchars($complaint['student_matricule']) ?>
            </div>
          </div>
          
          <div class="complaint-meta">
            <span class="complaint-date">
              <i class="far fa-calendar"></i> <?= date("F j, Y g:i A", strtotime($complaint['complaint_date'])) ?>
            </span>
            <span class="complaint-status status-<?= $complaint['status'] ?>">
              <?= ucfirst($complaint['status']) ?>
            </span>
          </div>
        </div>
        
        <div class="complaint-text">
          <strong>Complaint:</strong><br>
          <?= nl2br(htmlspecialchars($complaint['complaint_text'])) ?>
        </div>
        
        <?php if ($complaint['admin_response']): ?>
          <div class="admin-response-section">
            <h4><i class="fas fa-reply"></i> Admin Response:</h4>
            <p><?= nl2br(htmlspecialchars($complaint['admin_response'])) ?></p>
          </div>
        <?php endif; ?>
        
        <div class="complaint-actions">
          <button onclick="toggleResponse(<?= $complaint['id'] ?>)" class="btn btn-respond">
            <i class="fas fa-reply"></i> <?= $complaint['admin_response'] ? 'Update Response' : 'Respond' ?>
          </button>
          <a href="?delete=<?= $complaint['id'] ?>" 
             onclick="return confirm('Are you sure you want to delete this complaint?')" 
             class="btn btn-danger">
            <i class="fas fa-trash"></i> Delete
          </a>
        </div>
        
        <div id="response-form-<?= $complaint['id'] ?>" class="response-form">
          <form method="POST">
            <input type="hidden" name="complaint_id" value="<?= $complaint['id'] ?>">
            
            <div class="form-group">
              <label>Your Response</label>
              <textarea name="admin_response" required><?= htmlspecialchars($complaint['admin_response'] ?? '') ?></textarea>
            </div>
            
            <div class="form-group">
              <label>Status</label>
              <select name="status" required>
                <option value="pending" <?= $complaint['status'] === 'pending' ? 'selected' : '' ?>>Pending</option>
                <option value="resolved" <?= $complaint['status'] === 'resolved' ? 'selected' : '' ?>>Resolved</option>
              </select>
            </div>
            
            <button type="submit" name="respond_complaint" class="btn">
              <i class="fas fa-paper-plane"></i> Submit Response
            </button>
            <button type="button" onclick="toggleResponse(<?= $complaint['id'] ?>)" class="btn btn-secondary">
              Cancel
            </button>
          </form>
        </div>
      </div>
    <?php endforeach; ?>
  <?php else: ?>
    <div class="no-complaints">
      <i class="fas fa-inbox"></i>
      <h3>No complaints found</h3>
      <p>There are no complaints matching your current filter.</p>
    </div>
  <?php endif; ?>

  <a href="admin_panel.php" class="back-link">
    <i class="fas fa-arrow-left"></i> Back to Admin Panel
  </a>
</div>

<script>
  function toggleResponse(id) {
    const responseForm = document.getElementById('response-form-' + id);
    
    if (responseForm.classList.contains('active')) {
      responseForm.classList.remove('active');
    } else {
      document.querySelectorAll('.response-form').forEach(form => {
        form.classList.remove('active');
      });
      responseForm.classList.add('active');
    }
  }
</script>

</body>
</html>
