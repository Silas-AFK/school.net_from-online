<?php
// samo/index.php — Landing page
declare(strict_types=1);
session_start();

if (isset($_SESSION['user_id'])) {
    if (isset($_SESSION['role']) && $_SESSION['role'] === 'teacher') {
        header("Location: admin/teacher_dashboard.php");
    } else {
        header("Location: admin/dashboard.php");
    }
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Caroma Report Card System</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        .container {
            background: white;
            padding: 50px;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            text-align: center;
            max-width: 500px;
            width: 100%;
        }
        .logo {
            width: 120px;
            height: 120px;
            margin: 0 auto 30px;
            border-radius: 50%;
            object-fit: cover;
            border: 4px solid #667eea;
        }
        h1 {
            color: #333;
            font-size: 2em;
            margin-bottom: 15px;
        }
        p {
            color: #666;
            font-size: 1.1em;
            line-height: 1.6;
            margin-bottom: 30px;
        }
        .button {
            display: inline-block;
            padding: 15px 40px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            text-decoration: none;
            border-radius: 50px;
            font-weight: bold;
            font-size: 1.1em;
            transition: transform 0.3s, box-shadow 0.3s;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
        }
        .button:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(102, 126, 234, 0.6);
        }
        .features {
            margin-top: 40px;
            text-align: left;
        }
        .feature {
            margin: 15px 0;
            padding-left: 30px;
            position: relative;
        }
        .feature:before {
            content: "✓";
            position: absolute;
            left: 0;
            color: #667eea;
            font-weight: bold;
            font-size: 1.2em;
        }
    </style>
</head>
<body>
    <div class="container">
        <img src="assets/images/caro.jpg" alt="Caroma Logo" class="logo" onerror="this.src='assets/images/school-logo.jpg'">
        <h1>Welcome to Caroma Report Card System</h1>
        <p>A comprehensive solution for managing student performance, generating report cards, and tracking academic progress.</p>
        
        <div class="features">
            <div class="feature">Student Management</div>
            <div class="feature">Score Entry & Tracking</div>
            <div class="feature">Report Card Generation</div>
            <div class="feature">Academic Analytics</div>
        </div>
        
        <a href="public/login.php" class="button">Login to Continue</a>
    </div>
</body>
</html>
