<?php
// samo/includes/functions.php — Helper functions
declare(strict_types=1);

// Grade based on total score (e.g. CA + Exam)
function getGrade(float $score): string {
    if ($score >= 18) return 'A';
    if ($score >= 15) return 'B';
    if ($score >= 12) return 'C';
    if ($score >= 10) return 'D';
    if ($score >= 8)  return 'E';
    return 'F';
}

// Remark based on grade
function getGradeRemark(string $grade): string {
    $remarks = [
        'A' => 'Excellent',
        'B' => 'Very Good',
        'C' => 'Good',
        'D' => 'Fair',
        'E' => 'Poor',
        'F' => 'Very Poor'
    ];
    return $remarks[$grade] ?? 'N/A';
}

// Combined helper to get both grade and remark from score
function getGradeAndRemark(float $score): array {
    $grade = getGrade($score);
    $remark = getGradeRemark($grade);
    return [$grade, $remark];
}

// Escape HTML safely
function e(string $string): string {
    return htmlspecialchars($string, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

// Format date to readable string
function formatDate(string $date): string {
    return date('F j, Y', strtotime($date));
}

// Calculate average from array of scores
function calculateAverage(array $scores): float {
    if (empty($scores)) {
        return 0.0;
    }
    return round(array_sum($scores) / count($scores), 2);
}

// CSRF token generation
function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

// CSRF token verification
function verify_csrf(string $token): bool {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

// Basic input sanitization
function sanitize(string $input): string {
    return trim(strip_tags($input));
}

// Email validation
function isValidEmail(string $email): bool {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

// Random password generator
function generatePassword(int $length = 12): string {
    $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*';
    return substr(str_shuffle(str_repeat($chars, $length)), 0, $length);
}

function getTermTotal(PDO $conn, int $student_id, int $subject_id, int $term_id): float {
    $stmt = $conn->prepare("
        SELECT SUM(ca_score + exam_score) AS total
        FROM scores
        JOIN sequences ON scores.sequence_id = sequences.id
        WHERE scores.student_id = ? AND scores.subject_id = ? AND sequences.term_id = ?
    ");
    $stmt->execute([$student_id, $subject_id, $term_id]);
    return round((float) $stmt->fetchColumn(), 2);
}

function getAnnualAverage(PDO $conn, int $student_id, int $subject_id): float {
    $stmt = $conn->prepare("
        SELECT AVG(ca_score + exam_score) AS average
        FROM scores
        WHERE student_id = ? AND subject_id = ?
    ");
    $stmt->execute([$student_id, $subject_id]);
    return round((float) $stmt->fetchColumn(), 2);
}

function getClassRanking(PDO $conn, int $class_id, int $sequence_id): array {
    $stmt = $conn->prepare("
        SELECT s.id AS student_id, s.name,
               SUM(sc.ca_score + sc.exam_score) AS total_score
        FROM students s
        JOIN scores sc ON s.id = sc.student_id
        WHERE s.class_id = ? AND sc.sequence_id = ?
        GROUP BY s.id
        ORDER BY total_score DESC
    ");
    $stmt->execute([$class_id, $sequence_id]);
    $raw = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Assign positions with tie handling
    $ranked = [];
    $position = 1;
    $last_score = null;
    $tie_count = 0;

    foreach ($raw as $index => $row) {
        if ($last_score !== null && $row['total_score'] == $last_score) {
            $tie_count++;
        } else {
            $position += $tie_count;
            $tie_count = 0;
        }

        $ranked[] = [
            'student_id' => $row['student_id'],
            'name' => $row['name'],
            'total_score' => round($row['total_score'], 2),
            'position' => ordinal($position)
        ];

        $last_score = $row['total_score'];
    }

    return $ranked;
}

function calculateTermAverage(PDO $conn, int $student_id, string $term): float {
    $stmt = $conn->prepare("
        SELECT AVG(sc.average * sub.coefficient) / AVG(sub.coefficient) AS weighted_avg
        FROM scores sc
        JOIN subjects sub ON sc.subject_id = sub.id
        WHERE sc.student_id = ? AND sc.term = ?
    ");
    $stmt->execute([$student_id, $term]);
    return round((float)$stmt->fetchColumn(), 2);
}

function getStudentRanking(PDO $conn, int $student_id, int $class_id, string $term): array {
    $stmt = $conn->prepare("
        SELECT s.id, s.name,
               SUM(sc.average * sub.coefficient) / SUM(sub.coefficient) AS weighted_avg
        FROM students s
        JOIN scores sc ON s.id = sc.student_id
        JOIN subjects sub ON sc.subject_id = sub.id
        WHERE s.class_id = ? AND sc.term = ?
        GROUP BY s.id
        ORDER BY weighted_avg DESC
    ");
    $stmt->execute([$class_id, $term]);
    $rankings = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $position = 0;
    foreach ($rankings as $index => $student) {
        if ($student['id'] == $student_id) {
            $position = $index + 1;
            break;
        }
    }
    
    return [
        'position' => $position,
        'total_students' => count($rankings),
        'rankings' => $rankings
    ];
}

function ordinal(int $n): string {
    if (in_array($n % 100, [11, 12, 13])) return $n . 'th';
    $suffix = ['th','st','nd','rd','th','th','th','th','th','th'][$n % 10];
    return $n . $suffix;
}
?>
