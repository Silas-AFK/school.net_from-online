<?php
// samo/includes/config.php
declare(strict_types=1);

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Prevent multiple inclusions
if (!defined('CONFIG_LOADED')) {
    define('CONFIG_LOADED', true);

    $host    = 'MYSQL8001.site4now.net';
    $db      = 'db_aae8a0_mercy';
    $user    = 'aae8a0_mercy';
    $pass    = 'Af@nwi676'; 
    $charset = 'utf8mb4';

    $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];

    try {
        $pdo = new PDO($dsn, $user, $pass, $options);
    } catch (PDOException $e) {
        error_log('Database connection failed: ' . $e->getMessage());
        exit('Database connection failed. Please check your configuration.');
    }

    $school_name = 'Caroma School';
    $principal_name = 'Principal';
    $logo_url = '';

    try {
        $stmt = $pdo->query("SELECT school_name, principal_name, logo_url FROM school_info LIMIT 1");
        $school_info = $stmt->fetch();
        if ($school_info) {
            $school_name = $school_info['school_name'] ?? 'Caroma School';
            $principal_name = $school_info['principal_name'] ?? 'Principal';
            $logo_url = $school_info['logo_url'] ?? '';
        }
    } catch (PDOException $e) {
        // School info not yet configured, use defaults
    }
}
?>
