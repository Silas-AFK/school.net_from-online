<?php
// samo/includes/auth.php — Authentication and authorization
declare(strict_types=1);

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in
function isLoggedIn(): bool {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

// Require authentication, but avoid redirect loop on login page
function requireAuth(): void {
    $currentPage = basename($_SERVER['PHP_SELF']);
    if (!isLoggedIn() && $currentPage !== 'login.php' && $currentPage !== 'teacher_login.php') {
        header("Location: ../public/login.php");
        exit;
    }
}

function requireRole(string $role): void {
    requireAuth();

    $currentPage = basename($_SERVER['PHP_SELF']);
    if (!isset($_SESSION['role']) || $_SESSION['role'] !== $role) {
        if (isset($_SESSION['role']) && $_SESSION['role'] === 'teacher' && $role === 'admin') {
            header("Location: teacher_dashboard.php");
            exit;
        }
        // Otherwise redirect to login
        if ($currentPage !== 'login.php' && $currentPage !== 'teacher_login.php') {
            header("Location: ../public/login.php");
            exit;
        }
    }
}

function requireAnyRole(array $allowedRoles): void {
    requireAuth();
    
    $currentPage = basename($_SERVER['PHP_SELF']);
    $userRole = $_SESSION['role'] ?? null;
    
    if (!in_array($userRole, $allowedRoles, true)) {
        // Redirect to appropriate dashboard based on role
        if ($userRole === 'teacher') {
            header("Location: teacher_dashboard.php");
            exit;
        } elseif ($userRole === 'admin') {
            header("Location: dashboard.php");
            exit;
        } else {
            header("Location: ../public/login.php");
            exit;
        }
    }
}

function getDashboardUrl(): string {
    $userRole = $_SESSION['role'] ?? null;
    if ($userRole === 'teacher') {
        return 'teacher_dashboard.php';
    }
    return 'dashboard.php';
}

// Get current user ID
function getCurrentUserId(): ?int {
    return $_SESSION['user_id'] ?? null;
}

// Get current username
function getCurrentUsername(): ?string {
    return $_SESSION['username'] ?? null;
}

// Get current user role
function getCurrentUserRole(): ?string {
    return $_SESSION['role'] ?? null;
}
?>
