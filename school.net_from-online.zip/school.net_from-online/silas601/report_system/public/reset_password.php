<?php
// Temporary script to reset admin password
// Run this once: http://localhost/samo2/reset_password.php
// Then delete this file for security

require_once __DIR__ . '/includes/db.php';

try {
    // Generate correct hash for "admin123"
    $password = 'admin123';
    $hash = password_hash($password, PASSWORD_BCRYPT);
    
    // Update admin user
    $stmt = $conn->prepare('UPDATE users SET password_hash = :hash WHERE username = :username');
    $stmt->execute([
        ':hash' => $hash,
        ':username' => 'admin'
    ]);
    
    echo "<!DOCTYPE html>
    <html>
    <head>
        <title>Password Reset</title>
        <style>
            body { font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; padding: 20px; }
            .success { background: #d4edda; color: #155724; padding: 20px; border-radius: 8px; border: 1px solid #c3e6cb; }
            .info { background: #d1ecf1; color: #0c5460; padding: 15px; border-radius: 8px; margin-top: 20px; border: 1px solid #bee5eb; }
            h1 { color: #333; }
            code { background: #f4f4f4; padding: 2px 6px; border-radius: 3px; }
        </style>
    </head>
    <body>
        <h1>Password Reset Successful</h1>
        <div class='success'>
            <strong>Admin password has been reset!</strong><br><br>
            Username: <code>admin</code><br>
            Password: <code>admin123</code>
        </div>
        <div class='info'>
            <strong>Important:</strong> For security, please delete this file (<code>reset_password.php</code>) immediately after use.
        </div>
        <p><a href='public/login.php'>Go to Login Page</a></p>
    </body>
    </html>";
    
} catch (PDOException $e) {
    echo "Error: " . htmlspecialchars($e->getMessage());
}
?>
