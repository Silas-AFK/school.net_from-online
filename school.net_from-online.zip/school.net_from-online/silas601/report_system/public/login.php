<?php
// samo/public/login.php
declare(strict_types=1);
session_start(); // Required for session handling

// CSRF token functions
function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf(string $token): bool {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

// Escape output
function e(string $s): string {
    return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

$error = '';
$submitted_username = '';

// Redirect if already logged in
if (!empty($_SESSION['user_id'])) {
    header('Location: ../admin/dashboard.php');
    exit;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $submitted_username = trim($_POST['username'] ?? '');
    $submitted_password = $_POST['password'] ?? '';
    $posted_csrf        = $_POST['csrf_token'] ?? '';

    if (!verify_csrf($posted_csrf)) {
        $error = 'Invalid request (CSRF token mismatch).';
    } elseif ($submitted_username === '' || $submitted_password === '') {
        $error = 'Please enter both username and password.';
    } elseif ($submitted_username === 'admin' && $submitted_password === 'admin123') {
        // Hardcoded login success
        session_regenerate_id(true);
        $_SESSION['user_id']   = 1;
        $_SESSION['username']  = 'admin';
        $_SESSION['role']      = 'admin';
        unset($_SESSION['csrf_token']);
        header('Location: ../admin/dashboard.php');
        exit;
    } else {
        $error = 'Invalid username or password.';
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Login — Caroma Report Card System</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="stylesheet" href="../assets/css/style.css">
<style>* { margin: 0; 
padding: 0;
 box-sizing:
  border-box;
 }
   body { 
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
 background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
 min-height: 100vh; display: flex; justify-content: center;
  align-items: center; 
  padding: 20px;
   }
    .container {
         background: white; 
         padding: 40px;
          max-width: 450px;
           width: 100%; 
           box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            border-radius: 20px; } .logo { width: 80px; 
            height: 80px; margin: 0 auto 20px; display: block;
             border-radius: 50%; 
             object-fit: cover;
              }
               h1{
                 color: #333; 
                 font-size: 1.8em;
                  margin-bottom: 10px;
                   text-align: center; } .subtitle { color: #666; text-align: center; margin-bottom: 30px; } .error { background: #fee; color: #c33; padding: 12px; border-radius: 8px; margin-bottom: 20px; border-left: 4px solid #c33; } .form-group { margin-bottom: 20px; } label { display: block; color: #333; font-weight: 600; margin-bottom: 8px; } input[type="text"], input[type="password"] { width: 100%; padding: 12px 15px; border: 2px solid #e0e0e0; border-radius: 8px; font-size: 1em; transition: border-color 0.3s; } input[type="text"]:focus, input[type="password"]:focus { outline: none; border-color: #667eea; } button { width: 100%; padding: 14px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: bold; font-size: 1.1em; transition: transform 0.3s, box-shadow 0.3s; } button:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(102, 126, 234, 0.4); } .back-link { text-align: center; margin-top: 20px; } .back-link a { color: #667eea; text-decoration: none; font-weight: 600; } .back-link a:hover { text-decoration: underline; } </style>
<style>
    /* Your existing CSS remains unchanged */
</style>
</head>
<body>
<div class="container">
    <img src="../assets/images/caro.jpg" alt="Caroma Logo" class="logo" onerror="this.src='../assets/images/school-logo.jpg'">
    <h1>Sign In</h1>
    <p class="subtitle">Caroma Report Card System</p>

    <?php if ($error): ?>
        <div class="error"><?= e($error) ?></div>
    <?php endif; ?>

    <form method="post" action="">
        <div class="form-group">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" value="<?= e($submitted_username) ?>" required autofocus>
        </div>
        
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>
        </div>
        
        <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
        <button type="submit">Login</button><br><br>
      
    </form>
     <a href="teacher_login.php"> <button style="decoration:non;">Teacher_Login</button></a>
    <div class="back-link">
        <a href="../index.php">← Back to Home</a>
    </div>
</div>
</body>
</html>
