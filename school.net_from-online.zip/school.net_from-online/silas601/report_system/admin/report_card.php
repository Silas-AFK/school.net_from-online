<?php
ob_start();

require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';
requireRole('admin');

require_once __DIR__ . '/../pdf/fpdf/fpdf.php';
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetLineWidth(0.5);
$pdf->Rect(10, 10, 190, 277);

require_once __DIR__ . '/../qrcode/phpqrcode/phpqrcode.php';

if (!isset($_GET['student_id']) || !isset($_GET['term'])) {
    ob_end_clean();
    die("Missing student ID or term parameter.");
}

$student_id = (int)$_GET['student_id'];
$term = $_GET['term'];

$school_info = $conn->query("SELECT * FROM school_info LIMIT 1")->fetch(PDO::FETCH_ASSOC);
$school_name = $school_info['school_name'] ?? 'CAROMA COMPREHENSIVE EDUCATION CENTER (CCEC) BAMENDA';
$motto = $school_info['motto'] ?? 'Education for All Students';
$contact_info = $school_info['contact_info'] ?? '';
$additional_info = $school_info['additional_info'] ?? '';
$school_logo = '../assets/images/school-logo.jpg';

$student_stmt = $conn->prepare("
    SELECT DISTINCT s.*, c.name AS class_name
    FROM students s
    JOIN classes c ON s.class_id = c.id
    WHERE s.id = ?
    LIMIT 1
");
$student_stmt->execute([$student_id]);
$student = $student_stmt->fetch(PDO::FETCH_ASSOC);

if (!$student) {
    ob_end_clean();
    die("Student not found.");
}

$subject_rankings = [];
$subjects_stmt = $conn->query("SELECT id FROM subjects ORDER BY name");
$all_subjects = $subjects_stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($all_subjects as $subj) {
    $rank_stmt = $conn->prepare("
        SELECT DISTINCT sc.student_id, sc.average
        FROM scores sc
        JOIN students s ON sc.student_id = s.id
        WHERE s.class_id = ? AND sc.subject_id = ? AND sc.term = ?
        GROUP BY sc.student_id
        ORDER BY sc.average DESC
    ");
    $rank_stmt->execute([$student['class_id'], $subj['id'], $term]);
    $ranked = $rank_stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $position = 1;
    foreach ($ranked as $r) {
        if ($r['student_id'] == $student_id) {
            $subject_rankings[$subj['id']] = ordinal($position);
            break;
        }
        $position++;
    }
}

$scores_stmt = $conn->prepare("
    SELECT DISTINCT
        sub.id AS subject_id,
        sub.name AS subject,
        sc.seq1,
        sc.seq2,
        sc.average,
        sub.coefficient,
        (sc.average * sub.coefficient) AS weighted_score,
        sc.grade,
        sc.remark,
        st.teacher_name
    FROM scores sc
    JOIN subjects sub ON sc.subject_id = sub.id
    LEFT JOIN subject_teachers st ON sub.id = st.subject_id
    WHERE sc.student_id = ? AND sc.term = ?
    GROUP BY sub.id, sub.name, sc.seq1, sc.seq2, sc.average, sub.coefficient, sc.grade, sc.remark, st.teacher_name
    ORDER BY sub.name
");
$scores_stmt->execute([$student_id, $term]);
$scores = $scores_stmt->fetchAll(PDO::FETCH_ASSOC);

$class_students = $conn->prepare("
    SELECT DISTINCT s.id, s.name,
           SUM(sc.average * sub.coefficient) / NULLIF(SUM(sub.coefficient), 0) AS student_avg
    FROM students s
    JOIN scores sc ON s.id = sc.student_id
    JOIN subjects sub ON sc.subject_id = sub.id
    WHERE s.class_id = ? AND sc.term = ?
    GROUP BY s.id, s.name
    HAVING student_avg IS NOT NULL
    ORDER BY student_avg DESC
");
$class_students->execute([$student['class_id'], $term]);
$rankings = $class_students->fetchAll(PDO::FETCH_ASSOC);

$student_rank = 0;
$class_average = 0;
$highest_average = 0;
$lowest_average = null;
$total_students = count($rankings);
$students_passed_count = 0;

if ($total_students > 0) {
    foreach ($rankings as $index => $ranked_student) {
        $avg = (float)$ranked_student['student_avg'];
        
        if ($ranked_student['id'] == $student_id) {
            $student_rank = $index + 1;
        }
        
        $class_average += $avg;
        
        if ($avg > $highest_average) {
            $highest_average = $avg;
        }
        
        if ($lowest_average === null || $avg < $lowest_average) {
            $lowest_average = $avg;
        }
        
        if ($avg >= 10) {
            $students_passed_count++;
        }
    }
    
    $class_average = round($class_average / $total_students, 2);
    $highest_average = round($highest_average, 2);
    $lowest_average = round($lowest_average, 2);
} else {
    $lowest_average = 0;
}

$total_weighted = 0;
$total_coef = 0;
$subjects_passed = 0;

foreach ($scores as $score) {
    $total_weighted += $score['weighted_score'];
    $total_coef += $score['coefficient'];
    if ($score['average'] >= 10) {
        $subjects_passed++;
    }
}

$student_average = $total_coef > 0 ? round($total_weighted / $total_coef, 2) : 0;

if (!function_exists('getOverallRemark')) {
    function getOverallRemark($avg) {
        if ($avg >= 16) return 'Excellent';
        if ($avg >= 14) return 'Very Good';
        if ($avg >= 12) return 'Good';
        if ($avg >= 10) return 'Fair';
        return 'Poor';
    }
}

$overall_remark = getOverallRemark($student_average);

if ($term == '3rd') {
    $pass_status = $student_average >= 10 ? 'PROMOTED' : 'REPEAT';
} else {
    $pass_status = $student_average >= 10 ? 'PASSED' : 'FAILED';
}
$status_color = $student_average >= 10 ? [0, 0, 255] : [255, 0, 0];

$summary_stmt = $conn->prepare("SELECT * FROM report_summary WHERE student_id = ? AND term = ? LIMIT 1");
$summary_stmt->execute([$student_id, $term]);
$summary = $summary_stmt->fetch(PDO::FETCH_ASSOC);

if ($summary && isset($summary['promoted'])) {
    $pass_status = $summary['promoted'];
}

$hours_absence = $summary['hours_absence'] ?? 0;
$hours_punishment = $summary['hours_punishment'] ?? 0;
$days_suspension = $summary['days_suspension'] ?? 0;
$warning = $summary['warning'] ?? 'No';
$dismissed = $summary['dismissed'] ?? 'no';
$next_term_begins = $school_info['next_term_begins'] ?? '';

class ReportCardPDF extends FPDF {
    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->Cell(0, 10, 'Produced by Osiris', 0, 0, 'L');
        $this->Cell(0, 10, 'Printed on: ' . date('d/m/Y'), 0, 0, 'R');
    }
}

$pdf = new ReportCardPDF('P', 'mm', 'A4');
$pdf->AddPage();
$pdf->SetAutoPageBreak(false);
$pdf->SetMargins(10, 10, 10);

$pdf->SetFont('Arial', 'B', 9);
$pdf->SetFont('Arial', 'B', 11);

$pdf->SetXY(10, 10);
$pdf->MultiCell(60, 6, "REPUBLIQUE DU CAMEROUN\nPaix - Travail - Patrie\nMINISTERE DES ENSEIGNEMENTS SECONDAIRES", 0, 'L');

$pdf->SetXY(140, 10);
$pdf->MultiCell(60, 6, "REPUBLIC OF CAMEROON\nPeace - Work - FatherLand\nMINISTRY OF SECONDARY EDUCATION", 0, 'R');

$logo_path = __DIR__ . '/' . $school_logo;
if (file_exists($logo_path)) {
    $pdf->Image($logo_path, 90, 8, 34, 34);
}

$pdf->SetFont('Arial', 'B', 13);
$pdf->SetXY(10, 45);
$pdf->MultiCell(190, 6, $school_name, 0, 'C');

$pdf->SetFont('Arial', 'I', 9);
$pdf->SetX(10);
$pdf->Cell(190, 5, $motto, 0, 1, 'C');

if (!empty($contact_info) || !empty($additional_info)) {
    $pdf->SetFont('Arial', '', 8);
    $pdf->SetX(10);
    if (!empty($contact_info)) {
        $pdf->MultiCell(190, 4, $contact_info, 0, 'C');
    }
    if (!empty($additional_info)) {
        $pdf->MultiCell(190, 4, $additional_info, 0, 'C');
    }
}

$pdf->SetFillColor(0, 0, 128);
$pdf->SetTextColor(255, 255, 255);
$pdf->SetFont('Arial', 'B', 11);
$pdf->SetXY(10, 57);
$academic_year = $school_info['academic_year'] ?? '2023-2024';
$term_text = strtoupper(str_replace(['1st', '2nd', '3rd'], ['FIRST', 'SECOND', 'THIRD'], $term)) . " TERM REPORT SHEET " . $academic_year;
$pdf->Cell(190, 7, $term_text, 1, 1, 'C', true);

$pdf->SetFillColor(255, 255, 255);
$pdf->SetTextColor(0, 0, 0);

$y_info = 66;
$pdf->SetFont('Arial', '', 9);

$pdf->SetXY(10, $y_info);
$pdf->Cell(80, 6, "NAME: " . strtoupper($student['name']), 1, 0, 'L');
$pdf->Cell(30, 24, '', 1, 0, 'C');
$pdf->Cell(80, 6, "AD.NO: " . $student['admission_no'], 1, 1, 'L');

$pdf->SetX(10);
$pdf->Cell(80, 6, "DATE OF BIRTH: " . date('F d, Y', strtotime($student['dob'])), 1, 0, 'L');
$pdf->SetX(120);
$pdf->Cell(80, 6, "CLASS: " . $student['class_name'], 1, 1, 'L');

$pdf->SetX(10);
$pdf->Cell(80, 6, "PLACE OF BIRTH: " . strtoupper($student['place_of_birth'] ?? 'N/A'), 1, 0, 'L');
$pdf->SetX(120);
$pdf->Cell(80, 6, "REPEATER?: " . strtoupper($student['repeater'] ?? 'NO'), 1, 1, 'L');

$pdf->SetX(10);
$pdf->Cell(80, 6, "SEX: " . ucfirst($student['sex']), 1, 0, 'L');
$pdf->SetX(120);
$pdf->Cell(80, 6, "ENROLMENT: " . $total_students, 1, 1, 'L');

$qr_file = 'qr_' . $student_id . '.png';
QRcode::png($student_id, $qr_file);
if (file_exists($qr_file)) {
    $pdf->Image($qr_file, 95, $y_info + 2, 20, 20);
}

$pdf->SetFont('Arial', 'B', 7.5);
$y_table = $pdf->GetY() + 1;
$pdf->SetXY(10, $y_table);

$pdf->SetFillColor(144, 238, 144);
$pdf->Cell(7, 7, 'S/N', 1, 0, 'C', true);
$pdf->Cell(42, 7, 'SUBJECT', 1, 0, 'C', true);
$pdf->Cell(13, 7, 'Seq1', 1, 0, 'C', true);
$pdf->Cell(13, 7, 'Seq2', 1, 0, 'C', true);
$pdf->Cell(13, 7, 'Avg', 1, 0, 'C', true);
$pdf->Cell(11, 7, 'Coef', 1, 0, 'C', true);
$pdf->Cell(16, 7, 'Av x Coef', 1, 0, 'C', true);
$pdf->Cell(11, 7, 'Rank', 1, 0, 'C', true);
$pdf->Cell(19, 7, 'REMARK', 1, 0, 'C', true);
$pdf->Cell(28, 7, 'TEACHER', 1, 0, 'C', true);
$pdf->Cell(17, 7, 'SIGN', 1, 1, 'C', true);

$pdf->SetFont('Arial', '', 7.5);
$sn = 1;

foreach ($scores as $score) {
    $fill_color = ($sn % 2 == 0) ? [255, 255, 224] : [255, 255, 255];
    $pdf->SetFillColor($fill_color[0], $fill_color[1], $fill_color[2]);
    
    $seq1_red = $score['seq1'] < 15;
    $seq2_red = $score['seq2'] < 15;
    $remark_red = strtolower($score['remark']) == 'very poor';
    
    $pdf->SetX(10);
    $pdf->Cell(7, 6, $sn, 1, 0, 'C', true);
    $pdf->Cell(42, 6, $score['subject'], 1, 0, 'L', true);
    
    // Seq1 - Red if < 15
    if ($seq1_red) {
        $pdf->SetTextColor(255, 0, 0);
    }
    $pdf->Cell(13, 6, number_format($score['seq1'], 2), 1, 0, 'C', true);
    $pdf->SetTextColor(0, 0, 0);
    
    // Seq2 - Red if < 15
    if ($seq2_red) {
        $pdf->SetTextColor(255, 0, 0);
    }
    $pdf->Cell(13, 6, number_format($score['seq2'], 2), 1, 0, 'C', true);
    $pdf->SetTextColor(0, 0, 0);
    
    $pdf->Cell(13, 6, number_format($score['average'], 2), 1, 0, 'C', true);
    $pdf->Cell(11, 6, $score['coefficient'], 1, 0, 'C', true);
    $pdf->Cell(16, 6, number_format($score['weighted_score'], 2), 1, 0, 'C', true);
    $pdf->Cell(11, 6, $subject_rankings[$score['subject_id']] ?? '-', 1, 0, 'C', true);
    
    // Remark - Red if "very poor"
    if ($remark_red) {
        $pdf->SetTextColor(255, 0, 0);
    }
    $pdf->Cell(19, 6, $score['remark'], 1, 0, 'C', true);
    $pdf->SetTextColor(0, 0, 0);
    
    $pdf->Cell(28, 6, $score['teacher_name'] ?? '', 1, 0, 'L', true);
    $pdf->Cell(17, 6, 'sign', 1, 1, 'C', true);
    
    $sn++;
}

$total_template_rows = 13;
$empty_rows = max(0, $total_template_rows - count($scores));
for ($i = 0; $i < $empty_rows; $i++) {
    $fill_color = ($sn % 2 == 0) ? [255, 255, 224] : [255, 255, 255];
    $pdf->SetFillColor($fill_color[0], $fill_color[1], $fill_color[2]);
    
    $pdf->SetX(10);
    $pdf->Cell(7, 6, '', 1, 0, 'C', true);
    $pdf->Cell(42, 6, '', 1, 0, 'L', true);
    $pdf->Cell(13, 6, '', 1, 0, 'C', true);
    $pdf->Cell(13, 6, '', 1, 0, 'C', true);
    $pdf->Cell(13, 6, '', 1, 0, 'C', true);
    $pdf->Cell(11, 6, '', 1, 0, 'C', true);
    $pdf->Cell(16, 6, '', 1, 0, 'C', true);
    $pdf->Cell(11, 6, '', 1, 0, 'C', true);
    $pdf->Cell(19, 6, '', 1, 0, 'C', true);
    $pdf->Cell(28, 6, '', 1, 0, 'L', true);
    $pdf->Cell(17, 6, '', 1, 1, 'C', true);
    $sn++;
}

$pdf->SetFont('Arial', 'B', 8);
$pdf->SetX(10);
$pdf->Cell(67, 6, '', 0, 0);
$pdf->Cell(27, 6, 'Total', 1, 0, 'C');
$pdf->Cell(11, 6, $total_coef, 1, 0, 'C');
$pdf->Cell(16, 6, number_format($total_weighted, 2), 1, 1, 'C');

$pdf->SetFont('Arial', '', 8);
$pdf->SetX(10);
$pdf->Cell(190, 4, 'Next Term Begins on: ' . ($next_term_begins ? date('d/m/Y', strtotime($next_term_begins)) : ''), 1, 1, 'R');

$y_summary = $pdf->GetY() + 1;
$pdf->SetXY(10, $y_summary);
$pdf->SetFillColor(0, 0, 0);
$pdf->Cell(190, 5, '', 1, 1, 'C', true);

$pdf->SetFillColor(255, 255, 255);
$pdf->SetTextColor(0, 0, 0);
$pdf->SetFont('Arial', '', 8);

$pdf->SetX(10);
$pdf->Cell(75, 6, "First Term Av.", 1, 0, 'L');
$pdf->Cell(20, 6, $term == '1st' ? number_format($student_average, 2) : '', 1, 0, 'C');
$pdf->Cell(25, 6, "Average", 1, 0, 'L');
$pdf->Cell(20, 6, number_format($student_average, 2), 1, 0, 'C');
$pdf->Cell(30, 6, "Class Average", 1, 0, 'L');
$pdf->Cell(20, 6, number_format($class_average, 2), 1, 1, 'C');

$pdf->SetX(10);
$pdf->Cell(75, 6, "Second Term Av.", 1, 0, 'L');
$pdf->Cell(20, 6, $term == '2nd' ? number_format($student_average, 2) : '', 1, 0, 'C');
$pdf->Cell(25, 6, "Rank", 1, 0, 'L');
$pdf->Cell(20, 6, ordinal($student_rank), 1, 0, 'C');
$pdf->Cell(30, 6, "Highest Average", 1, 0, 'L');
$pdf->Cell(20, 6, number_format($highest_average, 2), 1, 1, 'C');

$pdf->SetX(10);
$pdf->Cell(75, 6, "Third Term Av.", 1, 0, 'L');
$pdf->Cell(20, 6, $term == '3rd' ? number_format($student_average, 2) : '', 1, 0, 'C');
$pdf->Cell(25, 6, "Comment", 1, 0, 'L');
$pdf->Cell(20, 6, $overall_remark, 1, 0, 'C');
$pdf->Cell(30, 6, "Lowest Average", 1, 0, 'L');
$pdf->Cell(20, 6, number_format($lowest_average, 2), 1, 1, 'C');

$pdf->SetX(10);
$pdf->Cell(75, 6, "Anual Av.", 1, 0, 'L');
$pdf->Cell(20, 6, '', 1, 0, 'C');
$pdf->Cell(25, 6, "Subject Passed", 1, 0, 'L');
$pdf->Cell(20, 6, $subjects_passed, 1, 0, 'C');
$pdf->Cell(30, 6, "Class size", 1, 0, 'L');
$pdf->Cell(20, 6, $students_passed_count, 1, 1, 'C');

$pdf->SetX(10);
$pdf->Cell(75, 6, "Status", 1, 0, 'L');
$pdf->SetTextColor($status_color[0], $status_color[1], $status_color[2]);
$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(20, 6, $pass_status, 1, 0, 'C');
$pdf->SetTextColor(0, 0, 0);
$pdf->SetFont('Arial', '', 8);
$pdf->Cell(95, 6, '', 1, 1, 'C');

$pdf->SetX(10);
$pdf->SetFillColor(0, 0, 0);
$pdf->Cell(190, 5, '', 1, 1, 'C', true);

$pdf->SetFillColor(255, 255, 255);
$pdf->SetX(10);
$pdf->Cell(45, 6, "Hours of Absence", 1, 0, 'L');
$pdf->Cell(12, 6, $hours_absence, 1, 0, 'C');
$pdf->Cell(60, 6, '', 1, 1);

$pdf->SetX(10);
$pdf->Cell(45, 6, "Hours of Punishment", 1, 0, 'L');
$pdf->Cell(12, 6, $hours_punishment, 1, 0, 'C');
$pdf->Cell(60, 6, '', 1, 1);

$pdf->SetX(10);
$pdf->Cell(45, 6, "Days of Suspension", 1, 0, 'L');
$pdf->Cell(12, 6, $days_suspension, 1, 0, 'C');
$pdf->Cell(60, 6, '', 1, 1);

$pdf->SetX(10);
$pdf->Cell(45, 6, "Warning", 1, 0, 'L');
$pdf->Cell(12, 6, ucfirst($warning), 1, 0, 'C');
$pdf->Cell(60, 6, '', 1, 1);

$pdf->SetX(10);
$pdf->Cell(45, 6, "Dismissed", 1, 0, 'L');
$pdf->Cell(12, 6, $dismissed, 1, 0, 'C');
$pdf->Cell(60, 6, '', 1, 1);

$pdf->SetY(222);
$pdf->SetX(126.7);
$pdf->SetFillColor(144, 238, 144);
$pdf->SetFont('Arial', 'B', 9);
$pdf->Cell(73.8, 6, 'Principal Signature', 1, 1, 'C', true);

$pdf->SetX(126.7);
$pdf->SetFillColor(255, 255, 255);
$pdf->Cell(73.8, 29, '', 1, 1, 'L');

$pdf->Ln(10);
$pdf->SetFont('Arial', 'B', 10);
$pdf->SetX(10);

$marginLeft = 7;
$marginTop = 8;
$marginRight = 7;
$marginBottom = 36;
$pageWidth = 210;
$pageHeight = 297;
$borderWidth = $pageWidth - $marginLeft - $marginRight;
$borderHeight = $pageHeight - $marginTop - $marginBottom;

$pdf->SetLineWidth(0.4);
$pdf->Rect($marginLeft, $marginTop, $borderWidth, $borderHeight);

ob_end_clean();
$pdf->Output('I', $student['name'] . "_Report_Card_" . $term . "_Term.pdf");

if (file_exists($qr_file)) {
    unlink($qr_file);
}
?>
