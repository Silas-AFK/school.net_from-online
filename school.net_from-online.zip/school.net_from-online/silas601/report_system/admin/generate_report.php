<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';
requireRole('admin');

$classes = $conn->query("SELECT id, name FROM classes ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);

$report_data = [];
$class_id = $_GET['class_id'] ?? null;
$term = $_GET['term'] ?? null;

if ($class_id && $term) {
    $students_stmt = $conn->prepare("
        SELECT DISTINCT s.id, s.name, s.admission_no
        FROM students s
        WHERE s.class_id = ?
        GROUP BY s.id, s.name, s.admission_no
        ORDER BY s.name
    ");
    $students_stmt->execute([$class_id]);
    $students = $students_stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($students as $student) {
        $student_id = $student['id'];

        $scores_stmt = $conn->prepare("
            SELECT 
                SUM(sc.average * sub.coefficient) AS total_weighted,
                SUM(sub.coefficient) AS total_coef,
                COUNT(DISTINCT sc.subject_id) AS subject_count
            FROM scores sc
            JOIN subjects sub ON sc.subject_id = sub.id
            WHERE sc.student_id = ? AND sc.term = ?
            GROUP BY sc.student_id
        ");
        $scores_stmt->execute([$student_id, $term]);
        $result = $scores_stmt->fetch(PDO::FETCH_ASSOC);

        $total_weighted = $result['total_weighted'] ?? 0;
        $total_coef = $result['total_coef'] ?? 1;
        $average = $total_coef > 0 ? round($total_weighted / $total_coef, 2) : 0;
        
        $passed_stmt = $conn->prepare("
            SELECT COUNT(DISTINCT subject_id) FROM scores 
            WHERE student_id = ? AND term = ? AND average >= 10
        ");
        $passed_stmt->execute([$student_id, $term]);
        $subjects_passed = $passed_stmt->fetchColumn();

        if ($term == '3rd') {
            $status = $average >= 10 ? 'PROMOTED' : 'REPEAT';
        } else {
            $status = $average >= 10 ? 'PASSED' : 'FAILED';
        }

        $report_data[] = [
            'id' => $student_id,
            'name' => $student['name'],
            'admission_no' => $student['admission_no'],
            'total_weighted' => $total_weighted,
            'average' => $average,
            'subjects_passed' => $subjects_passed,
            'status' => $status
        ];
    }

    usort($report_data, fn($a, $b) => $b['average'] <=> $a['average']);

    foreach ($report_data as $index => &$student) {
        $student['position'] = ordinal($index + 1);
        
        $stmt = $conn->prepare("
            INSERT INTO report_summary 
            (student_id, term, total_marks, average, position, promoted, subjects_passed, no_passed)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                total_marks = VALUES(total_marks),
                average = VALUES(average),
                position = VALUES(position),
                promoted = VALUES(promoted),
                subjects_passed = VALUES(subjects_passed),
                no_passed = VALUES(no_passed)
        ");
        $stmt->execute([
            $student['id'],
            $term,
            $student['total_weighted'],
            $student['average'],
            $student['position'],
            $student['status'],
            $student['subjects_passed'],
            count($report_data)
        ]);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generate Reports</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
        }
        h2 {
            color: #333;
            margin-bottom: 30px;
            font-size: 2em;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }
        select {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 1em;
        }
        .btn {
            padding: 12px 30px;
            border: none;
            border-radius: 8px;
            font-size: 1em;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
        }
        .btn-primary {
            background: #667eea;
            color: white;
        }
        .btn-primary:hover {
            background: #5568d3;
            transform: translateY(-2px);
        }
        .btn-success {
            background: #28a745;
            color: white;
        }
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #e0e0e0;
        }
        th {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            font-weight: 600;
        }
        tr:hover {
            background: #f8f9fa;
        }
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #667eea;
            text-decoration: none;
            font-weight: 600;
        }
        .actions {
            margin-top: 30px;
        }
        .actions .btn {
            margin-right: 10px;
        }
        /* Added color styling for pass/fail status */
        .status-passed {
            color: #0000ff;
            font-weight: bold;
        }
        .status-failed {
            color: #ff0000;
            font-weight: bold;
        }
    </style>
</head>
<body>
<div class="container">
    <a href="dashboard.php" class="back-link">← Back to Dashboard</a>
    <h2>📊 Generate Class Reports</h2>

    <form method="GET">
        <div class="form-group">
            <label>Select Class:</label>
            <select name="class_id" required>
                <option value="">-- Choose Class --</option>
                <?php foreach ($classes as $class): ?>
                    <option value="<?= $class['id'] ?>" <?= $class_id == $class['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($class['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label>Select Term:</label>
            <select name="term" required>
                <option value="">-- Choose Term --</option>
                <option value="1st" <?= $term == '1st' ? 'selected' : '' ?>>1st Term</option>
                <option value="2nd" <?= $term == '2nd' ? 'selected' : '' ?>>2nd Term</option>
                <option value="3rd" <?= $term == '3rd' ? 'selected' : '' ?>>3rd Term</option>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Generate Report</button>
    </form>

    <?php if ($report_data): ?>
        <h3 style="margin-top: 40px; color: #333;">Report Summary - Term <?= htmlspecialchars($term) ?></h3>
        <table>
            <thead>
                <tr>
                    <th>Position</th>
                    <th>Admission No</th>
                    <th>Student Name</th>
                    <th>Average</th>
                    <th>Subjects Passed</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($report_data as $student): ?>
                    <tr>
                        <td><?= $student['position'] ?></td>
                        <td><?= htmlspecialchars($student['admission_no']) ?></td>
                        <td><?= htmlspecialchars($student['name']) ?></td>
                        <td><?= number_format($student['average'], 2) ?></td>
                        <td><?= $student['subjects_passed'] ?></td>
                        <td>
                             
                            <span class="<?= ($student['status'] == 'PROMOTED' || $student['status'] == 'PASSED') ? 'status-passed' : 'status-failed' ?>">
                                <?= $student['status'] ?>
                            </span>
                        </td>
                        <td>
                            <a href="report_card.php?student_id=<?= $student['id'] ?>&term=<?= urlencode($term) ?>" 
                               class="btn btn-success" 
                               target="_blank"
                               style="padding: 6px 12px; font-size: 0.9em;">
                                📄 View Report
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div class="actions">
            <a href="download_reports.php?class_id=<?= $class_id ?>&term=<?= urlencode($term) ?>" 
               class="btn btn-success">
                📦 Download All Reports (ZIP)
            </a>
            <a href="dashboard.php" class="btn btn-secondary">← Back to Dashboard</a>
        </div>
    <?php elseif ($class_id && $term): ?>
        <p style="margin-top: 20px; color: #666;">No data found for this class and term. Please ensure scores have been entered.</p>
    <?php endif; ?>
</div>
</body>
</html>
