<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';
requireAnyRole(['admin', 'teacher']);

$classes = $conn->query("SELECT id, name FROM classes ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
$subjects = $conn->query("SELECT id, name, coefficient FROM subjects ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);

$success = '';
$error = '';

// Handle score submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_scores'])) {
    $class_id = $_POST['class_id'];
    $subject_id = $_POST['subject_id'];
    $term = $_POST['term'];
    $seq1_scores = $_POST['seq1'] ?? [];
    $seq2_scores = $_POST['seq2'] ?? [];

    try {
        $conn->beginTransaction();
        
        foreach ($seq1_scores as $student_id => $seq1) {
            $seq2 = $seq2_scores[$student_id] ?? 0;
            
            // Calculate average and determine grade/remark
            $average = ((float)$seq1 + (float)$seq2) / 2;
            list($grade, $remark) = getGradeAndRemark($average);
            
            // Insert or update score
            $stmt = $conn->prepare("
                INSERT INTO scores (student_id, subject_id, term, seq1, seq2, grade, remark)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE 
                    seq1 = VALUES(seq1),
                    seq2 = VALUES(seq2),
                    grade = VALUES(grade),
                    remark = VALUES(remark)
            ");
            $stmt->execute([$student_id, $subject_id, $term, $seq1, $seq2, $grade, $remark]);
        }
        
        $conn->commit();
        $success = '✅ Scores saved successfully!';
    } catch (PDOException $e) {
        $conn->rollBack();
        error_log('Score entry error: ' . $e->getMessage());
        $error = '❌ Database error: ' . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enter Scores - Sequence System</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
        }
        h2 {
            color: #333;
            margin-bottom: 10px;
            font-size: 2em;
        }
        .subtitle {
            color: #666;
            margin-bottom: 30px;
            font-size: 1.1em;
        }
        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 500;
        }
        .alert-success {
            background: #d4edda;
            color: #155724;
            border-left: 4px solid #28a745;
        }
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border-left: 4px solid #dc3545;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }
        select, input[type="number"] {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 1em;
            transition: border-color 0.3s;
        }
        select:focus, input[type="number"]:focus {
            outline: none;
            border-color: #667eea;
        }
        .btn {
            padding: 12px 30px;
            border: none;
            border-radius: 8px;
            font-size: 1em;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        .btn-primary {
            background: #667eea;
            color: white;
        }
        .btn-primary:hover {
            background: #5568d3;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }
        .btn-success {
            background: #28a745;
            color: white;
        }
        .btn-success:hover {
            background: #218838;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(40, 167, 69, 0.4);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #e0e0e0;
        }
        th {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 0.9em;
            letter-spacing: 0.5px;
        }
        tr:hover {
            background: #f8f9fa;
        }
        tr:last-child td {
            border-bottom: none;
        }
        input[type="number"] {
            width: 100px;
            padding: 8px;
        }
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #667eea;
            text-decoration: none;
            font-weight: 600;
            transition: color 0.3s;
        }
        .back-link:hover {
            color: #5568d3;
        }
        .info-box {
            background: #e7f3ff;
            border-left: 4px solid #2196F3;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        .info-box strong {
            color: #1976D2;
        }
    </style>
</head>
<body>
<div class="container">
    <a href="<?= getDashboardUrl() ?>" class="back-link">← Back to Dashboard</a>
    <h2>📝 Enter Scores</h2>
    <p class="subtitle">Sequence-Based Grading System</p>

    <div class="info-box">
        <strong>ℹ️ Grading System:</strong><br>
        • <strong>1st Term:</strong> Sequence 1 + Sequence 2 → Pass/Fail<br>
        • <strong>2nd Term:</strong> Sequence 3 + Sequence 4 → Pass/Fail<br>
        • <strong>3rd Term:</strong> Sequence 5 + Sequence 6 → Promoted/Repeat
    </div>

    <?php if ($success): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="GET">
        <div class="form-group">
            <label>Select Class:</label>
            <select name="class_id" required>
                <option value="">-- Choose Class --</option>
                <?php foreach ($classes as $class): ?>
                    <option value="<?= $class['id'] ?>" <?= ($_GET['class_id'] ?? '') == $class['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($class['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label>Select Subject:</label>
            <select name="subject_id" required>
                <option value="">-- Choose Subject --</option>
                <?php foreach ($subjects as $subject): ?>
                    <option value="<?= $subject['id'] ?>" <?= ($_GET['subject_id'] ?? '') == $subject['id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($subject['name']) ?> (Coef: <?= $subject['coefficient'] ?>)
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label>Select Term:</label>
            <select name="term" required>
                <option value="">-- Choose Term --</option>
                <option value="1st" <?= ($_GET['term'] ?? '') == '1st' ? 'selected' : '' ?>>1st Term (Seq 1 & 2)</option>
                <option value="2nd" <?= ($_GET['term'] ?? '') == '2nd' ? 'selected' : '' ?>>2nd Term (Seq 3 & 4)</option>
                <option value="3rd" <?= ($_GET['term'] ?? '') == '3rd' ? 'selected' : '' ?>>3rd Term (Seq 5 & 6)</option>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Load Students</button>
    </form>

<?php
if (isset($_GET['class_id'], $_GET['subject_id'], $_GET['term'])) {
    $class_id = $_GET['class_id'];
    $subject_id = $_GET['subject_id'];
    $term = $_GET['term'];

    // Get students in the class
    $students_stmt = $conn->prepare("
        SELECT s.id, s.name, s.admission_no,
               sc.seq1, sc.seq2
        FROM students s
        LEFT JOIN scores sc ON s.id = sc.student_id 
            AND sc.subject_id = ? 
            AND sc.term = ?
        WHERE s.class_id = ?
        ORDER BY s.name
    ");
    $students_stmt->execute([$subject_id, $term, $class_id]);
    $students = $students_stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($students):
        // Get subject info
        $subject_info = $conn->prepare("SELECT name, coefficient FROM subjects WHERE id = ?");
        $subject_info->execute([$subject_id]);
        $subject = $subject_info->fetch(PDO::FETCH_ASSOC);
        
        $seq_labels = [
            '1st' => ['Seq 1', 'Seq 2'],
            '2nd' => ['Seq 3', 'Seq 4'],
            '3rd' => ['Seq 5', 'Seq 6']
        ];
        $labels = $seq_labels[$term];
?>
    <form method="POST">
        <input type="hidden" name="class_id" value="<?= htmlspecialchars($class_id) ?>">
        <input type="hidden" name="subject_id" value="<?= htmlspecialchars($subject_id) ?>">
        <input type="hidden" name="term" value="<?= htmlspecialchars($term) ?>">
        
        <h3 style="margin-top: 30px; color: #333;">
            Subject: <?= htmlspecialchars($subject['name']) ?> | 
            Coefficient: <?= $subject['coefficient'] ?> | 
            Term: <?= htmlspecialchars($term) ?>
        </h3>
        
        <table>
            <thead>
                <tr>
                    <th>Admission No</th>
                    <th>Student Name</th>
                    <th><?= $labels[0] ?></th>
                    <th><?= $labels[1] ?></th>
                    <th>Average</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($students as $student): ?>
                    <tr>
                        <td><?= htmlspecialchars($student['admission_no']) ?></td>
                        <td><?= htmlspecialchars($student['name']) ?></td>
                        <td>
                            <input type="number" 
                                   name="seq1[<?= $student['id'] ?>]" 
                                   value="<?= $student['seq1'] ?? '' ?>" 
                                   min="0" 
                                   max="100" 
                                   step="0.01" 
                                   placeholder="0.00"
                                   class="seq-input"
                                   data-student="<?= $student['id'] ?>">
                        </td>
                        <td>
                            <input type="number" 
                                   name="seq2[<?= $student['id'] ?>]" 
                                   value="<?= $student['seq2'] ?? '' ?>" 
                                   min="0" 
                                   max="100" 
                                   step="0.01" 
                                   placeholder="0.00"
                                   class="seq-input"
                                   data-student="<?= $student['id'] ?>">
                        </td>
                        <td>
                            <span id="avg-<?= $student['id'] ?>" style="font-weight: 600; color: #667eea;">
                                <?php 
                                if ($student['seq1'] !== null && $student['seq2'] !== null) {
                                    echo number_format(($student['seq1'] + $student['seq2']) / 2, 2);
                                } else {
                                    echo '--';
                                }
                                ?>
                            </span>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        
        <div style="margin-top: 30px;">
            <button type="submit" name="save_scores" class="btn btn-success">💾 Save All Scores</button>
        </div>
    </form>

    <script>
        // Auto-calculate average as user types
        document.querySelectorAll('.seq-input').forEach(input => {
            input.addEventListener('input', function() {
                const studentId = this.dataset.student;
                const seq1Input = document.querySelector(`input[name="seq1[${studentId}]"]`);
                const seq2Input = document.querySelector(`input[name="seq2[${studentId}]"]`);
                const avgSpan = document.getElementById(`avg-${studentId}`);
                
                const seq1 = parseFloat(seq1Input.value) || 0;
                const seq2 = parseFloat(seq2Input.value) || 0;
                const avg = (seq1 + seq2) / 2;
                
                avgSpan.textContent = avg.toFixed(2);
            });
        });
    </script>

<?php else: ?>
    <p style="margin-top: 20px; color: #666;">No students found in this class.</p>
<?php endif; } ?>
</div>
</body>
</html>
