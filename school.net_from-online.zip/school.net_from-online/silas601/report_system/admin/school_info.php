<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
requireRole('admin');

$success = '';
$error = '';

// Handle update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update'])) {
    $school_name = trim($_POST['school_name']);
    $school_name_french = trim($_POST['school_name_french']);
    $motto = trim($_POST['motto']);
    $principal_name = trim($_POST['principal_name']);
    $next_term_begins = $_POST['next_term_begins'] ?? null;
    $contact_info = trim($_POST['contact_info']);
    $additional_info = trim($_POST['additional_info']);

    $target_dir = __DIR__ . '/../assets/images/';
    if (!is_dir($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    // Handle logo upload
    if (!empty($_FILES['logo']['name'])) {
        $logo_filename = 'school-logo.png';
        $target_file = $target_dir . $logo_filename;
        
        if (move_uploaded_file($_FILES['logo']['tmp_name'], $target_file)) {
            $success = "✅ Logo uploaded successfully! ";
        } else {
            $error = "❌ Failed to upload logo. ";
        }
    }

    try {
        // Check if record exists
        $check = $conn->query("SELECT COUNT(*) FROM school_info WHERE id = 1")->fetchColumn();
        
        if ($check > 0) {
            $stmt = $conn->prepare("
                UPDATE school_info 
                SET school_name = ?, school_name_french = ?, motto = ?, principal_name = ?, next_term_begins = ?, contact_info = ?, additional_info = ?
                WHERE id = 1
            ");
            $stmt->execute([$school_name, $school_name_french, $motto, $principal_name, $next_term_begins, $contact_info, $additional_info]);
        } else {
            $stmt = $conn->prepare("
                INSERT INTO school_info (id, school_name, school_name_french, motto, principal_name, academic_year, current_term, next_term_begins, contact_info, additional_info)
                VALUES (1, ?, ?, ?, ?, '2024-2025', '1st', ?, ?, ?)
            ");
            $stmt->execute([$school_name, $school_name_french, $motto, $principal_name, $next_term_begins, $contact_info, $additional_info]);
        }
        
        $success .= "✅ School information updated successfully!";
    } catch (PDOException $e) {
        error_log('School info update error: ' . $e->getMessage());
        $error .= "❌ Database error: " . $e->getMessage();
    }
}

// Fetch current info
try {
    $info = $conn->query("SELECT * FROM school_info WHERE id = 1")->fetch(PDO::FETCH_ASSOC);
    if (!$info) {
        $info = [
            'school_name' => 'ABC BILINGUAL SECONDARY SCHOOL JUPITER',
            'school_name_french' => 'MINISTERE DES ENSEIGNEMENTS SECONDAIRES',
            'motto' => 'Education for All Students',
            'principal_name' => '',
            'next_term_begins' => null,
            'contact_info' => '',
            'additional_info' => ''
        ];
    }
} catch (PDOException $e) {
    $info = [
        'school_name' => 'ABC BILINGUAL SECONDARY SCHOOL JUPITER',
        'school_name_french' => 'MINISTERE DES ENSEIGNEMENTS SECONDAIRES',
        'motto' => 'Education for All Students',
        'principal_name' => '',
        'next_term_begins' => null,
        'contact_info' => '',
        'additional_info' => ''
    ];
}

$school_name = $info['school_name'];
$school_name_french = $info['school_name_french'];
$motto = $info['motto'];
$principal_name = $info['principal_name'];
$next_term_begins = $info['next_term_begins'] ?? null;
$contact_info = $info['contact_info'] ?? '';
$additional_info = $info['additional_info'] ?? '';
$logo_exists = file_exists(__DIR__ . '/../assets/images/school-logo.png');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>School Information Settings</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
        }
        h2 {
            color: #333;
            margin-bottom: 10px;
            font-size: 2em;
        }
        .subtitle {
            color: #666;
            margin-bottom: 30px;
        }
        .alert {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 500;
        }
        .alert-success {
            background: #d4edda;
            color: #155724;
            border-left: 4px solid #28a745;
        }
        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border-left: 4px solid #dc3545;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }
        input[type="text"], input[type="file"], input[type="date"], textarea {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 1em;
            font-family: inherit;
        }
        textarea {
            resize: vertical;
            min-height: 80px;
        }
        .btn {
            padding: 12px 30px;
            border: none;
            border-radius: 8px;
            font-size: 1em;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
        }
        .btn-primary {
            background: #667eea;
            color: white;
        }
        .btn-primary:hover {
            background: #5568d3;
            transform: translateY(-2px);
        }
        .logo-preview {
            margin-top: 10px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 8px;
        }
        .logo-preview img {
            max-width: 200px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
        }
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #667eea;
            text-decoration: none;
            font-weight: 600;
        }
        .back-link:hover {
            color: #5568d3;
        }
        .info-box {
            background: #e7f3ff;
            border-left: 4px solid #2196F3;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        small {
            color: #666;
            display: block;
            margin-top: 5px;
        }
    </style>
</head>
<body>
<div class="container">
    <a href="dashboard.php" class="back-link">← Back to Dashboard</a>
    <h2>🏫 School Information Settings</h2>
    <p class="subtitle">Configure school details for report cards</p>

    <?php if ($success): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="info-box">
        <strong>ℹ️ Note:</strong> All information configured here will appear on every student report card. Contact information and additional info will display below the school name and motto on all report cards.
    </div>

    <form method="POST" enctype="multipart/form-data">
        <div class="form-group">
            <label>School Name (English):</label>
            <input type="text" name="school_name" value="<?= htmlspecialchars($school_name) ?>" required placeholder="ABC BILINGUAL SECONDARY SCHOOL JUPITER">
        </div>

        <div class="form-group">
            <label>School Name (French):</label>
            <input type="text" name="school_name_french" value="<?= htmlspecialchars($school_name_french) ?>" required placeholder="MINISTERE DES ENSEIGNEMENTS SECONDAIRES">
        </div>

        <div class="form-group">
            <label>School Motto:</label>
            <input type="text" name="motto" value="<?= htmlspecialchars($motto) ?>" required placeholder="Education for All Students">
        </div>

        <div class="form-group">
            <label>Principal Name:</label>
            <input type="text" name="principal_name" value="<?= htmlspecialchars($principal_name) ?>" required placeholder="Dr. John Smith">
        </div>

        <!-- Contact Information field - displays on all report cards below school name and motto -->
        <div class="form-group">
            <label>School Contact Information:</label>
            <textarea name="contact_info" placeholder="e.g., Phone: +237 123 456 789, Email: info@school.edu, Address: 123 Main Street"><?= htmlspecialchars($contact_info) ?></textarea>
            <small>Enter phone, email, address, or other contact details. This will appear on all student report cards.</small>
        </div>

        <!-- Additional School Information field - displays on all report cards below school name and motto -->
        <div class="form-group">
            <label>Additional School Information:</label>
            <textarea name="additional_info" placeholder="e.g., Registration Number, Affiliation, Accreditation details, or any other relevant information"><?= htmlspecialchars($additional_info) ?></textarea>
            <small>Enter any additional school information you want displayed on report cards.</small>
        </div>

        <div class="form-group">
            <label>Next Term Begins (applies to all report cards):</label>
            <input type="date" name="next_term_begins" value="<?= htmlspecialchars($next_term_begins ?? '') ?>" placeholder="Select date">
            <small>This date will appear on all student report cards automatically.</small>
        </div>

        <div class="form-group">
            <label>School Logo (PNG format recommended):</label>
            <input type="file" name="logo" accept="image/*">
            
            <?php if ($logo_exists): ?>
                <div class="logo-preview">
                    <p style="margin-bottom: 10px; font-weight: 600;">Current Logo:</p>
                    <img src="../assets/images/school-logo.png?<?= time() ?>" alt="School Logo">
                </div>
            <?php endif; ?>
        </div>

        <button type="submit" name="update" class="btn btn-primary">💾 Update School Information</button>
    </form>
</div>
</body>
</html>
