<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
requireRole('admin');

if (!isset($_GET['type'])) {
    echo "Missing export type.";
    exit;
}

$type = $_GET['type'];
$filename = $type . '_export_' . date('Ymd_His') . '.csv';

header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="' . $filename . '"');

$output = fopen('php://output', 'w');

if ($type === 'students') {
    fputcsv($output, ['Name', 'Admission No', 'Class', 'Sex', 'DOB', 'Place of Birth']);

    $stmt = $conn->query("SELECT s.name, s.admission_no, c.name AS class, s.sex, s.dob, s.place_of_birth
                          FROM students s
                          JOIN classes c ON s.class_id = c.id");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        fputcsv($output, $row);
    }

} elseif ($type === 'scores') {
    fputcsv($output, ['Student', 'Class', 'Subject', 'Term', 'Seq1', 'Seq2', 'Average', 'Coef', 'Total', 'Remark']);

    $stmt = $conn->query("SELECT s.name AS student, c.name AS class, sub.name AS subject,
                                 sc.term, sc.seq1, sc.seq2, 
                                 ((sc.seq1 + sc.seq2) / 2) as average,
                                 sub.coefficient,
                                 ((sc.seq1 + sc.seq2) / 2 * sub.coefficient) as total,
                                 sc.remark
                          FROM scores sc
                          JOIN students s ON sc.student_id = s.id
                          JOIN classes c ON s.class_id = c.id
                          JOIN subjects sub ON sc.subject_id = sub.id
                          ORDER BY s.name, sc.term, sub.name");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        fputcsv($output, [
            $row['student'],
            $row['class'],
            $row['subject'],
            $row['term'],
            $row['seq1'] ?? 0,
            $row['seq2'] ?? 0,
            number_format($row['average'] ?? 0, 2),
            $row['coefficient'],
            number_format($row['total'] ?? 0, 2),
            $row['remark'] ?? ''
        ]);
    }

} else {
    fclose($output);
    header_remove();
    http_response_code(400);
    echo "Invalid export type.";
    exit;
}

fclose($output);
exit;
