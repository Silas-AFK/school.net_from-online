<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
requireRole('admin');

$school_info = $conn->query("SELECT academic_year FROM school_info LIMIT 1")->fetch(PDO::FETCH_ASSOC);
$current_academic_year = $school_info['academic_year'] ?? '2023-2024';

// Get all classes
$classes = $conn->query("SELECT id, name FROM classes ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);

$reports = [];
$selected_year = $_GET['academic_year'] ?? '';
$selected_term = $_GET['term'] ?? '';
$selected_class = $_GET['class_id'] ?? '';

if ($selected_year && $selected_term && $selected_class) {
    // Get all students in the class with their report data
    $stmt = $conn->prepare("
        SELECT 
            s.id,
            s.name,
            s.admission_no,
            rs.average,
            rs.position,
            rs.promoted
        FROM students s
        LEFT JOIN report_summary rs ON s.id = rs.student_id AND rs.term = ?
        WHERE s.class_id = ?
        ORDER BY s.name
    ");
    $stmt->execute([$selected_term, $selected_class]);
    $reports = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get class name
    $class_stmt = $conn->prepare("SELECT name FROM classes WHERE id = ?");
    $class_stmt->execute([$selected_class]);
    $class_name = $class_stmt->fetchColumn();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View All Report Cards</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
        }
        h2 {
            color: #333;
            margin-bottom: 30px;
            font-size: 2em;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }
        select {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 1em;
        }
        select:focus {
            outline: none;
            border-color: #667eea;
        }
        .btn {
            padding: 12px 30px;
            border: none;
            border-radius: 8px;
            font-size: 1em;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
        }
        .btn-primary {
            background: #667eea;
            color: white;
        }
        .btn-primary:hover {
            background: #5568d3;
            transform: translateY(-2px);
        }
        .btn-success {
            background: #28a745;
            color: white;
            padding: 8px 16px;
            font-size: 0.9em;
        }
        .btn-success:hover {
            background: #218838;
        }
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #e0e0e0;
        }
        th {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            font-weight: 600;
        }
        tr:hover {
            background: #f8f9fa;
        }
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #667eea;
            text-decoration: none;
            font-weight: 600;
        }
        .back-link:hover {
            text-decoration: underline;
        }
        .status-passed {
            color: #28a745;
            font-weight: bold;
        }
        .status-failed {
            color: #dc3545;
            font-weight: bold;
        }
        .filter-section {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
        }
        .form-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }
    </style>
</head>
<body>
<div class="container">
    <a href="dashboard.php" class="back-link">← Back to Dashboard</a>
    <h2>📚 View All Report Cards</h2>

    <div class="filter-section">
        <form method="GET">
            <div class="form-row">
                <div class="form-group">
                    <label>Academic Year:</label>
                    <select name="academic_year" required>
                        <option value="">-- Select Year --</option>
                        <option value="<?= htmlspecialchars($current_academic_year) ?>" <?= $selected_year == $current_academic_year ? 'selected' : '' ?>>
                            <?= htmlspecialchars($current_academic_year) ?>
                        </option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Term:</label>
                    <select name="term" required>
                        <option value="">-- Select Term --</option>
                        <option value="1st" <?= $selected_term == '1st' ? 'selected' : '' ?>>1st Term</option>
                        <option value="2nd" <?= $selected_term == '2nd' ? 'selected' : '' ?>>2nd Term</option>
                        <option value="3rd" <?= $selected_term == '3rd' ? 'selected' : '' ?>>3rd Term</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Class:</label>
                    <select name="class_id" required>
                        <option value="">-- Select Class --</option>
                        <?php foreach ($classes as $class): ?>
                            <option value="<?= $class['id'] ?>" <?= $selected_class == $class['id'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($class['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <button type="submit" class="btn btn-primary" style="margin-top: 20px;">View Reports</button>
        </form>
    </div>

    <?php if (!empty($reports)): ?>
        <h3 style="color: #333; margin-top: 40px;">
            Report Cards - <?= htmlspecialchars($class_name) ?> - <?= htmlspecialchars($selected_term) ?> Term (<?= htmlspecialchars($selected_year) ?>)
        </h3>
        
        <table>
            <thead>
                <tr>
                    <th>S/N</th>
                    <th>Admission No</th>
                    <th>Student Name</th>
                    <th>Average</th>
                    <th>Position</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $sn = 1;
                foreach ($reports as $report): 
                ?>
                    <tr>
                        <td><?= $sn++ ?></td>
                        <td><?= htmlspecialchars($report['admission_no']) ?></td>
                        <td><?= htmlspecialchars($report['name']) ?></td>
                        <td><?= $report['average'] ? number_format($report['average'], 2) : 'N/A' ?></td>
                        <td><?= htmlspecialchars($report['position'] ?? 'N/A') ?></td>
                        <td>
                            <?php if ($report['promoted']): ?>
                                <span class="<?= in_array($report['promoted'], ['PASSED', 'PROMOTED']) ? 'status-passed' : 'status-failed' ?>">
                                    <?= htmlspecialchars($report['promoted']) ?>
                                </span>
                            <?php else: ?>
                                <span style="color: #6c757d;">Not Generated</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="report_card.php?student_id=<?= $report['id'] ?>&term=<?= urlencode($selected_term) ?>" 
                               class="btn btn-success" 
                               target="_blank">
                                📄 Download PDF
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div style="margin-top: 30px;">
            <a href="download_reports.php?class_id=<?= $selected_class ?>&term=<?= urlencode($selected_term) ?>" 
               class="btn btn-primary">
                📦 Download All Reports (ZIP)
            </a>
        </div>
    <?php elseif ($selected_year && $selected_term && $selected_class): ?>
        <p style="margin-top: 20px; color: #666;">No students found for the selected criteria.</p>
    <?php endif; ?>
</div>
</body>
</html>
