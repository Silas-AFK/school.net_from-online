<?php
// samo/admin/add_student.php
declare(strict_types=1);
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

requireAuth();

$success = '';
$error = '';

// Fetch class list from database
$classes = [];
try {
    $stmt = $conn->query("SELECT id, name FROM classes ORDER BY name ASC");
    $classes = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log('Class fetch error: ' . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $dob = $_POST['dob'];
    $sex = $_POST['sex'];
    $place = trim($_POST['place_of_birth']);
    $admission = trim($_POST['admission_no']);
    $class_id = $_POST['class_id'];

    if (empty($name) || empty($dob) || empty($sex) || empty($admission) || empty($class_id)) {
        $error = 'All fields are required.';
    } else {
        try {
            $check_stmt = $conn->prepare("SELECT COUNT(*) FROM students WHERE admission_no = ?");
            $check_stmt->execute([$admission]);
            $exists = $check_stmt->fetchColumn();
            
            if ($exists > 0) {
                $error = 'Admission number already exists. Please use a unique admission number.';
            } else {
                $stmt = $conn->prepare("INSERT INTO students (name, dob, sex, place_of_birth, admission_no, class_id)
                                        VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->execute([$name, $dob, $sex, $place, $admission, $class_id]);
                $success = 'Student added successfully!';
                $name = $dob = $sex = $place = $admission = $class_id = '';
            }
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                $error = 'Admission number already exists.';
            } else {
                error_log('Add student error: ' . $e->getMessage());
                $error = 'An error occurred. Please try again.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Student - Caroma</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f7fa;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.08);
        }
        h2 {
            color: #333;
            margin-bottom: 20px;
        }
        .success {
            background: #d4edda;
            color: #155724;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #28a745;
        }
        .error {
            background: #f8d7da;
            color: #721c24;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #dc3545;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            color: #333;
            font-weight: 600;
            margin-bottom: 8px;
        }
        input[type="text"],
        input[type="date"],
        select {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 1em;
        }
        input:focus, select:focus {
            outline: none;
            border-color: #667eea;
        }
        button {
            padding: 12px 30px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-weight: bold;
            font-size: 1em;
        }
        button:hover {
            background: #5568d3;
        }
        .back-link {
            margin-top: 20px;
        }
        .back-link a {
            color: #667eea;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Add New Student</h2>
        
        <?php if ($success): ?>
            <div class="success"><?= e($success) ?></div>
        <?php endif; ?>
        
        <?php if ($error): ?>
            <div class="error"><?= e($error) ?></div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="form-group">
                <label for="name">Full Name *</label>
                <input type="text" id="name" name="name" required>
            </div>

            <div class="form-group">
                <label for="dob">Date of Birth *</label>
                <input type="date" id="dob" name="dob" required>
            </div>

            <div class="form-group">
                <label for="sex">Sex *</label>
                <select id="sex" name="sex" required>
                    <option value="">-- Select --</option>
                    <option value="M">Male</option>
                    <option value="F">Female</option>
                </select>
            </div>

            <div class="form-group">
                <label for="place_of_birth">Place of Birth</label>
                <input type="text" id="place_of_birth" name="place_of_birth">
            </div>

            <div class="form-group">
                <label for="admission_no">Admission Number *</label>
                <input type="text" id="admission_no" name="admission_no" required>
            </div>

            <div class="form-group">
                <label for="class_id">Class *</label>
                <select id="class_id" name="class_id" required>
                    <option value="">-- Select Class --</option>
                    <?php foreach ($classes as $class): ?>
                        <option value="<?= $class['id'] ?>"><?= htmlspecialchars($class['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <button type="submit">Add Student</button>
        </form>

        <p class="back-link"><a href="dashboard.php">← Back to Dashboard</a></p>
    </div>
</body>
</html>
