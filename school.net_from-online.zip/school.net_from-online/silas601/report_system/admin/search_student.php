<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
requireAnyRole(['admin', 'teacher']);

$results = [];

if (isset($_GET['query'])) {
    $query = '%' . $_GET['query'] . '%';
    $stmt = $conn->prepare("SELECT s.*, c.name AS class_name
                            FROM students s
                            LEFT JOIN classes c ON s.class_id = c.id
                            WHERE s.name LIKE ? OR s.admission_no LIKE ?");
    $stmt->execute([$query, $query]);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Search Student</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, sans-serif;
            background: #f5f7fa;
            padding: 20px;
        }
        .container {
            max-width: 900px;
            margin: auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h2, h3 {
            color: #333;
            margin-bottom: 20px;
        }
        form {
            margin-bottom: 20px;
        }
        input[type="text"] {
            width: 100%;
            padding: 12px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-bottom: 10px;
        }
        button {
            background: #0077cc;
            color: white;
            padding: 10px 25px;
            border: none;
            border-radius: 5px;
            font-weight: bold;
            cursor: pointer;
        }
        button:hover {
            background: #005fa3;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background: #0077cc;
            color: white;
        }
        tr:nth-child(even) {
            background: #f9f9f9;
        }
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #0077cc;
            text-decoration: none;
            font-weight: bold;
        }
        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<div class="container">
    <a href="<?= getDashboardUrl() ?>" class="back-link">← Back to Dashboard</a>
    <h2>🔍 Search Student</h2>

    <form method="GET">
        <input type="text" name="query" placeholder="Enter name or admission number" required>
        <button type="submit">Search</button>
    </form>

    <?php if (!empty($results)): ?>
        <h3>📋 Search Results</h3>
        <table>
            <tr>
                <th>Name</th>
                <th>Admission No</th>
                <th>Class</th>
                <?php if (getCurrentUserRole() === 'admin'): ?>
                <th>Actions</th>
                <?php endif; ?>
            </tr>
            <?php foreach ($results as $student): ?>
                <tr>
                    <td><?= htmlspecialchars($student['name']) ?></td>
                    <td><?= htmlspecialchars($student['admission_no']) ?></td>
                    <td><?= htmlspecialchars($student['class_name'] ?? 'N/A') ?></td>
                    <?php if (getCurrentUserRole() === 'admin'): ?>
                    <td><a href="edit_student.php?id=<?= $student['id'] ?>">Edit</a></td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php elseif (isset($_GET['query'])): ?>
        <p>No students found matching your search.</p>
    <?php endif; ?>
</div>
</body>
</html>
