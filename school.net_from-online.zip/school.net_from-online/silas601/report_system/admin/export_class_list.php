<?php
ob_start();

require_once '../includes/db.php';
require_once '../includes/auth.php';
requireRole('admin');

require_once __DIR__ . '/../pdf/fpdf/fpdf.php';

if (!isset($_POST['class_id'])) {
    ob_end_clean();
    die("Missing class ID parameter.");
}

$class_id = (int)$_POST['class_id'];

$class_stmt = $conn->prepare("SELECT name FROM classes WHERE id = ?");
$class_stmt->execute([$class_id]);
$class_info = $class_stmt->fetch(PDO::FETCH_ASSOC);

if (!$class_info) {
    ob_end_clean();
    die("Class not found.");
}

$school_info = $conn->query("SELECT school_name, academic_year FROM school_info LIMIT 1")->fetch(PDO::FETCH_ASSOC);
$school_name = $school_info['school_name'] ?? 'CAROMA COMPREHENSIVE EDUCATION CENTER (CCEC) BAMENDA';
$academic_year = $school_info['academic_year'] ?? '2023-2024';

// Get all students in the class
$students_stmt = $conn->prepare("
    SELECT name, admission_no, sex, dob, place_of_birth, repeater
    FROM students 
    WHERE class_id = ?
    ORDER BY name ASC
");
$students_stmt->execute([$class_id]);
$students = $students_stmt->fetchAll(PDO::FETCH_ASSOC);

if (empty($students)) {
    ob_end_clean();
    die("No students found in this class.");
}

// Create PDF
$pdf = new FPDF('P', 'mm', 'A4');
$pdf->AddPage();
$pdf->SetMargins(15, 15, 15);

// Header
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell(0, 10, $school_name, 0, 1, 'C');

$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(0, 8, 'CLASS LIST', 0, 1, 'C');

$pdf->SetFont('Arial', '', 11);
$pdf->Cell(0, 6, 'Class: ' . htmlspecialchars($class_info['name']), 0, 1, 'C');
$pdf->Cell(0, 6, 'Academic Year: ' . htmlspecialchars($academic_year), 0, 1, 'C');
$pdf->Cell(0, 6, 'Total Students: ' . count($students), 0, 1, 'C');
$pdf->Ln(5);

// Table header
$pdf->SetFont('Arial', 'B', 9);
$pdf->SetFillColor(0, 119, 204);
$pdf->SetTextColor(255, 255, 255);

$pdf->Cell(10, 8, 'S/N', 1, 0, 'C', true);
$pdf->Cell(60, 8, 'NAME', 1, 0, 'C', true);
$pdf->Cell(30, 8, 'ADMISSION NO', 1, 0, 'C', true);
$pdf->Cell(15, 8, 'SEX', 1, 0, 'C', true);
$pdf->Cell(25, 8, 'DOB', 1, 0, 'C', true);
$pdf->Cell(40, 8, 'PLACE OF BIRTH', 1, 1, 'C', true);

// Table content
$pdf->SetFont('Arial', '', 8);
$pdf->SetTextColor(0, 0, 0);

$sn = 1;
foreach ($students as $student) {
    $fill = ($sn % 2 == 0);
    $pdf->SetFillColor(249, 249, 249);
    
    $pdf->Cell(10, 7, $sn, 1, 0, 'C', $fill);
    $pdf->Cell(60, 7, strtoupper($student['name']), 1, 0, 'L', $fill);
    $pdf->Cell(30, 7, $student['admission_no'], 1, 0, 'C', $fill);
    $pdf->Cell(15, 7, $student['sex'], 1, 0, 'C', $fill);
    $pdf->Cell(25, 7, date('d/m/Y', strtotime($student['dob'])), 1, 0, 'C', $fill);
    $pdf->Cell(40, 7, strtoupper($student['place_of_birth'] ?? 'N/A'), 1, 1, 'L', $fill);
    
    $sn++;
}

// Footer
$pdf->Ln(10);
$pdf->SetFont('Arial', 'I', 8);
$pdf->Cell(0, 5, 'Generated on: ' . date('F d, Y h:i A'), 0, 1, 'R');

ob_end_clean();
$pdf->Output('I', 'Class_List_' . preg_replace('/[^a-zA-Z0-9]/', '_', $class_info['name']) . '.pdf');
exit;
?>
