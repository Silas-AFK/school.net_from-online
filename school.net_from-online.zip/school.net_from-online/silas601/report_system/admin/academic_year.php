<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
requireRole('admin');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $year = $_POST['academic_year'];
    $term = $_POST['term'];

    $stmt = $conn->prepare("UPDATE school_info SET academic_year = ?, current_term = ? WHERE id = 1");
    $stmt->execute([$year, $term]);
    $success = "Academic year and term updated!";
}

$info = $conn->query("SELECT academic_year, current_term FROM school_info WHERE id = 1")->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Set Academic Year</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .container {
            background: white;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            max-width: 500px;
            width: 100%;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
        }
        .header h2 {
            color: #333;
            font-size: 28px;
            margin: 0 0 10px 0;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        .header p {
            color: #666;
            font-size: 14px;
            margin: 0;
        }
        .success {
            background: #d4edda;
            color: #155724;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 25px;
            border-left: 4px solid #28a745;
            font-weight: 500;
        }
        .form-group {
            margin-bottom: 25px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
            font-size: 14px;
        }
        input[type="text"], select {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 15px;
            transition: border-color 0.3s;
            box-sizing: border-box;
        }
        input[type="text"]:focus, select:focus {
            outline: none;
            border-color: #667eea;
        }
        .button-group {
            display: flex;
            gap: 10px;
            margin-top: 30px;
        }
        button {
            flex: 1;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 14px 25px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            font-size: 15px;
            cursor: pointer;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        button:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(102, 126, 234, 0.4);
        }
        .back-btn {
            background: #6c757d;
            background: linear-gradient(135deg, #6c757d 0%, #5a6268 100%);
        }
        .back-btn:hover {
            box-shadow: 0 5px 20px rgba(108, 117, 125, 0.4);
        }
        .info-box {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 25px;
            border-left: 4px solid #667eea;
        }
        .info-box p {
            margin: 0;
            color: #555;
            font-size: 13px;
            line-height: 1.6;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h2>📅 Set Academic Year & Term</h2>
            <p>Configure the current academic year and term for the entire system</p>
        </div>

        <?php if (isset($success)): ?>
            <div class="success">✓ <?= htmlspecialchars($success) ?></div>
        <?php endif; ?>

        <div class="info-box">
            <p><strong>Note:</strong> This setting will apply to all report cards, class lists, and other documents generated in the system.</p>
        </div>

        <form method="POST">
            <div class="form-group">
                <label>Academic Year:</label>
                <input type="text" name="academic_year" value="<?php echo htmlspecialchars($info['academic_year']); ?>" placeholder="e.g., 2024-2025" required>
            </div>

            <div class="form-group">
                <label>Current Term:</label>
                <select name="term" required>
                    <option value="1st" <?php if ($info['current_term'] == '1st') echo 'selected'; ?>>1st Term</option>
                    <option value="2nd" <?php if ($info['current_term'] == '2nd') echo 'selected'; ?>>2nd Term</option>
                    <option value="3rd" <?php if ($info['current_term'] == '3rd') echo 'selected'; ?>>3rd Term</option>
                </select>
            </div>

            <div class="button-group">
                <button type="button" class="back-btn" onclick="window.location.href='dashboard.php'">← Back</button>
                <button type="submit">Update Settings</button>
            </div>
        </form>
    </div>
</body>
</html>
