<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
requireRole('admin');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $principal_name = $_POST['principal_name'];

    // Handle logo upload
    if ($_FILES['logo']['name']) {
        $logo_path = 'assets/images/caroma-logo.png';
        move_uploaded_file($_FILES['logo']['tmp_name'], $logo_path);
    }

    // Handle signature upload
    if ($_FILES['signature']['name']) {
        $signature_path = 'assets/images/signature.png';
        move_uploaded_file($_FILES['signature']['tmp_name'], $signature_path);
    }

    $stmt = $conn->prepare("UPDATE school_info SET principal_name = ? WHERE id = 1");
    $stmt->execute([$principal_name]);

    echo "<p style='color:green;'>Settings updated successfully!</p>";
}

$info = $conn->query("SELECT principal_name FROM school_info WHERE id = 1")->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <title>School Settings</title>
</head>
<body>
    <h2>🏫 School Branding & Principal Info</h2>
    <form method="POST" enctype="multipart/form-data">
        <label>Principal Name:</label>
        <input type="text" name="principal_name" value="<?php echo $info['principal_name']; ?>" required><br>

        <label>School Logo:</label>
        <input type="file" name="logo" accept="image/*"><br>

        <label>Principal Signature:</label>
        <input type="file" name="signature" accept="image/*"><br>

        <button type="submit">Update Settings</button>
    </form>
</body>
</html>
