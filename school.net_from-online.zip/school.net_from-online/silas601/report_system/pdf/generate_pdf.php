<?php
require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole('admin');
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../pdf/fpdf.php';

// Accept POST data from form
$class_id = $_POST['class_id'] ?? null;
$term = $_POST['term'] ?? null;

if (!$class_id || !$term) {
    echo "Missing class or term.";
    exit;
}

// Sequence-to-term mapping
$sequence_map = [
    '1st' => [1, 2],
    '2nd' => [3, 4],
    '3rd' => [5, 6]
];

// Fetch class name
$class_stmt = $conn->prepare("SELECT name FROM classes WHERE id = ?");
$class_stmt->execute([$class_id]);
$class_name = $class_stmt->fetchColumn() ?: 'Unknown Class';

// Fetch students
$student_stmt = $conn->prepare("SELECT id, name, admission_no FROM students WHERE class_id = ?");
$student_stmt->execute([$class_id]);
$students = $student_stmt->fetchAll(PDO::FETCH_ASSOC);

// Create PDF
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(0, 10, $school_name ?? 'School Name', 0, 1, 'C');
$pdf->Cell(0, 10, "Class Report - $class_name ($term Term)", 0, 1, 'C');
$pdf->Ln(5);

// Table headers
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(10, 10, '#', 1);
$pdf->Cell(50, 10, 'Name', 1);
$pdf->Cell(30, 10, 'Adm No', 1);
$pdf->Cell(20, 10, 'Total', 1);
$pdf->Cell(20, 10, 'Avg', 1);
$pdf->Cell(20, 10, 'Pos', 1);
$pdf->Cell(40, 10, 'Promotion', 1);
$pdf->Ln();

// Table rows
$pdf->SetFont('Arial', '', 10);
$i = 1;

foreach ($students as $student) {
    $student_id = $student['id'];

    $summary_stmt = $conn->prepare("SELECT total_marks, average, position, promoted FROM report_summary
                                    WHERE student_id = ? AND term = ?");
    $summary_stmt->execute([$student_id, $term]);
    $summary = $summary_stmt->fetch(PDO::FETCH_ASSOC);

    $total = $summary['total_marks'] ?? 0;
    $average = $summary['average'] ?? 0;
    $position = $summary['position'] ?? '-';
    $promotion = isset($summary['promoted']) ? ($summary['promoted'] ? 'Promoted' : 'Repeat') : '-';

    $pdf->Cell(10, 10, $i++, 1);
    $pdf->Cell(50, 10, $student['name'], 1);
    $pdf->Cell(30, 10, $student['admission_no'], 1);
    $pdf->Cell(20, 10, $total, 1);
    $pdf->Cell(20, 10, $average, 1);
    $pdf->Cell(20, 10, $position, 1);
    $pdf->Cell(40, 10, $promotion, 1);
    $pdf->Ln();
}

// Output PDF to browser
$pdf->Output('I', "Class_Report_{$class_name}_{$term}.pdf");
