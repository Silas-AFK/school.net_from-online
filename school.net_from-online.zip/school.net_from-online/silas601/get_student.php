<?php
// get_student.php
header('Content-Type: application/json');
require 'includes/db.php';

$matricule = trim($_GET['matricule'] ?? '');
if ($matricule === '') {
    echo json_encode(['error' => 'Matricule is required']); exit;
}

$sql = "SELECT matricule, fullName, department, classLevel, dob, placeOfBirth, sex, photo
        FROM admission WHERE matricule = ? LIMIT 1";
$stmt = $mysqli_conn->prepare($sql);
if(!$stmt){ echo json_encode(['error'=>'DB prepare failed']); exit; }
$stmt->bind_param('s', $matricule);
$stmt->execute();
$res = $stmt->get_result();
if ($res->num_rows === 0) {
    echo json_encode(['error' => 'Student not found']); exit;
}
$st = $res->fetch_assoc();

// Build photo URL (falls back to placeholder)
$photo_file = $st['photo'] ? ('upload/'.basename($st['photo'])) : 'upload/placeholder.png';

echo json_encode([
  'matricule'   => $st['matricule'],
  'fullName'    => $st['fullName'],
  'department'  => $st['department'],
  'classLevel'  => $st['classLevel'],
  'dob'         => $st['dob'],
  'placeOfBirth'=> $st['placeOfBirth'],
  'sex'         => $st['sex'],
  'photo_url'   => $photo_file
]);
