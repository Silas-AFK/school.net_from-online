-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 15, 2025 at 06:17 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mercy`
--

DELIMITER $$
--
-- Functions
--
CREATE DEFINER=`root`@`localhost` FUNCTION `generate_matricule` () RETURNS VARCHAR(20) CHARSET utf8mb4 COLLATE utf8mb4_general_ci DETERMINISTIC BEGIN
    DECLARE new_matricule VARCHAR(20);
    DECLARE current_year VARCHAR(2);
    DECLARE next_number INT;
    DECLARE max_matricule VARCHAR(20);
    
    -- Get current year (last 2 digits)
    SET current_year = RIGHT(YEAR(CURDATE()), 2);
    
    -- Get the highest matricule for current year
    SELECT matricule INTO max_matricule 
    FROM admission 
    WHERE matricule LIKE CONCAT('CCEC', current_year, '%')
    ORDER BY matricule DESC 
    LIMIT 1;
    
    -- Extract number and increment
    IF max_matricule IS NULL THEN
        SET next_number = 1;
    ELSE
        SET next_number = CAST(RIGHT(max_matricule, 4) AS UNSIGNED) + 1;
    END IF;
    
    -- Format: CCECYY#### (e.g., CCEC250001)
    SET new_matricule = CONCAT('CCEC', current_year, LPAD(next_number, 4, '0'));
    
    RETURN new_matricule;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `administrative_staff`
--

CREATE TABLE `administrative_staff` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `position` varchar(100) DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `display_order` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `administrative_staff`
--

INSERT INTO `administrative_staff` (`id`, `name`, `position`, `bio`, `photo`, `display_order`, `created_at`) VALUES
(1, 'Afanwi Silas Shu', 'Principal', 'hola', 'uploads/staff/1760373431_68ed2ab7a1569.jpg', 1, '2025-10-13 16:37:11'),
(2, 'MADAM MANKAH', 'Economics teacher', 'teacher in all aspects of economics', 'uploads/staff/1760527139_68ef832359dd9.jpg', 2, '2025-10-15 11:18:59');

-- --------------------------------------------------------

--
-- Table structure for table `admission`
--

CREATE TABLE `admission` (
  `id` int(11) NOT NULL,
  `fullName` varchar(100) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `placeOfBirth` varchar(100) DEFAULT NULL,
  `residence` varchar(100) DEFAULT NULL,
  `fatherName` varchar(100) DEFAULT NULL,
  `fatherPhone` varchar(20) DEFAULT NULL,
  `fatherResidence` varchar(100) DEFAULT NULL,
  `motherName` varchar(100) DEFAULT NULL,
  `motherPhone` varchar(20) DEFAULT NULL,
  `motherResidence` varchar(100) DEFAULT NULL,
  `guardianName` varchar(100) DEFAULT NULL,
  `guardianPhone` varchar(20) DEFAULT NULL,
  `guardianResidence` varchar(100) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `classLevel` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `registrationDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `matricule` varchar(20) DEFAULT NULL,
  `sex` varchar(10) NOT NULL,
  `reset_token` varchar(255) DEFAULT NULL,
  `reset_expiry` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admission`
--

INSERT INTO `admission` (`id`, `fullName`, `dob`, `placeOfBirth`, `residence`, `fatherName`, `fatherPhone`, `fatherResidence`, `motherName`, `motherPhone`, `motherResidence`, `guardianName`, `guardianPhone`, `guardianResidence`, `photo`, `classLevel`, `password`, `registrationDate`, `matricule`, `sex`, `reset_token`, `reset_expiry`) VALUES
(1, 'girl kumba afanwi', '2025-10-21', 'efeffwfew', 'hefhwef', 'ffew', '67899899', 'vsdvsvv', 'dggergerrg', 'rgerger', 'rgrege', 'rgerger', 'ergger', 'SMCC', 'uploads/1760372699_men.jpg', 'Form 2', '$2y$10$kPTr4ejkwDzoTx77mlvNS.Ttcb6PFriwgs53ui/DYhSNx0eaBaEHm', '2025-10-13 16:24:59', 'CAROMA001', 'Female', NULL, NULL),
(2, 'Baba kumba afanwi', '2025-10-21', 'efeffwfew', 'hefhwef', 'ffew', '67899899', 'vsdvsvv', 'dggergerrg', 'rgerger', 'rgrege', 'rgerger', 'ergger', 'CAROMA', 'uploads/1760374228_IMG-20250228-WA0012.jpg', 'Upper Sixth - Arts', '$2y$10$zMQ7sTndbOt96rDnG3qqnuHqZSnvFZz6fodlDvpYAwUo0wCPPKCxG', '2025-10-13 16:50:28', 'CAROMA002', 'Female', NULL, NULL),
(3, 'AMBE GAIUS che', '2025-10-10', 'BAFUT', 'TOWN', 'ffew', '67899899', 'sfsfsf', 'tythyht', 'dgdgd', 'kijlkjm', 'fvver', '6789889989', 'SMCC', 'uploads/1760524141_IMG-20250228-WA0018.jpg', 'Form 1', '$2y$10$9zngCKMZPCq0D2sWjjf5YOsAMKb7aHq41eEgCRT76fApH/.P13Eoa', '2025-10-15 10:29:01', 'CAROMA003', 'Male', NULL, NULL);

--
-- Triggers `admission`
--
DELIMITER $$
CREATE TRIGGER `before_admission_insert` BEFORE INSERT ON `admission` FOR EACH ROW BEGIN
    IF NEW.matricule IS NULL OR NEW.matricule = '' THEN
        SET NEW.matricule = generate_matricule();
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `class` varchar(100) NOT NULL,
  `image` varchar(255) NOT NULL,
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `title`, `class`, `image`, `uploaded_at`) VALUES
(2, 'mbhh', 'FORM 2', 'uploads/68ed302cd75f1.jpg', '2025-10-13 17:00:28'),
(3, 'nm', 'Form 4', 'uploads/68ed304b48a0f.PNG', '2025-10-13 17:00:59'),
(4, 'bb', 'form 3', 'uploads/68ed320538292.jpg', '2025-10-13 17:08:21');

-- --------------------------------------------------------

--
-- Table structure for table `classes`
--

CREATE TABLE `classes` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `academic_year` varchar(20) NOT NULL DEFAULT '2024-2025',
  `term` enum('1st','2nd','3rd') NOT NULL DEFAULT '1st'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `classes`
--

INSERT INTO `classes` (`id`, `name`, `academic_year`, `term`) VALUES
(2, 'Form 1', '2024-2025', '1st'),
(4, 'Form 2', '2024-2025', '1st'),
(7, 'Form 3 Science', '2024-2025', '1st'),
(8, 'Form 3 Arts', '2024-2025', '1st'),
(9, 'Form 3 Commercial', '2024-2025', '1st'),
(10, 'Form 4 Science', '2024-2025', '1st'),
(11, 'Form 4 Arts', '2024-2025', '1st'),
(12, 'Form 4 Commercial', '2024-2025', '1st'),
(13, 'Form 5 Science', '2024-2025', '1st'),
(14, 'Form 5 Arts', '2024-2025', '1st'),
(15, 'Form 5 Commercial', '2024-2025', '1st'),
(16, 'Lower Sixth Science', '2024-2025', '1st'),
(17, 'Lower Sixth Arts', '2024-2025', '1st'),
(18, 'Lower Sixth Commercial', '2024-2025', '1st'),
(19, 'Upper Sixth Science', '2024-2025', '1st'),
(20, 'Upper Sixth Arts', '2024-2025', '1st'),
(21, 'Upper Sixth Commercial', '2024-2025', '1st');

-- --------------------------------------------------------

--
-- Table structure for table `complaints`
--

CREATE TABLE `complaints` (
  `id` int(11) NOT NULL,
  `student_matricule` varchar(50) DEFAULT NULL,
  `student_name` varchar(100) DEFAULT NULL,
  `complaint_text` text DEFAULT NULL,
  `complaint_date` datetime DEFAULT current_timestamp(),
  `status` enum('pending','resolved') DEFAULT 'pending',
  `admin_response` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `complaints`
--

INSERT INTO `complaints` (`id`, `student_matricule`, `student_name`, `complaint_text`, `complaint_date`, `status`, `admin_response`) VALUES
(1, 'CAROMA001', 'girl kumba afanwi', 'my leg', '2025-10-13 09:47:57', 'resolved', 'solved'),
(2, 'CAROMA002', 'Baba kumba afanwi', 'hi', '2025-10-13 09:50:48', 'pending', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `published_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title`, `content`, `published_date`) VALUES
(2, 'fee payment ', 'pay your fees', '2025-10-14');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `voucher_no` varchar(100) NOT NULL,
  `org_name` varchar(255) DEFAULT NULL,
  `org_address` text DEFAULT NULL,
  `org_contact` varchar(255) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `payee_name` varchar(255) NOT NULL,
  `payee_address` text DEFAULT NULL,
  `payee_contact` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `payment_method` enum('Cash','Cheque','Bank Transfer','Mobile Money') DEFAULT 'Cash',
  `account_details` text DEFAULT NULL,
  `total_due` decimal(12,2) DEFAULT 0.00,
  `total_paid` decimal(12,2) DEFAULT 0.00,
  `balance` decimal(12,2) DEFAULT 0.00,
  `authorized_by` varchar(255) DEFAULT NULL,
  `authorized_designation` varchar(255) DEFAULT NULL,
  `approved_by` varchar(255) DEFAULT NULL,
  `approved_designation` varchar(255) DEFAULT NULL,
  `received_by` varchar(255) DEFAULT NULL,
  `received_designation` varchar(255) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `pdf_path` varchar(500) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`id`, `voucher_no`, `org_name`, `org_address`, `org_contact`, `payment_date`, `payee_name`, `payee_address`, `payee_contact`, `description`, `payment_method`, `account_details`, `total_due`, `total_paid`, `balance`, `authorized_by`, `authorized_designation`, `approved_by`, `approved_designation`, `received_by`, `received_designation`, `remarks`, `pdf_path`, `created_at`) VALUES
(1, 'nn,', 'SANTA MEMORIAL COMPREHENSIVE COLLEGE', 'Bamenda town', '5667767', '2025-10-13', 'SILAS', 'Bamenda town', '67898990', 'vgvv', 'Cash', 'nmjm,', 344.00, 34.00, 310.00, 'BLESSING BIH', 'jkkkkl', 'mmm;l', '.mmm', 'nm;mmlm', ',mmm;l', ',/l', 'payment_1_nn_.pdf', '2025-10-13 16:42:20'),
(2, 'nn,', 'SANTA MEMORIAL COMPREHENSIVE COLLEGE', 'Bamenda town', '5667767', '2025-10-13', 'SILAS', 'Bamenda town', '67898990', 'bbb', 'Cash', 'nmjm,', 234.00, 23.00, 211.00, 'BLESSING BIH', 'jkkkkl', 'mmm;l', '.mmm', 'nm;mmlm', ',mmm;l', ',/l', 'payment_2_nn_.pdf', '2025-10-13 19:52:29');

-- --------------------------------------------------------

--
-- Table structure for table `payment_vouchers`
--

CREATE TABLE `payment_vouchers` (
  `id` int(11) NOT NULL,
  `organization_name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `payment_voucher_no` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `payee_name` varchar(255) NOT NULL,
  `payee_address` varchar(255) NOT NULL,
  `payee_contact` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `payment_method` enum('Cash','Cheque','Bank Transfer','Mobile Money') NOT NULL,
  `account_details` varchar(255) DEFAULT NULL,
  `total_due_amount` decimal(10,2) NOT NULL,
  `total_amount_paid` decimal(10,2) NOT NULL,
  `balance_due` decimal(10,2) NOT NULL,
  `authorized_by` varchar(255) NOT NULL,
  `designation` varchar(255) NOT NULL,
  `approved_by` varchar(255) NOT NULL,
  `designation_approved` varchar(255) NOT NULL,
  `received_by` varchar(255) NOT NULL,
  `designation_received` varchar(255) NOT NULL,
  `remarks` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `report_summary`
--

CREATE TABLE `report_summary` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `term` enum('1st','2nd','3rd') NOT NULL,
  `total_marks` float DEFAULT NULL,
  `average` float DEFAULT NULL,
  `position` varchar(10) DEFAULT NULL,
  `class_average` float DEFAULT NULL,
  `highest_average` float DEFAULT NULL,
  `lowest_average` float DEFAULT NULL,
  `teacher_remark` text DEFAULT NULL,
  `principal_remark` text DEFAULT NULL,
  `promoted` enum('PASSED','FAILED','PROMOTED','REPEAT') DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `hours_absence` int(11) DEFAULT 0,
  `hours_punishment` int(11) DEFAULT 0,
  `days_suspension` int(11) DEFAULT 0,
  `warning` enum('YES','NO','Yes','No') DEFAULT 'NO',
  `dismissed` enum('YES','NO','yes','no') DEFAULT 'NO',
  `subjects_passed` int(11) DEFAULT 0,
  `no_passed` int(11) DEFAULT 0,
  `next_term_begins` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `report_summary`
--

INSERT INTO `report_summary` (`id`, `student_id`, `term`, `total_marks`, `average`, `position`, `class_average`, `highest_average`, `lowest_average`, `teacher_remark`, `principal_remark`, `promoted`, `remarks`, `hours_absence`, `hours_punishment`, `days_suspension`, `warning`, `dismissed`, `subjects_passed`, `no_passed`, `next_term_begins`) VALUES
(1, 1, '3rd', 232.5, 17.88, '1st', NULL, NULL, NULL, NULL, NULL, 'PROMOTED', 'repeet', 2, 3, 5, 'NO', 'NO', 4, 7, NULL),
(2, 3, '3rd', 231.5, 17.81, '2nd', NULL, NULL, NULL, NULL, NULL, 'PROMOTED', '', 0, 0, 0, 'NO', 'NO', 5, 7, NULL),
(3, 5, '3rd', 231, 17.77, '3rd', NULL, NULL, NULL, NULL, NULL, 'PROMOTED', '', 0, 0, 0, 'NO', 'NO', 5, 7, NULL),
(4, 2, '3rd', 215.5, 16.58, '4th', NULL, NULL, NULL, NULL, NULL, 'PROMOTED', '', 0, 0, 0, 'NO', 'NO', 5, 7, NULL),
(5, 4, '3rd', 205, 15.77, '5th', NULL, NULL, NULL, NULL, NULL, 'PROMOTED', '', 0, 0, 0, 'NO', 'NO', 5, 7, NULL),
(6, 6, '3rd', 169, 13, '6th', NULL, NULL, NULL, NULL, NULL, 'PROMOTED', '', 0, 0, 0, 'NO', 'NO', 4, 7, NULL),
(13, 1, '1st', 46, 23, '2nd', NULL, NULL, NULL, NULL, NULL, 'PASSED', NULL, 23, 12, 6, 'YES', 'NO', 1, 7, NULL),
(26, 7, '3rd', 0, 0, '7th', NULL, NULL, NULL, NULL, NULL, 'REPEAT', NULL, 3, 4, 2, 'YES', 'YES', 0, 7, NULL),
(58, 6, '1st', 50, 25, '1st', NULL, NULL, NULL, NULL, NULL, 'PASSED', NULL, 0, 0, 0, 'NO', 'NO', 1, 7, NULL),
(60, 4, '1st', 41.99, 20.99, '3rd', NULL, NULL, NULL, NULL, NULL, 'PASSED', NULL, 0, 0, 0, 'NO', 'NO', 1, 7, NULL),
(61, 7, '1st', 40, 20, '4th', NULL, NULL, NULL, NULL, NULL, 'PASSED', NULL, 0, 0, 0, 'NO', 'NO', 1, 7, NULL),
(62, 5, '1st', 38, 19, '5th', NULL, NULL, NULL, NULL, NULL, 'PASSED', NULL, 0, 0, 0, 'NO', 'NO', 1, 7, NULL),
(63, 2, '1st', 34, 17, '6th', NULL, NULL, NULL, NULL, NULL, 'PASSED', NULL, 0, 0, 0, 'NO', 'NO', 1, 7, NULL),
(64, 3, '1st', 26, 13, '7th', NULL, NULL, NULL, NULL, NULL, 'PASSED', NULL, 0, 0, 0, 'NO', 'NO', 1, 7, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `school_info`
--

CREATE TABLE `school_info` (
  `id` int(11) NOT NULL,
  `school_name` varchar(200) DEFAULT 'CAROMA COMPREHENSIVE EDUCATION CENTER (CCEC) BAMENDA',
  `school_name_french` varchar(200) DEFAULT 'MINISTERE DES ENSEIGNEMENTS SECONDAIRES',
  `motto` varchar(255) DEFAULT 'Education for All Students',
  `logo_url` varchar(255) DEFAULT NULL,
  `principal_name` varchar(100) DEFAULT 'Principal Name',
  `academic_year` varchar(20) DEFAULT '2024-2025',
  `current_term` enum('1st','2nd','3rd') DEFAULT '1st',
  `next_term_begins` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `school_info`
--

INSERT INTO `school_info` (`id`, `school_name`, `school_name_french`, `motto`, `logo_url`, `principal_name`, `academic_year`, `current_term`, `next_term_begins`) VALUES
(1, 'CAROMA COMPREHENSIVE EDUCATION CENTER (CCEC) BAMENDA', 'MINISTERE DES ENSEIGNEMENTS SECONDAIRES', 'Education for All Students', NULL, 'oga samo', '2024-2025', '1st', '2025-10-23');

-- --------------------------------------------------------

--
-- Table structure for table `scores`
--

CREATE TABLE `scores` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `term` enum('1st','2nd','3rd') NOT NULL,
  `seq1` float DEFAULT NULL,
  `seq2` float DEFAULT NULL,
  `average` float GENERATED ALWAYS AS ((`seq1` + `seq2`) / 2) STORED,
  `total` float GENERATED ALWAYS AS (`seq1` + `seq2`) STORED,
  `grade` varchar(2) DEFAULT NULL,
  `remark` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `scores`
--

INSERT INTO `scores` (`id`, `student_id`, `subject_id`, `term`, `seq1`, `seq2`, `grade`, `remark`) VALUES
(1, 1, 2, '3rd', 0, 18, 'E', 'Poor'),
(2, 5, 2, '3rd', 21, 13, 'B', 'Very Good'),
(3, 3, 2, '3rd', 16, 19, 'B', 'Very Good'),
(4, 2, 2, '3rd', 23, 10, 'B', 'Very Good'),
(5, 4, 2, '3rd', 17, 13, 'B', 'Very Good'),
(6, 6, 2, '3rd', 3, 10, 'F', 'Very Poor'),
(7, 1, 3, '3rd', 24, 21, 'A', 'Excellent'),
(8, 5, 3, '3rd', 15, 21, 'A', 'Excellent'),
(9, 3, 3, '3rd', 23, 9, 'B', 'Very Good'),
(10, 2, 3, '3rd', 23, 7, 'B', 'Very Good'),
(11, 4, 3, '3rd', 16, 19, 'B', 'Very Good'),
(12, 6, 3, '3rd', 10, 12, 'D', 'Fair'),
(13, 1, 5, '3rd', 24, 18, 'A', 'Excellent'),
(14, 5, 5, '3rd', 25, 12, 'A', 'Excellent'),
(15, 3, 5, '3rd', 26, 19, 'A', 'Excellent'),
(16, 2, 5, '3rd', 13, 18, 'B', 'Very Good'),
(17, 4, 5, '3rd', 23, 3, 'C', 'Good'),
(18, 6, 5, '3rd', 18, 17, 'B', 'Very Good'),
(19, 1, 4, '3rd', 24, 12, 'A', 'Excellent'),
(20, 5, 4, '3rd', 21, 14, 'B', 'Very Good'),
(21, 3, 4, '3rd', 27, 3, 'B', 'Very Good'),
(22, 2, 4, '3rd', 16, 18, 'B', 'Very Good'),
(23, 4, 4, '3rd', 17, 14, 'B', 'Very Good'),
(24, 6, 4, '3rd', 18, 15, 'B', 'Very Good'),
(25, 1, 1, '3rd', 27, 5, 'B', 'Very Good'),
(26, 5, 1, '3rd', 22, 13, 'B', 'Very Good'),
(27, 3, 1, '3rd', 22, 12, 'B', 'Very Good'),
(28, 2, 1, '3rd', 21, 17, 'A', 'Excellent'),
(29, 4, 1, '3rd', 24, 11, 'B', 'Very Good'),
(30, 6, 1, '3rd', 10, 15, 'C', 'Good'),
(31, 1, 2, '1st', 34, 12, 'A', 'Excellent'),
(32, 5, 2, '1st', 23, 15, 'A', 'Excellent'),
(33, 3, 2, '1st', 12, 14, 'C', 'Good'),
(34, 2, 2, '1st', 21, 13, 'B', 'Very Good'),
(35, 4, 2, '1st', 26, 15.99, 'A', 'Excellent'),
(36, 6, 2, '1st', 24, 26, 'A', 'Excellent'),
(37, 7, 2, '1st', 28, 12, 'A', 'Excellent');

-- --------------------------------------------------------

--
-- Table structure for table `sequences`
--

CREATE TABLE `sequences` (
  `id` int(11) NOT NULL,
  `term_id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sequences`
--

INSERT INTO `sequences` (`id`, `term_id`, `name`) VALUES
(1, 1, 'Sequence 1'),
(2, 1, 'Sequence 2'),
(3, 2, 'Sequence 3'),
(4, 2, 'Sequence 4'),
(5, 3, 'Sequence 5'),
(6, 3, 'Sequence 6');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `key` varchar(100) NOT NULL,
  `value` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`key`, `value`) VALUES
('results_paused', '0');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `dob` date NOT NULL,
  `sex` enum('Male','Female','M','F') NOT NULL,
  `repeater` enum('YES','NO') DEFAULT 'NO',
  `enrolment` int(11) DEFAULT 10,
  `photo_url` varchar(255) DEFAULT NULL,
  `place_of_birth` varchar(100) DEFAULT NULL,
  `admission_no` varchar(50) NOT NULL,
  `class_id` int(11) DEFAULT NULL,
  `matricule` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `name`, `dob`, `sex`, `repeater`, `enrolment`, `photo_url`, `place_of_birth`, `admission_no`, `class_id`, `matricule`) VALUES
(1, 'Afanwi Silas Shu', '2025-10-21', 'M', 'NO', 10, NULL, 'younde', 'silas234', 2, NULL),
(2, 'nfor junior', '2025-10-16', 'F', 'NO', 10, NULL, 'mankon', 'silas290', 2, NULL),
(3, 'mankah abinwi peace shu', '2025-10-03', 'F', 'NO', 10, NULL, 'bamenda', 'silas566', 2, NULL),
(4, 'Ngwa Bless Che', '2025-10-17', 'F', 'NO', 10, NULL, 'Kumba', 'silas003', 2, NULL),
(5, 'amba gaius shu', '2025-10-09', 'F', 'NO', 10, NULL, 'Kumba', 'silas009', 2, NULL),
(6, 'Ngwa precious', '2025-10-15', 'M', 'NO', 10, NULL, 'akum', 'silas256', 2, NULL),
(7, 'Ngwa precious che', '2025-10-15', 'M', 'NO', 10, NULL, 'akum', 'silas254', 2, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `coefficient` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `name`, `coefficient`) VALUES
(1, 'Mathematics', 3),
(2, 'Chemistry', 2),
(3, 'Economics', 3),
(4, 'Geology', 2),
(5, 'English Language', 3);

-- --------------------------------------------------------

--
-- Table structure for table `subject_teachers`
--

CREATE TABLE `subject_teachers` (
  `id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `teacher_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subject_teachers`
--

INSERT INTO `subject_teachers` (`id`, `subject_id`, `teacher_name`) VALUES
(1, 1, 'Mbiatu Desmond'),
(2, 2, 'Ebayong Samuel'),
(3, 3, 'Mankah Blessing'),
(4, 4, 'Mabell Shinna'),
(5, 5, 'Fulah Gomens');

-- --------------------------------------------------------

--
-- Table structure for table `terms`
--

CREATE TABLE `terms` (
  `id` int(11) NOT NULL,
  `name` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `terms`
--

INSERT INTO `terms` (`id`, `name`) VALUES
(1, '1st'),
(2, '2nd'),
(3, '3rd');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','teacher','principal') NOT NULL,
  `password_hash` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `password_hash`) VALUES
(1, 'admin', 'admin123', 'admin', '$2y$10$E9Xz...');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `administrative_staff`
--
ALTER TABLE `administrative_staff`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admission`
--
ALTER TABLE `admission`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `matricule` (`matricule`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `classes`
--
ALTER TABLE `classes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `complaints`
--
ALTER TABLE `complaints`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_received_by` (`received_by`);

--
-- Indexes for table `payment_vouchers`
--
ALTER TABLE `payment_vouchers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `payment_voucher_no` (`payment_voucher_no`);

--
-- Indexes for table `report_summary`
--
ALTER TABLE `report_summary`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_summary` (`student_id`,`term`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `school_info`
--
ALTER TABLE `school_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `scores`
--
ALTER TABLE `scores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_score` (`student_id`,`subject_id`,`term`),
  ADD KEY `scores_ibfk_2` (`subject_id`);

--
-- Indexes for table `sequences`
--
ALTER TABLE `sequences`
  ADD PRIMARY KEY (`id`),
  ADD KEY `term_id` (`term_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admission_no` (`admission_no`),
  ADD UNIQUE KEY `matricule` (`matricule`),
  ADD KEY `class_id` (`class_id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subject_teachers`
--
ALTER TABLE `subject_teachers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `subject_id` (`subject_id`);

--
-- Indexes for table `terms`
--
ALTER TABLE `terms`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `administrative_staff`
--
ALTER TABLE `administrative_staff`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `admission`
--
ALTER TABLE `admission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `classes`
--
ALTER TABLE `classes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `complaints`
--
ALTER TABLE `complaints`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `payment_vouchers`
--
ALTER TABLE `payment_vouchers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `report_summary`
--
ALTER TABLE `report_summary`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=128;

--
-- AUTO_INCREMENT for table `school_info`
--
ALTER TABLE `school_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `scores`
--
ALTER TABLE `scores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `sequences`
--
ALTER TABLE `sequences`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `subject_teachers`
--
ALTER TABLE `subject_teachers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `terms`
--
ALTER TABLE `terms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `report_summary`
--
ALTER TABLE `report_summary`
  ADD CONSTRAINT `report_summary_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `scores`
--
ALTER TABLE `scores`
  ADD CONSTRAINT `scores_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `scores_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `sequences`
--
ALTER TABLE `sequences`
  ADD CONSTRAINT `sequences_ibfk_1` FOREIGN KEY (`term_id`) REFERENCES `terms` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_ibfk_1` FOREIGN KEY (`class_id`) REFERENCES `classes` (`id`);

--
-- Constraints for table `subject_teachers`
--
ALTER TABLE `subject_teachers`
  ADD CONSTRAINT `subject_teachers_ibfk_1` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
