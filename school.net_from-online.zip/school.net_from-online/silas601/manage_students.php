<?php
session_start();
if (empty($_SESSION['admin']) && empty($_SESSION['main_admin'])) {
    header('Location: admin_login.php');
    exit();
}

require 'includes/db.php'; // Assumes $mysqli_conn is defined

// Delete student
if (isset($_GET['delete'])) {
    $mat = $mysqli_conn->real_escape_string($_GET['delete']);
    $mysqli_conn->query("DELETE FROM admission WHERE matricule='$mat'");
    header('Location: manage_students.php?deleted=1');
    exit;
}

// Handle student edit
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_student'])) {
    $matricule = $mysqli_conn->real_escape_string($_POST['matricule']);
    $fullName = $mysqli_conn->real_escape_string($_POST['fullName']);
    $classLevel = $mysqli_conn->real_escape_string($_POST['classLevel']);
    $fatherPhone = $mysqli_conn->real_escape_string($_POST['fatherPhone']);
    $motherPhone = $mysqli_conn->real_escape_string($_POST['motherPhone']);

    $sql = "UPDATE admission SET fullName='$fullName', classLevel='$classLevel', 
            fatherPhone='$fatherPhone', motherPhone='$motherPhone' 
            WHERE matricule='$matricule'";

    if ($mysqli_conn->query($sql)) {
        header('Location: manage_students.php?updated=1');
        exit;
    }
}

// Search by matricule, name, and/or class
$search = trim($_GET['search'] ?? '');
$class = trim($_GET['class'] ?? '');

$sql = "SELECT * FROM admission WHERE 1=1";
if ($search !== '') {
    $search_escaped = $mysqli_conn->real_escape_string($search);
    $sql .= " AND (matricule LIKE '%$search_escaped%' OR fullName LIKE '%$search_escaped%')";
}
if ($class !== '') {
    $class_escaped = $mysqli_conn->real_escape_string($class);
    $sql .= " AND classLevel LIKE '%$class_escaped%'";
}
$sql .= " ORDER BY registrationDate DESC";

$result = $mysqli_conn->query($sql);

// Get unique classes for dropdown
$classes_result = $mysqli_conn->query("SELECT DISTINCT classLevel FROM admission WHERE classLevel IS NOT NULL ORDER BY classLevel");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Manage Students - CAROMA</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { 
      font-family: 'Segoe UI', Arial, sans-serif; 
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      display: flex; 
      flex-direction: column; 
      min-height: 100vh; 
      padding: 20px;
    }
    
    header { text-align: center; padding: 20px 10px; }
    .logo { 
      width: 100px; 
      height: 100px; 
      border-radius: 50%; 
      object-fit: cover; 
      animation: fadeIn 2s;
      border: 3px solid white;
      box-shadow: 0 5px 15px rgba(0,0,0,0.3);
    }
    @keyframes fadeIn { from { opacity: 0; transform: scale(0.8); } to { opacity: 1; transform: scale(1); } }

    main { 
      flex: 1; 
      max-width: 1200px; 
      margin: 20px auto; 
      background: #fff; 
      padding: 30px; 
      border-radius: 15px; 
      box-shadow: 0 10px 40px rgba(0,0,0,0.3); 
    }
    
    h2 { 
      text-align: center; 
      color: #667eea; 
      margin-bottom: 25px;
      font-size: 2rem;
    }

    .alert {
      padding: 15px;
      border-radius: 8px;
      margin-bottom: 20px;
      text-align: center;
      font-weight: 600;
    }
    
    .alert-success {
      background: #d4edda;
      color: #155724;
      border: 1px solid #c3e6cb;
    }

    .search-form { 
      display: flex;
      gap: 10px;
      margin-bottom: 25px;
      flex-wrap: wrap;
      justify-content: center;
    }
    
    .search-form input, .search-form select {
      padding: 12px;
      border: 2px solid #e0e0e0;
      border-radius: 8px;
      font-size: 15px;
      flex: 1;
      min-width: 200px;
    }
    
    .search-form input:focus, .search-form select:focus {
      outline: none;
      border-color: #667eea;
    }
    
    .search-form button, .btn {
      padding: 12px 24px;
      border: none;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: #fff;
      border-radius: 8px;
      cursor: pointer;
      font-weight: 600;
      transition: transform 0.2s ease, box-shadow 0.2s ease;
    }
    
    .search-form button:hover, .btn:hover { 
      transform: translateY(-2px);
      box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
    }

    .btn-export {
      background: #28a745;
      margin-left: 10px;
    }

    .actions-bar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
      flex-wrap: wrap;
      gap: 10px;
    }

    table { 
      width: 100%; 
      border-collapse: collapse; 
      margin-top: 10px;
      background: white;
      box-shadow: 0 2px 8px rgba(0,0,0,0.1);
      border-radius: 8px;
      overflow: hidden;
    }
    
    table th, table td { 
      padding: 15px; 
      border-bottom: 1px solid #e0e0e0; 
      text-align: left; 
    }
    
    table th { 
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: #fff;
      font-weight: 600;
      text-transform: uppercase;
      font-size: 14px;
      letter-spacing: 0.5px;
    }
    
    table tr:hover {
      background: #f8f9fa;
    }
    
    .action-link {
      color: #667eea;
      text-decoration: none;
      font-weight: 600;
      margin-right: 15px;
      transition: color 0.2s ease;
    }
    
    .action-link:hover {
      color: #764ba2;
      text-decoration: underline;
    }
    
    .delete-link { 
      color: #dc3545; 
    }

    .student-photo {
      width: 50px;
      height: 50px;
      border-radius: 50%;
      object-fit: cover;
      border: 2px solid #667eea;
    }

    .modal {
      display: none;
      position: fixed;
      z-index: 1000;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      background: rgba(0,0,0,0.7);
      animation: fadeIn 0.3s ease;
    }

    .modal-content {
      background: white;
      margin: 5% auto;
      padding: 30px;
      border-radius: 15px;
      width: 90%;
      max-width: 600px;
      box-shadow: 0 10px 40px rgba(0,0,0,0.3);
      animation: slideDown 0.3s ease;
    }

    @keyframes slideDown {
      from { opacity: 0; transform: translateY(-50px); }
      to { opacity: 1; transform: translateY(0); }
    }

    .close {
      color: #aaa;
      float: right;
      font-size: 28px;
      font-weight: bold;
      cursor: pointer;
      transition: color 0.2s ease;
    }

    .close:hover { color: #000; }

    .form-group {
      margin-bottom: 20px;
    }

    .form-group label {
      display: block;
      font-weight: 600;
      margin-bottom: 8px;
      color: #333;
    }

    .form-group input, .form-group select {
      width: 100%;
      padding: 12px;
      border: 2px solid #e0e0e0;
      border-radius: 8px;
      font-size: 15px;
    }

    .form-group input:focus, .form-group select:focus {
      outline: none;
      border-color: #667eea;
    }

    .home { 
      margin-top: 30px; 
      text-align: center; 
    }
    
    .home a { 
      color: #667eea; 
      text-decoration: none; 
      font-weight: bold;
      padding: 10px 20px;
      border: 2px solid #667eea;
      border-radius: 8px;
      transition: all 0.3s ease;
    }
    
    .home a:hover { 
      background: #667eea;
      color: white;
    }

    footer { 
      background: rgba(0,0,0,0.8); 
      color: #fff; 
      text-align: center; 
      padding: 20px; 
      margin-top: 40px;
      border-radius: 10px;
      font-size: 14px; 
    }

    @media (max-width: 768px) {
      table th, table td { font-size: 13px; padding: 10px; }
      .logo { width: 80px; height: 80px; }
      h2 { font-size: 1.5rem; }
      .search-form { flex-direction: column; }
      .search-form input, .search-form select { min-width: 100%; }
    }
  </style>
  <script>
    function confirmDelete(matricule) {
      return confirm("Delete student with matricule '" + matricule + "'? This action cannot be undone.");
    }

    function viewStudent(matricule) {
      window.location.href = 'view_student_details.php?matricule=' + encodeURIComponent(matricule);
    }

    function editStudent(matricule, fullName, classLevel, fatherPhone, motherPhone) {
      document.getElementById('edit_matricule').value = matricule;
      document.getElementById('edit_fullName').value = fullName;
      document.getElementById('edit_classLevel').value = classLevel;
      document.getElementById('edit_fatherPhone').value = fatherPhone;
      document.getElementById('edit_motherPhone').value = motherPhone;
      document.getElementById('editModal').style.display = 'block';
    }

    function closeModal() {
      document.getElementById('editModal').style.display = 'none';
    }

    function exportClassList() {
      const classFilter = document.querySelector('[name="class"]').value;
      if (!classFilter) {
        alert('Please select a class to export');
        return;
      }
      window.location.href = 'export_class_pdf.php?class=' + encodeURIComponent(classFilter);
    }
  </script>
</head>
<body>

<header>
  <img src="joys.jpg" alt="CAROMA Logo" class="logo">
</header>

<main>
   
  <h2><i class="fas fa-users"></i> Manage Student Accounts</h2>

  <?php if (isset($_GET['deleted'])): ?>
    <div class="alert alert-success">Student deleted successfully.</div>
  <?php endif; ?>

  <?php if (isset($_GET['updated'])): ?>
    <div class="alert alert-success">Student information updated successfully.</div>
  <?php endif; ?>

  <div class="search-form">
    <form method="GET" style="display: flex; gap: 10px; flex-wrap: wrap; width: 100%;">
      <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Search by matricule or name...">
      <select name="class">
        <option value="">All Classes</option>
        <?php while ($class_row = $classes_result->fetch_assoc()): ?>
          <option value="<?= htmlspecialchars($class_row['classLevel']) ?>" 
                  <?= $class === $class_row['classLevel'] ? 'selected' : '' ?>>
            <?= htmlspecialchars($class_row['classLevel']) ?>
          </option>
        <?php endwhile; ?>
      </select>
      <button type="submit"><i class="fas fa-search"></i> Search</button>
      <button type="button" class="btn-export" onclick="exportClassList()">
        <i class="fas fa-file-pdf"></i> Export to PDF
      </button>
    </form>
  </div>

  <?php if ($result && $result->num_rows > 0): ?>
    <div style="overflow-x: auto;">
      <table>
        <thead>
          <tr>
            <th>#</th>
            <th>Photo</th>
            <th>Matricule</th>
            <th>Name</th>
            <th>Class</th>
            <th>Gender</th>
            <th>Father Phone</th>
            <th>Mother Phone</th>
            <th>Reg Date</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php $i = 1; while ($row = $result->fetch_assoc()): ?>
            <tr>
              <td><?= $i++ ?></td>
              <td>
                <?php 
                  $photoPath = !empty($row['photo']) ? $row['photo'] : 'uploads/default.jpg';
                  if (!file_exists($photoPath)) $photoPath = 'uploads/default.jpg';
                ?>
                <img src="<?= htmlspecialchars($photoPath) ?>" alt="Photo" class="student-photo">
              </td>
              <td><strong><?= htmlspecialchars($row['matricule']) ?></strong></td>
              <td><?= htmlspecialchars($row['fullName']) ?></td>
              <td><?= htmlspecialchars($row['classLevel']) ?></td>
              <td><?= htmlspecialchars($row['sex']) ?></td>
              <td><?= htmlspecialchars($row['fatherPhone']) ?></td>
              <td><?= htmlspecialchars($row['motherPhone']) ?></td>
              <td><?= date("M j, Y", strtotime($row['registrationDate'])) ?></td>
              <td>
                <a href="javascript:void(0)" 
                   onclick="viewStudent('<?= htmlspecialchars($row['matricule']) ?>')" 
                   class="action-link" title="View Details">
                  <i class="fas fa-eye"></i> View
                </a>
                <a href="javascript:void(0)" 
                   onclick="editStudent('<?= htmlspecialchars($row['matricule']) ?>', 
                                       '<?= htmlspecialchars($row['fullName']) ?>', 
                                       '<?= htmlspecialchars($row['classLevel']) ?>',
                                       '<?= htmlspecialchars($row['fatherPhone']) ?>',
                                       '<?= htmlspecialchars($row['motherPhone']) ?>')" 
                   class="action-link" title="Edit">
                  <i class="fas fa-edit"></i> Edit
                </a>
                <a href="?delete=<?= urlencode($row['matricule']) ?>" 
                   class="action-link delete-link"
                   onclick="return confirmDelete('<?= htmlspecialchars($row['matricule']) ?>')" title="Delete">
                  <i class="fas fa-trash"></i> Delete
                </a>
              </td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  <?php else: ?>
    <p style="text-align:center;color:gray;padding:40px;">No students found matching your search criteria.</p>
  <?php endif; ?>

  <div class="home">
    <a href="admin_panel.php"><i class="fas fa-arrow-left"></i> Back to Admin Panel</a>
  </div>
</main>

<div id="editModal" class="modal">
  <div class="modal-content">
    <span class="close" onclick="closeModal()">&times;</span>
    <h2 style="color: #667eea; margin-bottom: 20px;">Edit Student Information</h2>
    <form method="POST">
      <input type="hidden" name="matricule" id="edit_matricule">
      
      <div class="form-group">
        <label>Full Name</label>
        <input type="text" name="fullName" id="edit_fullName" required>
      </div>
      
      <div class="form-group">
        <label>Class Level</label>
        <input type="text" name="classLevel" id="edit_classLevel" required>
      </div>
      
      <div class="form-group">
        <label>Father's Phone</label>
        <input type="text" name="fatherPhone" id="edit_fatherPhone">
      </div>
      
      <div class="form-group">
        <label>Mother's Phone</label>
        <input type="text" name="motherPhone" id="edit_motherPhone">
      </div>
      
      <button type="submit" name="edit_student" class="btn">
        <i class="fas fa-save"></i> Update Student
      </button>
      <button type="button" onclick="closeModal()" class="btn" style="background: #6c757d; margin-left: 10px;">
        Cancel
      </button>
    </form>
  </div>
</div>

<footer>
   Updated footer branding 
  &copy; <?= date("Y") ?> CAROMA COMPREHENSIVE EDUCATION CENTER | Powered by <span style="color: goldenrod;">OSIRIS</span> Tech
</footer>

</body>
</html>
