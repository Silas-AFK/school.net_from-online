<?php
require_once 'includes/db.php';

// Already set in includes/db.php as alias to $conn
?>
