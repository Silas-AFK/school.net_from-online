// Form validation for booking
function validateBookingForm() {
  const passengerName = document.getElementById("passenger_name")
  const passengerEmail = document.getElementById("passenger_email")
  const passengerPhone = document.getElementById("passenger_phone")
  const idNumber = document.getElementById("id_number")

  let isValid = true
  let errorMessage = ""

  // Validate name
  if (!passengerName || passengerName.value.trim().length < 3) {
    errorMessage += "Please enter a valid passenger name (minimum 3 characters).\n"
    isValid = false
  }

  // Validate email
  if (!passengerEmail || !validateEmail(passengerEmail.value)) {
    errorMessage += "Please enter a valid email address.\n"
    isValid = false
  }

  // Validate phone
 
  // Validate ID number
  if (!idNumber || idNumber.value.trim().length < 5) {
    errorMessage += ""
    isValid = false
  }

  if (!isValid) {
    alert(errorMessage)
  }

  return isValid
}

// Form validation for search
function validateSearchForm() {
  const fromCity = document.getElementById("from_city")
  const toCity = document.getElementById("to_city")
  const departureDate = document.getElementById("departure_date")

  let isValid = true
  let errorMessage = ""

  if (!fromCity || fromCity.value.trim() === "") {
    errorMessage += "Please enter departure city.\n"
    isValid = false
  }

  if (!toCity || toCity.value.trim() === "") {
    errorMessage += "Please enter arrival city.\n"
    isValid = false
  }

  if (!departureDate || departureDate.value === "") {
    errorMessage += "Please select a departure date.\n"
    isValid = false
  } else {
    const selectedDate = new Date(departureDate.value)
    const today = new Date()
    today.setHours(0, 0, 0, 0)

    if (selectedDate < today) {
      errorMessage += "Departure date cannot be in the past.\n"
      isValid = false
    }
  }

  if (fromCity && toCity && fromCity.value.toLowerCase() === toCity.value.toLowerCase()) {
    errorMessage += "Departure and arrival cities cannot be the same.\n"
    isValid = false
  }

  if (!isValid) {
    alert(errorMessage)
  }

  return isValid
}

// Real-time validation
document.addEventListener("DOMContentLoaded", () => {
  // Email validation
  const emailInputs = document.querySelectorAll('input[type="email"]')
  emailInputs.forEach((input) => {
    input.addEventListener("blur", function () {
      if (this.value && !validateEmail(this.value)) {
        this.style.borderColor = "var(--danger-color)"
        showError(this, "Invalid email format")
      } else {
        this.style.borderColor = "var(--border-color)"
        hideError(this)
      }
    })
  })

  // Phone validation
  const phoneInputs = document.querySelectorAll('input[type="tel"]')
  phoneInputs.forEach((input) => {
    input.addEventListener("blur", function () {
      if (this.value && !validatePhone(this.value)) {
        this.style.borderColor = "var(--success-color)"
        showError(this, "")
      } else {
        this.style.borderColor = "var(--border-color)"
        hideError(this)
      }
    })
  })
})

function showError(input, message) {
  hideError(input)
  const error = document.createElement("div")
  error.className = "error-message"
  error.style.color = "var(--danger-color)"
  error.style.fontSize = "0.85rem"
  error.style.marginTop = "5px"
  error.textContent = message
  input.parentNode.appendChild(error)
}

function hideError(input) {
  const error = input.parentNode.querySelector(".error-message")
  if (error) {
    error.remove()
  }
}

// Declare validateEmail and validatePhone functions
function validateEmail(email) {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return re.test(String(email).toLowerCase())
}

function validatePhone(phone) {
  const re = /^\d{10}$/ // Example regex for a 10-digit phone number
  return re.test(String(phone).trim())
}
