// Mobile Navigation Toggle
document.addEventListener("DOMContentLoaded", () => {
  const navbarToggle = document.querySelector(".navbar-toggle")
  const navbarMenu = document.querySelector(".navbar-menu")

  if (navbarToggle) {
    navbarToggle.addEventListener("click", () => {
      navbarMenu.classList.toggle("active")
    })
  }

  // Smooth scroll for anchor links
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", function (e) {
      e.preventDefault()
      const target = document.querySelector(this.getAttribute("href"))
      if (target) {
        target.scrollIntoView({
          behavior: "smooth",
          block: "start",
        })
      }
    })
  })

  // Add animation to elements when they come into view
  const observerOptions = {
    threshold: 0.1,
    rootMargin: "0px 0px -50px 0px",
  }

  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("fade-in")
        observer.unobserve(entry.target)
      }
    })
  }, observerOptions)

  document.querySelectorAll(".card, .feature-box, .flight-card").forEach((el) => {
    observer.observe(el)
  })

  // Auto-hide alerts after 5 seconds
  const alerts = document.querySelectorAll(".alert")
  alerts.forEach((alert) => {
    setTimeout(() => {
      alert.style.transition = "opacity 0.5s ease"
      alert.style.opacity = "0"
      setTimeout(() => alert.remove(), 500)
    }, 5000)
  })
})

// Form validation helper
function validateEmail(email) {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return re.test(email)
}

function validatePhone(phone) {
  const re = /^[0-9]{9,15}$/
  return re.test(phone.replace(/[\s-]/g, ""))
}

// Show loading spinner
function showLoading() {
  const spinner = document.createElement("div")
  spinner.className = "spinner"
  spinner.id = "loading-spinner"
  document.body.appendChild(spinner)
}

function hideLoading() {
  const spinner = document.getElementById("loading-spinner")
  if (spinner) {
    spinner.remove()
  }
}
