<?php
// Start session safely (prevents "session already active" notice)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'db.php';
require_once 'functions.php';

// Admin login
function admin_login($username, $password) {
    // Hardcoded admin credentials - Admin name: Lorain
    if ($username === 'silas' && $password === 'silas123') {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_username'] = $username;
        return true;
    }
    return false;
}

// User registration
function register_user($full_name, $email, $phone, $password) {
    global $conn;
    
    $full_name = clean_input($full_name);
    $email = clean_input($email);
    // Remove spaces and ensure it starts with +237 if not already present
    $phone = preg_replace('/\s+/', '', $phone); // Remove all spaces
    if (!str_starts_with($phone, '+237')) {
        $phone = '+237' . $phone;
    }
    $phone = clean_input($phone);
    $password_hash = password_hash($password, PASSWORD_DEFAULT);
    
    // Check if email exists
    $check_query = "SELECT * FROM users WHERE email = '$email'";
    $check_result = mysqli_query($conn, $check_query);
    
    if (mysqli_num_rows($check_result) > 0) {
        return false; // Email already exists
    }
    
    $query = "INSERT INTO users (full_name, email, phone, password) 
              VALUES ('$full_name', '$email', '$phone', '$password_hash')";
    
    if (mysqli_query($conn, $query)) {
        return mysqli_insert_id($conn);
    }
    return false;
}

// User login
function user_login($email, $password) {
    global $conn;
    
    $email = clean_input($email);
    
    $query = "SELECT * FROM users WHERE email = '$email'";
    $result = mysqli_query($conn, $query);
    
    if (mysqli_num_rows($result) == 1) {
        $user = mysqli_fetch_assoc($result);
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['user_email'] = $user['email'];
            return true;
        }
    }
    return false;
}

// Logout
function logout() {
    session_destroy();
    header('Location: ../index.php');
    exit();
}
?>
