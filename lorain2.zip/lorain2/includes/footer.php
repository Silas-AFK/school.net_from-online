<footer class="footer">
    <div class="container">
        <div class="footer-content">
            <div class="footer-section">
                <h3>Lorain Air Travel</h3>
                <p>Your trusted partner for air travel. Fly with comfort and confidence.</p>
                <div class="social-links">
                    <a href="#"><i class="fab fa-facebook"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-linkedin"></i></a>
                </div>
            </div>
            
            <div class="footer-section">
                <h4>Quick Links</h4>
                <ul>
                    <li><a href="<?php echo isset($base_url) ? $base_url : '../'; ?>index.php">Home</a></li>
                    <li><a href="<?php echo isset($base_url) ? $base_url : '../'; ?>user/search_flights.php">Search Flights</a></li>
                    <li><a href="<?php echo isset($base_url) ? $base_url : '../'; ?>user/my_bookings.php">My Bookings</a></li>
                    <li><a href="<?php echo isset($base_url) ? $base_url : '../'; ?>auth/login.php">Login</a></li>
                </ul>
            </div>
            
            <div class="footer-section">
                <h4>Contact Us</h4>
                <ul>
                    <li><i class="fas fa-phone"></i> 676763842</li>
                    <li><i class="fas fa-envelope"></i> afanwisilas98@gmail.com</li>
                    <li><i class="fas fa-map-marker-alt"></i> Cameroon, Bamenda</li>
                </ul>
            </div>
        </div>
        
        <div class="footer-bottom">
            <p>&copy; 2025 Lorain Air Travel Agency. All rights reserved.</p>
        </div>
    </div>
</footer>

<script src="<?php echo isset($base_url) ? $base_url : '../'; ?>assets/js/main.js"></script>
</body>
</html>
