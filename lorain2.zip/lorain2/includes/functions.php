<?php
// Sanitize input data
function clean_input($data) {
    global $conn;
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return mysqli_real_escape_string($conn, $data);
}

// Generate unique booking reference
function generate_booking_reference() {
    return 'LR' . strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, 8));
}

// Format currency
function format_currency($amount) {
    return number_format($amount, 0) . ' FCFA';
}

// Format date
function format_date($date) {
    return date('d M Y', strtotime($date));
}

// Format time
function format_time($time) {
    return date('h:i A', strtotime($time));
}

// Check if user is logged in
function is_logged_in() {
    return isset($_SESSION['user_id']);
}

// Check if admin is logged in
function is_admin_logged_in() {
    return isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
}

// Get user details
function get_user_details($user_id) {
    global $conn;
    $query = "SELECT * FROM users WHERE user_id = " . (int)$user_id;
    $result = mysqli_query($conn, $query);
    return mysqli_fetch_assoc($result);
}

// Get flight details
function get_flight_details($flight_id) {
    global $conn;
    $query = "SELECT f.*, p.plane_name, p.plane_model 
              FROM flights f 
              LEFT JOIN planes p ON f.plane_id = p.plane_id 
              WHERE f.flight_id = " . (int)$flight_id;
    $result = mysqli_query($conn, $query);
    return mysqli_fetch_assoc($result);
}

// Search flights
function search_flights($from, $to, $date) {
    global $conn;
    $from = clean_input($from);
    $to = clean_input($to);
    $date = clean_input($date);
    
    $query = "SELECT f.*, p.plane_name, p.plane_model 
              FROM flights f 
              LEFT JOIN planes p ON f.plane_id = p.plane_id 
              WHERE LOWER(f.departure_city) LIKE LOWER('%$from%') 
              AND LOWER(f.arrival_city) LIKE LOWER('%$to%') 
              AND f.departure_date = '$date' 
              AND f.status = 'scheduled' 
              AND f.available_seats > 0
              ORDER BY f.departure_time ASC";
    
    return mysqli_query($conn, $query);
}

// Get user bookings
function get_user_bookings($user_id) {
    global $conn;
    $query = "SELECT b.*, f.flight_number, f.departure_city, f.arrival_city, 
              f.departure_date, f.departure_time, f.arrival_date, f.arrival_time 
              FROM bookings b 
              JOIN flights f ON b.flight_id = f.flight_id 
              WHERE b.user_id = " . (int)$user_id . " 
              ORDER BY b.booking_date DESC";
    
    return mysqli_query($conn, $query);
}
?>
