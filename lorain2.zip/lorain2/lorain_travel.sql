-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 20, 2025 at 12:41 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lorain_travel`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `booking_id` int(11) NOT NULL,
  `booking_reference` varchar(20) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `flight_id` int(11) DEFAULT NULL,
  `passenger_name` varchar(100) NOT NULL,
  `passenger_email` varchar(100) NOT NULL,
  `passenger_phone` varchar(20) NOT NULL,
  `id_number` varchar(50) NOT NULL,
  `seat_number` varchar(10) DEFAULT NULL,
  `num_passengers` int(11) DEFAULT 1,
  `total_amount` decimal(10,2) NOT NULL,
  `payment_status` enum('pending','confirmed','cancelled') DEFAULT 'confirmed',
  `booking_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`booking_id`, `booking_reference`, `user_id`, `flight_id`, `passenger_name`, `passenger_email`, `passenger_phone`, `id_number`, `seat_number`, `num_passengers`, `total_amount`, `payment_status`, `booking_date`) VALUES
(1, 'LR082A1762', NULL, 10, 'Afanwi Silas Shu', 'silasafanwi6@gmail.com', '+237676763842', '34566765r54444', NULL, 1, 25000.00, 'confirmed', '2025-12-19 22:08:34'),
(2, 'LRC8D87F41', NULL, 10, 'Afanwi Silas Shu', 'silasafanwi6@gmail.com', '+237676763842', '34566765r54444', NULL, 1, 25000.00, 'confirmed', '2025-12-19 22:12:21'),
(3, 'LRED734404', NULL, 10, 'Afanwi Silas Shu', 'silasafanwi6@gmail.com', '676763842', '34566765r54444', NULL, 1, 25000.00, 'confirmed', '2025-12-19 22:16:05'),
(4, 'LR12E5AD10', 1, 10, 'Afanwi Silas Shu', 'silasafanwi6@gmail.com', '678787889', '34566765r54444', NULL, 1, 25000.00, 'confirmed', '2025-12-19 22:40:16'),
(5, 'LR2AA8EC1F', 3, 10, 'kum bless', 'qdcchccchg@fjhhhj.com', '+237676763842', '34566765r54444', NULL, 1, 25000.00, 'confirmed', '2025-12-19 22:48:17'),
(6, 'LR248F60E0', 4, 10, 'ambe daren', 'dhfcjc@56k.com', '+237676763842', '34566765r54444', NULL, 1, 25000.00, 'confirmed', '2025-12-19 23:07:36'),
(7, 'LR0AD701B4', NULL, 10, 'Afanwi Silas Shu', 'silasafanwi6@gmail.com', '+237676763842', '34566765r54444', NULL, 1, 25000.00, 'confirmed', '2025-12-19 23:25:53');

-- --------------------------------------------------------

--
-- Table structure for table `flights`
--

CREATE TABLE `flights` (
  `flight_id` int(11) NOT NULL,
  `flight_number` varchar(20) NOT NULL,
  `plane_id` int(11) DEFAULT NULL,
  `departure_city` varchar(100) NOT NULL,
  `arrival_city` varchar(100) NOT NULL,
  `departure_date` date NOT NULL,
  `departure_time` time NOT NULL,
  `arrival_date` date NOT NULL,
  `arrival_time` time NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `available_seats` int(11) NOT NULL,
  `status` enum('scheduled','boarding','departed','arrived','cancelled') DEFAULT 'scheduled',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `flights`
--

INSERT INTO `flights` (`flight_id`, `flight_number`, `plane_id`, `departure_city`, `arrival_city`, `departure_date`, `departure_time`, `arrival_date`, `arrival_time`, `price`, `available_seats`, `status`, `created_at`) VALUES
(1, 'LR101', 1, 'Nairobi', 'Mombasa', '2025-01-15', '08:00:00', '2025-01-15', '09:15:00', 8500.00, 189, 'scheduled', '2025-12-19 20:31:55'),
(2, 'LR102', 2, 'Nairobi', 'Kisumu', '2025-01-15', '10:30:00', '2025-01-15', '11:30:00', 7200.00, 180, 'scheduled', '2025-12-19 20:31:55'),
(3, 'LR103', 3, 'Nairobi', 'Dar es Salaam', '2025-01-16', '14:00:00', '2025-01-16', '15:45:00', 12000.00, 242, 'scheduled', '2025-12-19 20:31:55'),
(4, 'LR104', 1, 'Mombasa', 'Nairobi', '2025-01-15', '11:00:00', '2025-01-15', '12:15:00', 8500.00, 189, 'scheduled', '2025-12-19 20:31:55'),
(5, 'LR105', 4, 'Nairobi', 'Kampala', '2025-01-17', '07:00:00', '2025-01-17', '08:30:00', 15000.00, 300, 'scheduled', '2025-12-19 20:31:55'),
(6, 'LR106', 2, 'Kisumu', 'Nairobi', '2025-01-15', '13:00:00', '2025-01-15', '14:00:00', 7200.00, 180, 'scheduled', '2025-12-19 20:31:55'),
(8, 'LR108', 4, 'Nairobi', 'Addis Ababa', '2025-01-19', '06:00:00', '2025-01-19', '08:30:00', 22000.00, 300, 'scheduled', '2025-12-19 20:31:55'),
(10, 'AS23', 1, 'Bamenda', 'abuja', '2025-12-21', '16:24:00', '2025-12-31', '04:27:00', 25000.00, 0, 'scheduled', '2025-12-19 21:23:47');

-- --------------------------------------------------------

--
-- Table structure for table `planes`
--

CREATE TABLE `planes` (
  `plane_id` int(11) NOT NULL,
  `plane_name` varchar(100) NOT NULL,
  `plane_model` varchar(100) NOT NULL,
  `capacity` int(11) NOT NULL,
  `status` enum('active','maintenance','inactive') DEFAULT 'active',
  `image_url` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `planes`
--

INSERT INTO `planes` (`plane_id`, `plane_name`, `plane_model`, `capacity`, `status`, `image_url`, `created_at`) VALUES
(1, 'Lorain Express 1', 'Boeing 737-800', 189, 'active', 'assets/images/planes/plane1.jpg', '2025-12-19 20:31:55'),
(2, 'Lorain Cruiser', 'Airbus A320', 180, 'active', 'assets/images/planes/plane2.jpg', '2025-12-19 20:31:55'),
(3, 'Lorain Skyline', 'Boeing 787 Dreamliner', 242, 'active', 'assets/images/planes/plane3.jpg', '2025-12-19 20:31:55'),
(4, 'Lorain Voyager', 'Airbus A350', 300, 'active', 'assets/images/planes/plane4.jpg', '2025-12-19 20:31:55');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  `id_number` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `full_name`, `email`, `phone`, `password`, `id_number`, `created_at`) VALUES
(1, 'Afanwi Silas Shu', 'silasafanwi6@gmail.com', '676763842', '$2y$10$kpCwqOFPtqrm9EjvkZUcXOSEQHijswfMlKQXmI3OgvBugwmtSvijy', NULL, '2025-12-19 21:11:57'),
(2, 'Afanwi Silas Shu', 'sdcchccchg@fjhhhj.com', '+237676763847', '$2y$10$LdGqspoMxO2H5KrD4PBdG.rjGaI/e34NVvM65pZzu0balq02GzpRi', NULL, '2025-12-19 22:19:50'),
(3, 'kum bless', 'qdcchccchg@fjhhhj.com', '+237676763846', '$2y$10$Qs7LH20GShS5.NhxTZXkcO/duNYg7SVYgr7ZzxrZHV4.nSiuWflkS', NULL, '2025-12-19 22:47:05'),
(4, 'ambe daren', 'dhfcjc@56k.com', '+237676763842', '$2y$10$2ewgepAyFCJxPxjso0Z1POSre3xkEXuWt9jAtdKmKVaQTilFtjxpy', NULL, '2025-12-19 23:06:24');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`booking_id`),
  ADD UNIQUE KEY `booking_reference` (`booking_reference`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `flight_id` (`flight_id`);

--
-- Indexes for table `flights`
--
ALTER TABLE `flights`
  ADD PRIMARY KEY (`flight_id`),
  ADD UNIQUE KEY `flight_number` (`flight_number`),
  ADD KEY `plane_id` (`plane_id`);

--
-- Indexes for table `planes`
--
ALTER TABLE `planes`
  ADD PRIMARY KEY (`plane_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `booking_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `flights`
--
ALTER TABLE `flights`
  MODIFY `flight_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `planes`
--
ALTER TABLE `planes`
  MODIFY `plane_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `bookings_ibfk_2` FOREIGN KEY (`flight_id`) REFERENCES `flights` (`flight_id`);

--
-- Constraints for table `flights`
--
ALTER TABLE `flights`
  ADD CONSTRAINT `flights_ibfk_1` FOREIGN KEY (`plane_id`) REFERENCES `planes` (`plane_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
