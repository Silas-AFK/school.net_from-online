<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/auth.php';

// Check if already logged in
if (isset($_SESSION['user_id'])) {
    header('Location: ../user/my_bookings.php');
    exit();
}

if (isset($_SESSION['admin_logged_in'])) {
    header('Location: ../admin/dashboard.php');
    exit();
}

$page_title = 'Login';
$base_url = '../';
$is_admin = isset($_GET['admin']);

// Handle login
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['admin_login'])) {
        // Admin login
        $username = $_POST['username'];
        $password = $_POST['password'];
        
        if (admin_login($username, $password)) {
            header('Location: ../admin/dashboard.php');
            exit();
        } else {
            $error = "Invalid admin credentials!";
        }
    } else {
        // User login
        $email = $_POST['email'];
        $password = $_POST['password'];
        
        if (user_login($email, $password)) {
            header('Location: ../user/my_bookings.php');
            exit();
        } else {
            $error = "Invalid email or password!";
        }
    }
}

require_once '../includes/header.php';
?>

<nav class="navbar">
    <div class="container">
        <a href="../index.php" class="navbar-brand">
            <i class="fas fa-plane"></i> Lorain Air Travel
        </a>
        <button class="navbar-toggle" aria-label="Toggle navigation">
            <i class="fas fa-bars"></i>
        </button>
        <ul class="navbar-menu">
            <li><a href="../index.php"><i class="fas fa-home"></i> Home</a></li>
            <li><a href="../user/search_flights.php"><i class="fas fa-search"></i> Search Flights</a></li>
            <li><a href="login.php"><i class="fas fa-sign-in-alt"></i> Login</a></li>
            <li><a href="register.php"><i class="fas fa-user-plus"></i> Register</a></li>
        </ul>
    </div>
</nav>

<div style="padding: 80px 20px; background: linear-gradient(135deg, var(--primary-color), #0052a3); min-height: 90vh; display: flex; align-items: center; justify-content: center;">
    <div class="container">
        <div style="max-width: 500px; margin: 0 auto; background: white; padding: 50px; border-radius: 15px; box-shadow: 0 10px 40px rgba(0,0,0,0.2);" class="fade-in">
            <div style="text-align: center; margin-bottom: 40px;">
                <div style="font-size: 4rem; color: var(--primary-color); margin-bottom: 15px;">
                    <i class="fas fa-<?php echo $is_admin ? 'user-shield' : 'user-circle'; ?>"></i>
                </div>
                <h1 style="margin: 0 0 10px 0; color: var(--dark-color);">
                    <?php echo $is_admin ? 'Admin Login' : 'Welcome Back'; ?>
                </h1>
                <p style="color: #666; margin: 0;">
                    <?php echo $is_admin ? 'Login to access admin panel' : 'Login to manage your bookings'; ?>
                </p>
            </div>

            <?php if (isset($error)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <?php if (isset($_GET['registered'])): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> Registration successful! Please login.
                </div>
            <?php endif; ?>

            <form method="POST" style="margin-top: 30px;">
                <?php if ($is_admin): ?>
                    <div class="form-group">
                        <label for="username"><i class="fas fa-user"></i> Username</label>
                        <input type="text" id="username" name="username" required autofocus>
                    </div>
                    <div class="form-group">
                        <label for="password"><i class="fas fa-lock"></i> Password</label>
                        <input type="password" id="password" name="password" required>
                    </div>
                    <button type="submit" name="admin_login" class="btn btn-primary" style="width: 100%; padding: 15px; font-size: 1.1rem; margin-top: 20px;">
                        <i class="fas fa-sign-in-alt"></i> Login as Admin
                    </button>
                <?php else: ?>
                    <div class="form-group">
                        <label for="email"><i class="fas fa-envelope"></i> Email Address</label>
                        <input type="email" id="email" name="email" required autofocus>
                    </div>
                    <div class="form-group">
                        <label for="password"><i class="fas fa-lock"></i> Password</label>
                        <input type="password" id="password" name="password" required>
                    </div>
                    <button type="submit" class="btn btn-primary" style="width: 100%; padding: 15px; font-size: 1.1rem; margin-top: 20px;">
                        <i class="fas fa-sign-in-alt"></i> Login
                    </button>
                <?php endif; ?>
            </form>

            <?php if (!$is_admin): ?>
                <div style="text-align: center; margin-top: 30px; padding-top: 30px; border-top: 1px solid var(--border-color);">
                    <p style="color: #666;">
                        Don't have an account? 
                        <a href="register.php" style="color: var(--primary-color); font-weight: 600; text-decoration: none;">
                            Register here
                        </a>
                    </p>
                </div>
            <?php else: ?>
                <div style="text-align: center; margin-top: 30px; padding-top: 30px; border-top: 1px solid var(--border-color);">
                    <a href="login.php" style="color: var(--primary-color); font-weight: 600; text-decoration: none;">
                        <i class="fas fa-arrow-left"></i> Back to User Login
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
