<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/auth.php';

// Check if already logged in
if (isset($_SESSION['user_id'])) {
    header('Location: ../user/my_bookings.php');
    exit();
}

$page_title = 'Register';
$base_url = '../';

// Handle registration
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    // Validation
    if ($password !== $confirm_password) {
        $error = "Passwords do not match!";
    } elseif (strlen($password) < 6) {
        $error = "Password must be at least 6 characters!";
    } else {
        $user_id = register_user($full_name, $email, $phone, $password);
        
        if ($user_id) {
            header('Location: login.php?registered=1');
            exit();
        } else {
            $error = "Email already exists or registration failed!";
        }
    }
}

require_once '../includes/header.php';
?>

<nav class="navbar">
    <div class="container">
        <a href="../index.php" class="navbar-brand">
            <i class="fas fa-plane"></i> Lorain Air Travel
        </a>
        <button class="navbar-toggle" aria-label="Toggle navigation">
            <i class="fas fa-bars"></i>
        </button>
        <ul class="navbar-menu">
            <li><a href="../index.php"><i class="fas fa-home"></i> Home</a></li>
            <li><a href="../user/search_flights.php"><i class="fas fa-search"></i> Search Flights</a></li>
            <li><a href="login.php"><i class="fas fa-sign-in-alt"></i> Login</a></li>
            <li><a href="register.php"><i class="fas fa-user-plus"></i> Register</a></li>
        </ul>
    </div>
</nav>

<div style="padding: 80px 20px; background: linear-gradient(135deg, var(--primary-color), #0052a3); min-height: 90vh; display: flex; align-items: center; justify-content: center;">
    <div class="container">
        <div style="max-width: 550px; margin: 0 auto; background: white; padding: 50px; border-radius: 15px; box-shadow: 0 10px 40px rgba(0,0,0,0.2);" class="fade-in">
            <div style="text-align: center; margin-bottom: 40px;">
                <div style="font-size: 4rem; color: var(--primary-color); margin-bottom: 15px;">
                    <i class="fas fa-user-plus"></i>
                </div>
                <h1 style="margin: 0 0 10px 0; color: var(--dark-color);">Create Account</h1>
                <p style="color: #666; margin: 0;">Join Lorain Air Travel today</p>
            </div>

            <?php if (isset($error)): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <form method="POST" style="margin-top: 30px;">
                <div class="form-group">
                    <label for="full_name"><i class="fas fa-user"></i> Full Name *</label>
                    <input type="text" id="full_name" name="full_name" required autofocus
                           value="<?php echo isset($_POST['full_name']) ? htmlspecialchars($_POST['full_name']) : ''; ?>">
                </div>
                <div class="form-group">
                    <label for="email"><i class="fas fa-envelope"></i> Email Address *</label>
                    <input type="email" id="email" name="email" required
                           value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
                </div>
                <div class="form-group">
                    <label for="phone"><i class="fas fa-phone"></i> Phone Number *</label>
                    <input type="tel" id="phone" name="phone" required 
                           placeholder="+237 676 763 842" 
                           pattern="(\+237\s?)?[0-9]{9}" 
                           title="Please enter a valid Cameroon phone number (9 digits, optional +237 prefix)"
                           value="<?php echo isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : ''; ?>">
                    <small style="color: #666; font-size: 0.85rem;">Format: +237 676 763 842 or 676763842</small>
                </div>
                <div class="form-group">
                    <label for="password"><i class="fas fa-lock"></i> Password *</label>
                    <input type="password" id="password" name="password" required minlength="6">
                    <small style="color: #666; font-size: 0.85rem;">Minimum 6 characters</small>
                </div>
                <div class="form-group">
                    <label for="confirm_password"><i class="fas fa-lock"></i> Confirm Password *</label>
                    <input type="password" id="confirm_password" name="confirm_password" required minlength="6">
                </div>
                
                <button type="submit" class="btn btn-primary" style="width: 100%; padding: 15px; font-size: 1.1rem; margin-top: 20px;">
                    <i class="fas fa-user-plus"></i> Create Account
                </button>
            </form>

            <div style="text-align: center; margin-top: 30px; padding-top: 30px; border-top: 1px solid var(--border-color);">
                <p style="color: #666;">
                    Already have an account? 
                    <a href="login.php" style="color: var(--primary-color); font-weight: 600; text-decoration: none;">
                        Login here
                    </a>
                </p>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
