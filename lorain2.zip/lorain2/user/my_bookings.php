<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

if (!is_logged_in()) {
    header('Location: ../auth/login.php');
    exit();
}

$page_title = 'My Bookings';
$base_url = '../';

$bookings = get_user_bookings($_SESSION['user_id']);

require_once '../includes/header.php';
?>

<nav class="navbar">
    <div class="container">
        <a href="../index.php" class="navbar-brand">
            <i class="fas fa-plane"></i> Lorain Air Travel
        </a>
        <button class="navbar-toggle" aria-label="Toggle navigation">
            <i class="fas fa-bars"></i>
        </button>
        <ul class="navbar-menu">
            <li><a href="../index.php"><i class="fas fa-home"></i> Home</a></li>
            <li><a href="search_flights.php"><i class="fas fa-search"></i> Search Flights</a></li>
            <li><a href="my_bookings.php"><i class="fas fa-ticket-alt"></i> My Bookings</a></li>
            <li><a href="profile.php"><i class="fas fa-user"></i> Profile</a></li>
            <li><a href="../auth/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
    </div>
</nav>

<div style="padding: 60px 20px; background: var(--light-color); min-height: 80vh;">
    <div class="container">
        <h1 style="text-align: center; margin-bottom: 40px; color: var(--dark-color);">
            <i class="fas fa-ticket-alt"></i> My Bookings
        </h1>

        <?php if (mysqli_num_rows($bookings) > 0): ?>
            <div style="margin-top: 30px;">
                <?php while($booking = mysqli_fetch_assoc($bookings)): ?>
                    <div class="card fade-in" style="margin-bottom: 20px;">
                        <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
                            <div>
                                <strong><i class="fas fa-barcode"></i> <?php echo $booking['booking_reference']; ?></strong>
                            </div>
                            <div>
                                <span class="badge <?php 
                                    echo $booking['payment_status'] == 'confirmed' ? 'badge-success' : 
                                         ($booking['payment_status'] == 'pending' ? 'badge-warning' : 'badge-danger'); 
                                ?>">
                                    <?php echo ucfirst($booking['payment_status']); ?>
                                </span>
                            </div>
                        </div>
                        <div class="card-body">
                            <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 30px;">
                                <div>
                                    <h3 style="color: var(--primary-color); margin-bottom: 15px;">
                                        <i class="fas fa-plane"></i> <?php echo $booking['flight_number']; ?>
                                    </h3>
                                    <div class="flight-route">
                                        <div class="flight-location">
                                            <div class="city"><?php echo $booking['departure_city']; ?></div>
                                            <div class="time"><?php echo format_time($booking['departure_time']); ?></div>
                                            <div class="date"><?php echo format_date($booking['departure_date']); ?></div>
                                        </div>
                                        <div class="flight-arrow">
                                            <i class="fas fa-arrow-right"></i>
                                        </div>
                                        <div class="flight-location">
                                            <div class="city"><?php echo $booking['arrival_city']; ?></div>
                                            <div class="time"><?php echo format_time($booking['arrival_time']); ?></div>
                                            <div class="date"><?php echo format_date($booking['arrival_date']); ?></div>
                                        </div>
                                    </div>
                                </div>
                                <div>
                                    <p><strong><i class="fas fa-user"></i> Passenger:</strong><br><?php echo $booking['passenger_name']; ?></p>
                                    <p><strong><i class="fas fa-users"></i> Passengers:</strong><br><?php echo $booking['num_passengers']; ?></p>
                                    <p><strong><i class="fas fa-money-bill-wave"></i> Total:</strong><br>
                                        <span style="font-size: 1.3rem; color: var(--success-color); font-weight: bold;">
                                            <?php echo format_currency($booking['total_amount']); ?>
                                        </span>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer">
                            <div>
                                <small><i class="fas fa-calendar"></i> Booked on: <?php echo date('d M Y, h:i A', strtotime($booking['booking_date'])); ?></small>
                            </div>
                            <div>
                                <a href="ticket_pdf.php?booking_id=<?php echo $booking['booking_id']; ?>" class="btn btn-primary" target="_blank">
                                    <i class="fas fa-download"></i> Download Ticket
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <div class="alert alert-info" style="text-align: center; padding: 60px;">
                <i class="fas fa-info-circle" style="font-size: 4rem; margin-bottom: 20px;"></i>
                <h3>No Bookings Yet</h3>
                <p>You haven't made any flight bookings yet. Start exploring our destinations!</p>
                <a href="search_flights.php" class="btn btn-primary" style="margin-top: 20px;">
                    <i class="fas fa-search"></i> Search Flights
                </a>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
