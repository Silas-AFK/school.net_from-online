<?php
session_start();
$page_title = 'Search Flights';
$base_url = '../';
require_once '../includes/header.php';
?>

<nav class="navbar">
    <div class="container">
        <a href="../index.php" class="navbar-brand">
            <i class="fas fa-plane"></i> Lorain Air Travel
        </a>
        <button class="navbar-toggle" aria-label="Toggle navigation">
            <i class="fas fa-bars"></i>
        </button>
        <ul class="navbar-menu">
            <li><a href="../index.php"><i class="fas fa-home"></i> Home</a></li>
            <li><a href="search_flights.php"><i class="fas fa-search"></i> Search Flights</a></li>
            <?php if(isset($_SESSION['user_id'])): ?>
                <li><a href="my_bookings.php"><i class="fas fa-ticket-alt"></i> My Bookings</a></li>
                <li><a href="profile.php"><i class="fas fa-user"></i> Profile</a></li>
                <li><a href="../auth/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            <?php else: ?>
                <li><a href="../auth/login.php"><i class="fas fa-sign-in-alt"></i> Login</a></li>
                <li><a href="../auth/register.php"><i class="fas fa-user-plus"></i> Register</a></li>
            <?php endif; ?>
        </ul>
    </div>
</nav>

<div style="padding: 60px 20px; background: var(--light-color); min-height: 80vh;">
    <div class="container">
        <h1 style="text-align: center; margin-bottom: 40px; color: var(--dark-color);">
            <i class="fas fa-search"></i> Search Available Flights
        </h1>
        
        <form action="flight_results.php" method="GET" class="search-form fade-in" onsubmit="return validateSearchForm()">
            <div class="form-row">
                <div class="form-group">
                    <label for="from_city"><i class="fas fa-plane-departure"></i> Departure City</label>
                    <input type="text" id="from_city" name="from_city" placeholder="e.g., Douala" required 
                           value="<?php echo isset($_GET['from_city']) ? htmlspecialchars($_GET['from_city']) : ''; ?>">
                </div>
                <div class="form-group">
                    <label for="to_city"><i class="fas fa-plane-arrival"></i> Arrival City</label>
                    <input type="text" id="to_city" name="to_city" placeholder="e.g., Yaoundé" required
                           value="<?php echo isset($_GET['to_city']) ? htmlspecialchars($_GET['to_city']) : ''; ?>">
                </div>
                <div class="form-group">
                    <label for="departure_date"><i class="fas fa-calendar"></i> Departure Date</label>
                    <input type="date" id="departure_date" name="departure_date" min="<?php echo date('Y-m-d'); ?>" required
                           value="<?php echo isset($_GET['departure_date']) ? htmlspecialchars($_GET['departure_date']) : ''; ?>">
                </div>
            </div>
            <div style="text-align: center; margin-top: 20px;">
                <button type="submit" class="btn btn-primary" style="padding: 15px 50px; font-size: 1.1rem;">
                    <i class="fas fa-search"></i> Search Flights
                </button>
            </div>
        </form>

        <!-- Updated popular destinations to show Cameroon cities -->
        <div style="margin-top: 60px;">
            <h2 style="text-align: center; margin-bottom: 30px; color: var(--dark-color);">Popular Destinations</h2>
            <div class="cards-grid">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-map-marker-alt"></i> Douala - Yaoundé</h3>
                    </div>
                    <div class="card-body">
                        <p><strong>Duration:</strong> 1h</p>
                        <p><strong>From:</strong> 35,000 FCFA</p>
                        <p>Experience the capital city with daily flights available.</p>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-map-marker-alt"></i> Douala - Garoua</h3>
                    </div>
                    <div class="card-body">
                        <p><strong>Duration:</strong> 2h 30m</p>
                        <p><strong>From:</strong> 55,000 FCFA</p>
                        <p>Visit the northern region with convenient flight schedules.</p>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-map-marker-alt"></i> Yaoundé - Garoua</h3>
                    </div>
                    <div class="card-body">
                        <p><strong>Duration:</strong> 2h 15m</p>
                        <p><strong>From:</strong> 50,000 FCFA</p>
                        <p>Explore northern Cameroon with affordable flights.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>

<script src="../assets/js/validation.js"></script>
