<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

if (!is_logged_in()) {
    header('Location: ../auth/login.php');
    exit();
}

$page_title = 'My Profile';
$base_url = '../';

$user = get_user_details($_SESSION['user_id']);

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $full_name = clean_input($_POST['full_name']);
    $phone = preg_replace('/\s+/', '', $_POST['phone']); // Remove all spaces
    if (!str_starts_with($phone, '+237')) {
        $phone = '+237' . $phone;
    }
    $phone = clean_input($phone);
    
    $query = "UPDATE users SET full_name = '$full_name', phone = '$phone' WHERE user_id = " . $_SESSION['user_id'];
    
    if (mysqli_query($conn, $query)) {
        $_SESSION['user_name'] = $full_name;
        $success = "Profile updated successfully!";
        $user = get_user_details($_SESSION['user_id']);
    } else {
        $error = "Update failed. Please try again.";
    }
}

require_once '../includes/header.php';
?>

<nav class="navbar">
    <div class="container">
        <a href="../index.php" class="navbar-brand">
            <i class="fas fa-plane"></i> Lorain Air Travel
        </a>
        <button class="navbar-toggle" aria-label="Toggle navigation">
            <i class="fas fa-bars"></i>
        </button>
        <ul class="navbar-menu">
            <li><a href="../index.php"><i class="fas fa-home"></i> Home</a></li>
            <li><a href="search_flights.php"><i class="fas fa-search"></i> Search Flights</a></li>
            <li><a href="my_bookings.php"><i class="fas fa-ticket-alt"></i> My Bookings</a></li>
            <li><a href="profile.php"><i class="fas fa-user"></i> Profile</a></li>
            <li><a href="../auth/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
    </div>
</nav>

<div style="padding: 60px 20px; background: var(--light-color); min-height: 80vh;">
    <div class="container">
        <h1 style="text-align: center; margin-bottom: 40px; color: var(--dark-color);">
            <i class="fas fa-user"></i> My Profile
        </h1>

        <?php if (isset($success)): ?>
            <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo $success; ?></div>
        <?php endif; ?>
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><i class="fas fa-exclamation-circle"></i> <?php echo $error; ?></div>
        <?php endif; ?>

        <div style="max-width: 600px; margin: 0 auto; background: white; padding: 40px; border-radius: 10px; box-shadow: 0 5px 15px rgba(0,0,0,0.1);">
            <form method="POST">
                <div class="form-group">
                    <label for="full_name"><i class="fas fa-user"></i> Full Name</label>
                    <input type="text" id="full_name" name="full_name" value="<?php echo htmlspecialchars($user['full_name']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="email"><i class="fas fa-envelope"></i> Email Address</label>
                    <input type="email" id="email" value="<?php echo htmlspecialchars($user['email']); ?>" disabled 
                           style="background: var(--light-color); cursor: not-allowed;">
                    <small style="color: #666; font-size: 0.85rem;">Email cannot be changed</small>
                </div>
                <div class="form-group">
                    <label for="phone"><i class="fas fa-phone"></i> Phone Number</label>
                    <input type="tel" id="phone" name="phone" 
                           value="<?php echo htmlspecialchars($user['phone']); ?>" 
                           required 
                           placeholder="+237 676 763 842" 
                           pattern="(\+237\s?)?[0-9]{9}" 
                           title="Please enter a valid Cameroon phone number (9 digits, optional +237 prefix)">
                    <small style="color: #666; font-size: 0.85rem;">Format: +237 676 763 842 or 676763842</small>
                </div>
                <div class="form-group">
                    <label><i class="fas fa-calendar"></i> Member Since</label>
                    <input type="text" value="<?php echo date('d M Y', strtotime($user['created_at'])); ?>" disabled 
                           style="background: var(--light-color); cursor: not-allowed;">
                </div>
                
                <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 20px; padding: 15px;">
                    <i class="fas fa-save"></i> Update Profile
                </button>
            </form>
            
            <hr style="margin: 40px 0; border: none; border-top: 1px solid var(--border-color);">
            
            <div style="text-align: center;">
                <a href="my_bookings.php" class="btn btn-secondary">
                    <i class="fas fa-ticket-alt"></i> View My Bookings
                </a>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
