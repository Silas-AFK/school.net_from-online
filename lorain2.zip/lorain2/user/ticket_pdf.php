<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/functions.php';
require_once '../fpdf/fpdf.php';

// Check if booking_id is provided
if (!isset($_GET['booking_id'])) {
    header('Location: search_flights.php');
    exit();
}

$booking_id = (int)$_GET['booking_id'];

// Get booking details with flight information
$query = "SELECT b.*, f.flight_number, f.departure_city, f.arrival_city, 
          f.departure_date, f.departure_time, f.arrival_date, f.arrival_time,
          p.plane_name, p.plane_model
          FROM bookings b 
          JOIN flights f ON b.flight_id = f.flight_id 
          LEFT JOIN planes p ON f.plane_id = p.plane_id
          WHERE b.booking_id = $booking_id";

$result = mysqli_query($conn, $query);
$booking = mysqli_fetch_assoc($result);

// Beautiful HTML fallback if booking not found
if (!$booking) {
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Booking Not Found | Lorain Air Travel</title>
        <style>
            body {
                margin: 0;
                font-family: Arial, sans-serif;
                background: linear-gradient(135deg, #0066cc, #00a8ff);
                color: #333;
                display: flex;
                align-items: center;
                justify-content: center;
                min-height: 100vh;
            }
            .card {
                background: #ffffff;
                border-radius: 12px;
                box-shadow: 0 10px 25px rgba(0,0,0,0.15);
                max-width: 500px;
                width: 90%;
                padding: 30px 25px;
                text-align: center;
            }
            .logo {
                font-size: 26px;
                font-weight: bold;
                color: #0066cc;
                margin-bottom: 5px;
            }
            .tagline {
                font-size: 12px;
                color: #777;
                margin-bottom: 20px;
            }
            .icon {
                font-size: 55px;
                margin-bottom: 15px;
                color: #ff6b6b;
            }
            h1 {
                font-size: 22px;
                margin-bottom: 10px;
                color: #222;
            }
            p {
                font-size: 14px;
                color: #555;
                margin-bottom: 20px;
            }
            .info {
                font-size: 13px;
                color: #777;
                margin-bottom: 20px;
            }
            .btn {
                display: inline-block;
                padding: 10px 20px;
                border-radius: 25px;
                background: #0066cc;
                color: #fff;
                text-decoration: none;
                font-size: 14px;
                font-weight: 600;
                margin: 5px;
                transition: background 0.2s;
            }
            .btn.secondary {
                background: #f1f1f1;
                color: #333;
            }
            .btn:hover {
                background: #004c99;
                color: #fff;
            }
            .footer {
                margin-top: 15px;
                font-size: 11px;
                color: #aaa;
            }
        </style>
    </head>
    <body>
        <div class="card">
            <div class="logo">Lorain Air Travel</div>
            <div class="tagline">Your Journey Begins Here</div>
            <div class="icon">✈️</div>
            <h1>Booking </h1>Sucessfull!
            <p>We guarantee and promise for a sefe flight.</p>
            <div class="info">
                Please make sure you used the correct booking link<br>
                or search for your booking again from the flights page.
            </div>
            <a href="search_flights.php" class="btn">Search Flights</a>
            <a href="../index.php" class="btn secondary">Back to Home</a>
            <div class="footer">
                Lorain Air Travel &middot; Contact: 676763842 &middot; Email: afanwisilas98@gmail.com
            </div>
        </div>
    </body>
    </html>
    <?php
    exit();
}

// Create PDF
class TicketPDF extends FPDF {

    function Header() {
        // Top brand bar
        $this->SetFillColor(0, 51, 102); // Deep blue
        $this->Rect(0, 0, 210, 40, 'F');

        // Accent strip
        $this->SetFillColor(255, 102, 0); // Orange accent
        $this->Rect(0, 38, 210, 2, 'F');

        // Company name
        $this->SetTextColor(255, 255, 255);
        $this->SetFont('Arial', 'B', 24);
        $this->SetY(10);
        $this->Cell(0, 10, 'Lorain Air Travel', 0, 1, 'C');

        // Tagline
        $this->SetFont('Arial', 'I', 11);
        $this->Cell(0, 8, 'Your Journey Begins Here', 0, 1, 'C');

        $this->Ln(8);
    }

    function Footer() {
        $this->SetY(-25);
        $this->SetFont('Arial', 'I', 8);
        $this->SetTextColor(128, 128, 128);
        $this->Cell(0, 5, 'Thank you for choosing Lorain Air Travel', 0, 1, 'C');
        $this->Cell(0, 5, 'Contact: 676763842 | Email: afanwisilas98@gmail.com', 0, 1, 'C');
        $this->Cell(0, 5, 'This ticket is valid only with an official ID/Passport.', 0, 0, 'C');
    }

    function SectionTitle($title) {
        $this->SetFillColor(240, 240, 240);
        $this->SetTextColor(0, 0, 0);
        $this->SetFont('Arial', 'B', 13);
        $this->Cell(0, 9, $title, 0, 1, 'L', true);
        $this->Ln(2);
    }

    function InfoRow($label, $value, $width1 = 60, $width2 = 120) {
        $this->SetFont('Arial', 'B', 11);
        $this->SetTextColor(60, 60, 60);
        $this->Cell($width1, 7, $label . ':', 0, 0);
        $this->SetFont('Arial', '', 11);
        $this->SetTextColor(0, 0, 0);
        $this->Cell($width2, 7, $value, 0, 1);
    }

    // Simple watermark (centered, light text)
    function Watermark($text) {
        $this->SetFont('Arial', 'B', 40);
        $this->SetTextColor(235, 235, 235);
        // Save current position
        $x = $this->GetX();
        $y = $this->GetY();
        // Go to middle of page
        $this->SetXY(15, 120);
        $this->Cell(0, 20, $text, 0, 1, 'C');
        // Restore position
        $this->SetXY($x, $y);
        // Reset color
        $this->SetTextColor(0, 0, 0);
    }
}

$pdf = new TicketPDF();
$pdf->AddPage();
$pdf->SetAutoPageBreak(true, 25);

// Watermark
$pdf->Watermark('LORAIN AIR');

// Booking Reference - Prominent display
$pdf->SetFillColor(255, 102, 0);
$pdf->SetTextColor(255, 255, 255);
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell(0, 12, 'BOOKING REFERENCE: ' . $booking['booking_reference'], 0, 1, 'C', true);
$pdf->Ln(4);

// Booking Status
$statusColor = ($booking['payment_status'] == 'confirmed') ? [40, 167, 69] : [255, 193, 7];
$pdf->SetFillColor($statusColor[0], $statusColor[1], $statusColor[2]);
$pdf->SetTextColor(255, 255, 255);
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 10, 'Status: ' . strtoupper($booking['payment_status']), 0, 1, 'C', true);
$pdf->Ln(5);

// Reset text color
$pdf->SetTextColor(0, 0, 0);

// Passenger Information Section
$pdf->SectionTitle('Passenger Information');
$pdf->InfoRow('Name', $booking['passenger_name']);
$pdf->InfoRow('Email', $booking['passenger_email']);
$pdf->InfoRow('Phone', $booking['passenger_phone']);
$pdf->InfoRow('ID/Passport', $booking['id_number']);
$pdf->InfoRow('Number of Passengers', $booking['num_passengers']);

// Seat number (fallback if not present)
$seatNumber = isset($booking['seat_number']) && $booking['seat_number'] !== '' 
    ? $booking['seat_number'] 
    : 'Not Assigned';
$pdf->InfoRow('Seat Number', $seatNumber);

$pdf->Ln(5);

// Flight Information Section
$pdf->SectionTitle('Flight Information');
$pdf->InfoRow('Flight Number', $booking['flight_number']);
$pdf->InfoRow(
    'Aircraft', 
    trim($booking['plane_name'] . ' (' . $booking['plane_model'] . ')', ' ()')
);
$pdf->Ln(3);

// Departure and Arrival in boxes
$startX = $pdf->GetX();
$startY = $pdf->GetY();

$pdf->SetFillColor(230, 247, 255); // Light blue
$pdf->Rect($startX, $startY, 90, 35, 'F');
$pdf->SetXY($startX, $startY);
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(90, 8, 'DEPARTURE', 0, 1, 'C');

$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(90, 8, $booking['departure_city'], 0, 1, 'C');

$pdf->SetFont('Arial', '', 11);
$pdf->Cell(90, 7, date('d M Y', strtotime($booking['departure_date'])), 0, 1, 'C');

$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(90, 7, date('h:i A', strtotime($booking['departure_time'])), 0, 1, 'C');

// Arrival box
$pdf->SetXY($startX + 100, $startY);
$pdf->SetFillColor(255, 243, 230); // Light orange
$pdf->Rect($startX + 100, $startY, 90, 35, 'F');
$pdf->SetXY($startX + 100, $startY);
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(90, 8, 'ARRIVAL', 0, 1, 'C');

$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(90, 8, $booking['arrival_city'], 0, 1, 'C');

$pdf->SetFont('Arial', '', 11);
$pdf->Cell(90, 7, date('d M Y', strtotime($booking['arrival_date'])), 0, 1, 'C');

$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(90, 7, date('h:i A', strtotime($booking['arrival_time'])), 0, 1, 'C');

$pdf->Ln(8);

// Payment Information Section
$pdf->SectionTitle('Payment Information');
$pricePerPerson = $booking['num_passengers'] > 0
    ? $booking['total_amount'] / $booking['num_passengers']
    : $booking['total_amount'];

$pdf->InfoRow('Price per Person', 'KSh ' . number_format($pricePerPerson, 2));
$pdf->InfoRow('Number of Passengers', $booking['num_passengers']);

$pdf->SetFont('Arial', 'B', 13);
$pdf->SetTextColor(40, 167, 69);
$pdf->InfoRow('TOTAL AMOUNT', 'KSh ' . number_format($booking['total_amount'], 2));
$pdf->SetTextColor(0, 0, 0);
$pdf->SetFont('Arial', '', 11);
$pdf->InfoRow('Booking Date', date('d M Y, h:i A', strtotime($booking['booking_date'])));
$pdf->Ln(8);

// Important Notice
$pdf->SetFillColor(255, 243, 205);
$pdf->Rect($pdf->GetX(), $pdf->GetY(), 190, 30, 'F');
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(0, 8, 'Important Notice:', 0, 1);
$pdf->SetFont('Arial', '', 9);
$pdf->MultiCell(0, 5,
    "- Please arrive at the airport at least 2 hours before departure\n" .
    "- Carry a valid ID/Passport for verification\n" .
    "- Check-in closes 30 minutes before departure\n" .
    "- This is your e-ticket, please keep it safe"
);

$pdf->Ln(5);

// QR Code Section (using external API)
// This relies on internet access from the server.
$qrData = 'Lorain|' . $booking['booking_reference'] . '|' . $booking['passenger_name'] . '|' . $booking['flight_number'];
$qrDataEncoded = urlencode($qrData);
$qrUrl = "https://api.qrserver.com/v1/create-qr-code/?size=120x120&data={$qrDataEncoded}";

$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(0, 6, 'E-TICKET QR CODE', 0, 1, 'C');
$pdf->Ln(1);

// Try to place QR code image from URL
// Note: allow_url_fopen must be enabled for this to work.
$pdf->Image($qrUrl, 80, $pdf->GetY(), 50, 50, 'PNG');
$pdf->Ln(55);

$pdf->SetFont('Arial', '', 9);
$pdf->Cell(0, 5, $booking['booking_reference'], 0, 1, 'C');

// Signature area
$pdf->Ln(10);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(0, 6, 'Authorized Signature: _______________________________', 0, 1, 'L');
$pdf->Ln(3);
$pdf->SetFont('Arial', 'I', 8);
$pdf->Cell(0, 5, 'This ticket is system-generated and valid without a physical stamp.', 0, 1, 'L');

// Output PDF (download)
$pdf->Output('D', 'Lorain_Ticket_' . $booking['booking_reference'] . '.pdf');
?>
