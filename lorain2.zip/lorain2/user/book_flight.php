<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/functions.php';

$page_title = 'Book Flight';
$base_url = '../';

// Check if flight_id is provided
if (!isset($_GET['flight_id'])) {
    header('Location: search_flights.php');
    exit();
}

$flight_id = (int)$_GET['flight_id'];
$flight = get_flight_details($flight_id);

if (!$flight) {
    header('Location: search_flights.php');
    exit();
}

// Handle booking submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $passenger_name = clean_input($_POST['passenger_name']);
    $passenger_email = clean_input($_POST['passenger_email']);
    $passenger_phone = clean_input($_POST['passenger_phone']);
    $id_number = clean_input($_POST['id_number']);
    $num_passengers = (int)$_POST['num_passengers'];
    
    // Generate booking reference
    $booking_ref = generate_booking_reference();
    $total_amount = $flight['price'] * $num_passengers;
    $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : NULL;
    
    // Insert booking
    $query = "INSERT INTO bookings (booking_reference, user_id, flight_id, passenger_name, passenger_email, 
              passenger_phone, id_number, num_passengers, total_amount, payment_status) 
              VALUES ('$booking_ref', " . ($user_id ? $user_id : 'NULL') . ", $flight_id, '$passenger_name', 
              '$passenger_email', '$passenger_phone', '$id_number', $num_passengers, $total_amount, 'confirmed')";
    
    if (mysqli_query($conn, $query)) {
        // Update available seats
        $new_seats = $flight['available_seats'] - $num_passengers;
        $update_query = "UPDATE flights SET available_seats = $new_seats WHERE flight_id = $flight_id";
        mysqli_query($conn, $update_query);
        
        $booking_id = mysqli_insert_id($conn);
        $_SESSION['booking_success'] = $booking_ref;
        header('Location: ticket_pdf.php?booking_id=' . $booking_id);
        exit();
    } else {
        $error = "Booking failed. Please try again.";
    }
}

require_once '../includes/header.php';
?>

<nav class="navbar">
    <div class="container">
        <a href="../index.php" class="navbar-brand">
            <i class="fas fa-plane"></i> Lorain Air Travel
        </a>
        <button class="navbar-toggle" aria-label="Toggle navigation">
            <i class="fas fa-bars"></i>
        </button>
        <ul class="navbar-menu">
            <li><a href="../index.php"><i class="fas fa-home"></i> Home</a></li>
            <li><a href="search_flights.php"><i class="fas fa-search"></i> Search Flights</a></li>
            <?php if(isset($_SESSION['user_id'])): ?>
                <li><a href="my_bookings.php"><i class="fas fa-ticket-alt"></i> My Bookings</a></li>
                <li><a href="profile.php"><i class="fas fa-user"></i> Profile</a></li>
                <li><a href="../auth/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            <?php else: ?>
                <li><a href="../auth/login.php"><i class="fas fa-sign-in-alt"></i> Login</a></li>
                <li><a href="../auth/register.php"><i class="fas fa-user-plus"></i> Register</a></li>
            <?php endif; ?>
        </ul>
    </div>
</nav>

<div style="padding: 60px 20px; background: var(--light-color); min-height: 80vh;">
    <div class="container">
        <h1 style="text-align: center; margin-bottom: 40px; color: var(--dark-color);">
            <i class="fas fa-ticket-alt"></i> Book Your Flight
        </h1>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px; margin-bottom: 30px;">
            <!-- Flight Details -->
            <div class="flight-card">
                <h3 style="margin-bottom: 20px; color: var(--primary-color);">
                    <i class="fas fa-plane"></i> Flight Details
                </h3>
                <div class="flight-route">
                    <div class="flight-location">
                        <div class="city"><?php echo $flight['departure_city']; ?></div>
                        <div class="time"><?php echo format_time($flight['departure_time']); ?></div>
                        <div class="date"><?php echo format_date($flight['departure_date']); ?></div>
                    </div>
                    <div class="flight-arrow">
                        <i class="fas fa-arrow-right"></i>
                    </div>
                    <div class="flight-location">
                        <div class="city"><?php echo $flight['arrival_city']; ?></div>
                        <div class="time"><?php echo format_time($flight['arrival_time']); ?></div>
                        <div class="date"><?php echo format_date($flight['arrival_date']); ?></div>
                    </div>
                </div>
                <div class="flight-details" style="margin-top: 20px;">
                    <div class="detail-item">
                        <i class="fas fa-plane"></i>
                        <span><strong>Flight:</strong> <?php echo $flight['flight_number']; ?></span>
                    </div>
                    <div class="detail-item">
                        <i class="fas fa-plane"></i>
                        <span><strong>Aircraft:</strong> <?php echo $flight['plane_model']; ?></span>
                    </div>
                    <div class="detail-item">
                        <i class="fas fa-chair"></i>
                        <span><strong>Available:</strong> <?php echo $flight['available_seats']; ?> seats</span>
                    </div>
                    <div class="detail-item">
                        <i class="fas fa-money-bill-wave"></i>
                        <span><strong>Price:</strong> <?php echo format_currency($flight['price']); ?> per person</span>
                    </div>
                </div>
            </div>

            <!-- Booking Form -->
            <div style="background: white; padding: 30px; border-radius: 10px; box-shadow: 0 5px 15px rgba(0,0,0,0.1);">
                <h3 style="margin-bottom: 20px; color: var(--primary-color);">
                    <i class="fas fa-user"></i> Passenger Information
                </h3>
                <form method="POST" onsubmit="return validateBookingForm()">
                    <div class="form-group">
                        <label for="passenger_name">Full Name *</label>
                        <input type="text" id="passenger_name" name="passenger_name" required
                               value="<?php echo isset($_SESSION['user_name']) ? $_SESSION['user_name'] : ''; ?>">
                    </div>
                    <div class="form-group">
                        <label for="passenger_email">Email Address *</label>
                        <input type="email" id="passenger_email" name="passenger_email" required
                               value="<?php echo isset($_SESSION['user_email']) ? $_SESSION['user_email'] : ''; ?>">
                    </div>
                    <div class="form-group">
                        <label for="passenger_phone">Phone Number *</label>
                        <input type="tel" id="passenger_phone" name="passenger_phone" required
                               placeholder="+237 676 763 842" pattern="(\+237|237)?[0-9]{9}">
                        <small style="color: #666;">Format: +237 6XX XXX XXX or 6XXXXXXXX</small>
                    </div>
                    <div class="form-group">
                        <label for="id_number">ID/Passport Number *</label>
                        <input type="text" id="id_number" name="id_number" required
                               placeholder="Enter your ID or Passport number">
                    </div>
                    <div class="form-group">
                        <label for="num_passengers">Number of Passengers *</label>
                        <input type="number" id="num_passengers" name="num_passengers" min="1" 
                               max="<?php echo $flight['available_seats']; ?>" value="1" required
                               onchange="updateTotal()">
                    </div>
                    
                    <div style="background: var(--light-color); padding: 20px; border-radius: 5px; margin: 20px 0;">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <span style="font-size: 1.2rem; font-weight: 600;">Total Amount:</span>
                            <span id="total_amount" style="font-size: 1.8rem; font-weight: bold; color: var(--success-color);">
                                <?php echo format_currency($flight['price']); ?>
                            </span>
                        </div>
                    </div>
                    
                    <button type="submit" class="btn btn-primary" style="width: 100%; padding: 15px; font-size: 1.1rem;">
                        <i class="fas fa-check"></i> Confirm Booking
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>

<script src="../assets/js/validation.js"></script>
<script>
function updateTotal() {
    const numPassengers = document.getElementById('num_passengers').value;
    const pricePerPerson = <?php echo $flight['price']; ?>;
    const total = numPassengers * pricePerPerson;
    document.getElementById('total_amount').textContent = total.toLocaleString('fr-FR') + ' FCFA';
}
</script>
