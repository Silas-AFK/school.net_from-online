<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/functions.php';

$page_title = 'Flight Results';
$base_url = '../';

// Get search parameters
$from_city = isset($_GET['from_city']) ? clean_input($_GET['from_city']) : '';
$to_city = isset($_GET['to_city']) ? clean_input($_GET['to_city']) : '';
$departure_date = isset($_GET['departure_date']) ? clean_input($_GET['departure_date']) : '';

require_once '../includes/header.php';
?>

<nav class="navbar">
    <div class="container">
        <a href="../index.php" class="navbar-brand">
            <i class="fas fa-plane"></i> Lorain Air Travel
        </a>
        <button class="navbar-toggle" aria-label="Toggle navigation">
            <i class="fas fa-bars"></i>
        </button>
        <ul class="navbar-menu">
            <li><a href="../index.php"><i class="fas fa-home"></i> Home</a></li>
            <li><a href="search_flights.php"><i class="fas fa-search"></i> Search Flights</a></li>
            <?php if(isset($_SESSION['user_id'])): ?>
                <li><a href="my_bookings.php"><i class="fas fa-ticket-alt"></i> My Bookings</a></li>
                <li><a href="profile.php"><i class="fas fa-user"></i> Profile</a></li>
                <li><a href="../auth/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            <?php else: ?>
                <li><a href="../auth/login.php"><i class="fas fa-sign-in-alt"></i> Login</a></li>
                <li><a href="../auth/register.php"><i class="fas fa-user-plus"></i> Register</a></li>
            <?php endif; ?>
        </ul>
    </div>
</nav>

<div style="padding: 60px 20px; background: var(--light-color); min-height: 80vh;">
    <div class="container">
        <h1 style="text-align: center; margin-bottom: 30px; color: var(--dark-color);">
            <i class="fas fa-plane"></i> Available Flights
        </h1>
        
        <div style="background: white; padding: 20px; border-radius: 10px; margin-bottom: 30px; box-shadow: 0 3px 10px rgba(0,0,0,0.1);">
            <p style="margin: 0; text-align: center; font-size: 1.1rem;">
                <strong><?php echo htmlspecialchars($from_city); ?></strong> 
                <i class="fas fa-arrow-right" style="color: var(--secondary-color); margin: 0 15px;"></i> 
                <strong><?php echo htmlspecialchars($to_city); ?></strong> 
                on <strong><?php echo format_date($departure_date); ?></strong>
            </p>
        </div>

        <?php
        // Search for flights
        $flights = search_flights($from_city, $to_city, $departure_date);
        
        if (mysqli_num_rows($flights) > 0):
        ?>
            <div style="margin-top: 30px;">
                <?php while($flight = mysqli_fetch_assoc($flights)): ?>
                    <div class="flight-card fade-in">
                        <div class="flight-header">
                            <div class="flight-number">
                                <i class="fas fa-plane"></i> <?php echo $flight['flight_number']; ?>
                            </div>
                            <div>
                                <span class="badge badge-info"><?php echo $flight['plane_name']; ?></span>
                            </div>
                        </div>
                        
                        <div class="flight-route">
                            <div class="flight-location">
                                <div class="city"><?php echo $flight['departure_city']; ?></div>
                                <div class="time"><?php echo format_time($flight['departure_time']); ?></div>
                                <div class="date"><?php echo format_date($flight['departure_date']); ?></div>
                            </div>
                            
                            <div class="flight-arrow">
                                <i class="fas fa-arrow-right"></i>
                            </div>
                            
                            <div class="flight-location">
                                <div class="city"><?php echo $flight['arrival_city']; ?></div>
                                <div class="time"><?php echo format_time($flight['arrival_time']); ?></div>
                                <div class="date"><?php echo format_date($flight['arrival_date']); ?></div>
                            </div>
                        </div>
                        
                        <div class="flight-details">
                            <div class="detail-item">
                                <i class="fas fa-chair"></i>
                                <span><?php echo $flight['available_seats']; ?> seats available</span>
                            </div>
                            <div class="detail-item">
                                <i class="fas fa-plane"></i>
                                <span><?php echo $flight['plane_model']; ?></span>
                            </div>
                            <div class="detail-item">
                                <i class="fas fa-info-circle"></i>
                                <span><?php echo ucfirst($flight['status']); ?></span>
                            </div>
                        </div>
                        
                        <div class="card-footer">
                            <div class="price-tag">
                                <?php echo format_currency($flight['price']); ?>
                            </div>
                            <a href="book_flight.php?flight_id=<?php echo $flight['flight_id']; ?>" class="btn btn-primary">
                                <i class="fas fa-ticket-alt"></i> Book Now
                            </a>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <div class="alert alert-warning" style="text-align: center; padding: 40px;">
                <i class="fas fa-exclamation-triangle" style="font-size: 3rem; margin-bottom: 20px;"></i>
                <h3>No Flights Found</h3>
                <p>We couldn't find any flights matching your search criteria. Please try different cities or dates.</p>
                <a href="search_flights.php" class="btn btn-primary" style="margin-top: 20px;">
                    <i class="fas fa-search"></i> Search Again
                </a>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>
