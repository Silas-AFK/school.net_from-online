<?php
session_start();
$page_title = 'Home';
$base_url = '';
require_once 'includes/header.php';
?>

<nav class="navbar">
    <div class="container">
        <a href="index.php" class="navbar-brand">
            <i class="fas fa-plane"></i> Lorain Air Travel
        </a>
        <button class="navbar-toggle" aria-label="Toggle navigation">
            <i class="fas fa-bars"></i>
        </button>
        <ul class="navbar-menu">
            <li><a href="index.php"><i class="fas fa-home"></i> Home</a></li>
            <li><a href="user/search_flights.php"><i class="fas fa-search"></i> Search Flights</a></li>
            <?php if(isset($_SESSION['user_id'])): ?>
                <li><a href="user/my_bookings.php"><i class="fas fa-ticket-alt"></i> My Bookings</a></li>
                <li><a href="user/profile.php"><i class="fas fa-user"></i> Profile</a></li>
                <li><a href="auth/logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            <?php else: ?>
                <li><a href="auth/login.php"><i class="fas fa-sign-in-alt"></i> Login</a></li>
                <li><a href="auth/register.php"><i class="fas fa-user-plus"></i> Register</a></li>
            <?php endif; ?>
            <!-- Removed admin link from public navigation for security -->
        </ul>
    </div>
</nav>

<section class="hero">
    <div class="container">
        <div class="hero-content">
            <h1 class="slide-in-left">Welcome to Lorain Air Travel</h1>
            <p class="tagline slide-in-right">Your Journey Begins Here</p>
            <p class="fade-in">Experience world-class air travel with comfort, safety, and affordability. Book your next adventure with us today!</p>
            <div style="display: flex; gap: 20px; justify-content: center; margin-top: 30px;">
                <a href="user/search_flights.php" class="btn btn-primary">
                    <i class="fas fa-search"></i> Search Flights
                </a>
                <a href="#features" class="btn btn-secondary">
                    <i class="fas fa-info-circle"></i> Learn More
                </a>
            </div>
        </div>
    </div>
</section>

<section class="search-section">
    <div class="container">
        <h2 style="text-align: center; margin-bottom: 30px; font-size: 2rem; color: var(--dark-color);">
            Find Your Perfect Flight
        </h2>
        <form action="user/flight_results.php" method="GET" class="search-form" onsubmit="return validateSearchForm()">
            <div class="form-row">
                <div class="form-group">
                    <label for="from_city"><i class="fas fa-plane-departure"></i> From</label>
                    <input type="text" id="from_city" name="from_city" placeholder="Departure City" required>
                </div>
                <div class="form-group">
                    <label for="to_city"><i class="fas fa-plane-arrival"></i> To</label>
                    <input type="text" id="to_city" name="to_city" placeholder="Arrival City" required>
                </div>
                <div class="form-group">
                    <label for="departure_date"><i class="fas fa-calendar"></i> Departure Date</label>
                    <input type="date" id="departure_date" name="departure_date" min="<?php echo date('Y-m-d'); ?>" required>
                </div>
            </div>
            <div style="text-align: center;">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-search"></i> Search Flights
                </button>
            </div>
        </form>
    </div>
</section>

<section class="features" id="features">
    <div class="container">
        <h2>Why Choose Lorain Air Travel?</h2>
        <div class="features-grid">
            <div class="feature-box">
                <div class="feature-icon">
                    <i class="fas fa-shield-alt"></i>
                </div>
                <h3>Safe & Secure</h3>
                <p>Your safety is our top priority. We maintain the highest safety standards in the industry.</p>
            </div>
            <div class="feature-box">
                <div class="feature-icon">
                    <i class="fas fa-clock"></i>
                </div>
                <h3>On-Time Performance</h3>
                <p>We value your time. Our flights are known for punctuality and reliability.</p>
            </div>
            <div class="feature-box">
                <div class="feature-icon">
                    <i class="fas fa-tag"></i>
                </div>
                <h3>Best Prices</h3>
                <p>Competitive pricing without compromising on quality and comfort.</p>
            </div>
            <div class="feature-box">
                <div class="feature-icon">
                    <i class="fas fa-headset"></i>
                </div>
                <h3>24/7 Support</h3>
                <p>Our customer service team is always ready to assist you anytime, anywhere.</p>
            </div>
            <div class="feature-box">
                <div class="feature-icon">
                    <i class="fas fa-couch"></i>
                </div>
                <h3>Comfortable Travel</h3>
                <p>Spacious seating and modern amenities for a pleasant journey.</p>
            </div>
            <div class="feature-box">
                <div class="feature-icon">
                    <i class="fas fa-mobile-alt"></i>
                </div>
                <h3>Easy Booking</h3>
                <p>Book your flights quickly and easily through our user-friendly platform.</p>
            </div>
        </div>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>

<script src="assets/js/validation.js"></script>
