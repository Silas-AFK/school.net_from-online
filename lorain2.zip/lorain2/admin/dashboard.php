<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

if (!is_admin_logged_in()) {
    header('Location: ../auth/login.php?admin=1');
    exit();
}

$page_title = 'Admin Dashboard';
$base_url = '../';

// Get statistics
$total_flights = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM flights"))['count'];
$total_bookings = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM bookings"))['count'];
$total_users = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as count FROM users"))['count'];
$total_revenue = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(total_amount) as total FROM bookings WHERE payment_status = 'confirmed'"))['total'] ?? 0;

// Get recent bookings
$recent_bookings = mysqli_query($conn, "SELECT b.*, f.flight_number, f.departure_city, f.arrival_city 
                                        FROM bookings b 
                                        JOIN flights f ON b.flight_id = f.flight_id 
                                        ORDER BY b.booking_date DESC LIMIT 5");

require_once '../includes/header.php';
?>

<link rel="stylesheet" href="../assets/css/admin.css">

<div class="admin-wrapper">
    <aside class="admin-sidebar" id="adminSidebar">
        <div class="admin-sidebar-header">
            <h2><i class="fas fa-plane"></i> Lorain Admin</h2>
            <p style="margin: 5px 0 0 0; font-size: 0.9rem; opacity: 0.9;">Welcome, <?php echo $_SESSION['admin_username']; ?></p>
        </div>
        <nav class="admin-nav">
            <a href="dashboard.php" class="admin-nav-item active">
                <i class="fas fa-tachometer-alt"></i> Dashboard
            </a>
            <a href="manage_flights.php" class="admin-nav-item">
                <i class="fas fa-plane"></i> Manage Flights
            </a>
            <a href="manage_planes.php" class="admin-nav-item">
                <i class="fas fa-plane-departure"></i> Manage Planes
            </a>
            <a href="bookings.php" class="admin-nav-item">
                <i class="fas fa-ticket-alt"></i> Bookings
            </a>
            <a href="manage_users.php" class="admin-nav-item">
                <i class="fas fa-users"></i> Users
            </a>
            <a href="reports.php" class="admin-nav-item">
                <i class="fas fa-chart-bar"></i> Reports
            </a>
            <a href="../index.php" class="admin-nav-item">
                <i class="fas fa-home"></i> View Website
            </a>
            <a href="../auth/logout.php" class="admin-nav-item">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </nav>
    </aside>

    <main class="admin-content">
        <div class="admin-header">
            <h1><i class="fas fa-tachometer-alt"></i> Dashboard</h1>
            <div>
                <span style="color: #666;">
                    <i class="fas fa-calendar"></i> <?php echo date('l, d F Y'); ?>
                </span>
            </div>
        </div>

        <div class="stats-grid">
            <div class="stat-card primary">
                <div class="stat-icon">
                    <i class="fas fa-plane"></i>
                </div>
                <div class="stat-value"><?php echo $total_flights; ?></div>
                <div class="stat-label">Total Flights</div>
            </div>

            <div class="stat-card success">
                <div class="stat-icon">
                    <i class="fas fa-ticket-alt"></i>
                </div>
                <div class="stat-value"><?php echo $total_bookings; ?></div>
                <div class="stat-label">Total Bookings</div>
            </div>

            <div class="stat-card warning">
                <div class="stat-icon">
                    <i class="fas fa-users"></i>
                </div>
                <div class="stat-value"><?php echo $total_users; ?></div>
                <div class="stat-label">Registered Users</div>
            </div>

            <div class="stat-card danger">
                <div class="stat-icon">
                    <i class="fas fa-money-bill-wave"></i>
                </div>
                <div class="stat-value"><?php echo format_currency($total_revenue); ?></div>
                <div class="stat-label">Total Revenue</div>
            </div>
        </div>

        <div class="admin-section">
            <div class="admin-section-header">
                <h2><i class="fas fa-clock"></i> Recent Bookings</h2>
                <a href="bookings.php" class="btn btn-primary btn-sm">View All</a>
            </div>

            <?php if (mysqli_num_rows($recent_bookings) > 0): ?>
                <div style="overflow-x: auto;">
                    <table>
                        <thead>
                            <tr>
                                <th>Reference</th>
                                <th>Passenger</th>
                                <th>Flight</th>
                                <th>Route</th>
                                <th>Amount</th>
                                <th>Status</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($booking = mysqli_fetch_assoc($recent_bookings)): ?>
                                <tr>
                                    <td><strong><?php echo $booking['booking_reference']; ?></strong></td>
                                    <td><?php echo $booking['passenger_name']; ?></td>
                                    <td><?php echo $booking['flight_number']; ?></td>
                                    <td><?php echo $booking['departure_city'] . ' → ' . $booking['arrival_city']; ?></td>
                                    <td><?php echo format_currency($booking['total_amount']); ?></td>
                                    <td>
                                        <span class="badge <?php 
                                            echo $booking['payment_status'] == 'confirmed' ? 'badge-success' : 
                                                 ($booking['payment_status'] == 'pending' ? 'badge-warning' : 'badge-danger'); 
                                        ?>">
                                            <?php echo ucfirst($booking['payment_status']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo date('d M Y', strtotime($booking['booking_date'])); ?></td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p style="text-align: center; color: #666; padding: 40px;">No bookings yet.</p>
            <?php endif; ?>
        </div>

        <div class="admin-section">
            <div class="admin-section-header">
                <h2><i class="fas fa-info-circle"></i> Quick Actions</h2>
            </div>
            <div class="btn-group">
                <a href="manage_flights.php" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Add New Flight
                </a>
                <a href="manage_planes.php" class="btn btn-secondary">
                    <i class="fas fa-plane"></i> Add New Plane
                </a>
                <a href="bookings.php" class="btn btn-success">
                    <i class="fas fa-ticket-alt"></i> View All Bookings
                </a>
            </div>
        </div>
    </main>
</div>

<button class="sidebar-toggle" onclick="toggleSidebar()">
    <i class="fas fa-bars"></i>
</button>

<script>
function toggleSidebar() {
    document.getElementById('adminSidebar').classList.toggle('active');
}
</script>

<?php require_once '../includes/footer.php'; ?>
