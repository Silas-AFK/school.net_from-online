<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

if (!is_admin_logged_in()) {
    header('Location: ../auth/login.php?admin=1');
    exit();
}

$page_title = 'All Bookings';
$base_url = '../';

// Get all bookings
$bookings = mysqli_query($conn, "SELECT b.*, f.flight_number, f.departure_city, f.arrival_city, 
                                 f.departure_date, f.departure_time 
                                 FROM bookings b 
                                 JOIN flights f ON b.flight_id = f.flight_id 
                                 ORDER BY b.booking_date DESC");

require_once '../includes/header.php';
?>

<link rel="stylesheet" href="../assets/css/admin.css">

<div class="admin-wrapper">
    <aside class="admin-sidebar">
        <div class="admin-sidebar-header">
            <h2><i class="fas fa-plane"></i> Lorain Admin</h2>
            <p style="margin: 5px 0 0 0; font-size: 0.9rem; opacity: 0.9;">Welcome, <?php echo $_SESSION['admin_username']; ?></p>
        </div>
        <nav class="admin-nav">
            <a href="dashboard.php" class="admin-nav-item">
                <i class="fas fa-tachometer-alt"></i> Dashboard
            </a>
            <a href="manage_flights.php" class="admin-nav-item">
                <i class="fas fa-plane"></i> Manage Flights
            </a>
            <a href="manage_planes.php" class="admin-nav-item">
                <i class="fas fa-plane-departure"></i> Manage Planes
            </a>
            <a href="bookings.php" class="admin-nav-item active">
                <i class="fas fa-ticket-alt"></i> Bookings
            </a>
            <a href="manage_users.php" class="admin-nav-item">
                <i class="fas fa-users"></i> Users
            </a>
            <a href="reports.php" class="admin-nav-item">
                <i class="fas fa-chart-bar"></i> Reports
            </a>
            <a href="../index.php" class="admin-nav-item">
                <i class="fas fa-home"></i> View Website
            </a>
            <a href="../auth/logout.php" class="admin-nav-item">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </nav>
    </aside>

    <main class="admin-content">
        <div class="admin-header">
            <h1><i class="fas fa-ticket-alt"></i> All Bookings</h1>
        </div>

        <div class="admin-section">
            <div style="overflow-x: auto;">
                <table>
                    <thead>
                        <tr>
                            <th>Reference</th>
                            <th>Passenger</th>
                            <th>Contact</th>
                            <th>Flight</th>
                            <th>Route</th>
                            <th>Date</th>
                            <th>Passengers</th>
                            <th>Amount</th>
                            <th>Status</th>
                            <th>Booked On</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($booking = mysqli_fetch_assoc($bookings)): ?>
                            <tr>
                                <td><strong><?php echo $booking['booking_reference']; ?></strong></td>
                                <td><?php echo $booking['passenger_name']; ?></td>
                                <td>
                                    <?php echo $booking['passenger_email']; ?><br>
                                    <small><?php echo $booking['passenger_phone']; ?></small>
                                </td>
                                <td><?php echo $booking['flight_number']; ?></td>
                                <td><?php echo $booking['departure_city'] . ' → ' . $booking['arrival_city']; ?></td>
                                <td><?php echo format_date($booking['departure_date']) . '<br>' . format_time($booking['departure_time']); ?></td>
                                <td><?php echo $booking['num_passengers']; ?></td>
                                <td><?php echo format_currency($booking['total_amount']); ?></td>
                                <td>
                                    <span class="badge <?php 
                                        echo $booking['payment_status'] == 'confirmed' ? 'badge-success' : 
                                             ($booking['payment_status'] == 'pending' ? 'badge-warning' : 'badge-danger'); 
                                    ?>">
                                        <?php echo ucfirst($booking['payment_status']); ?>
                                    </span>
                                </td>
                                <td><?php echo date('d M Y, h:i A', strtotime($booking['booking_date'])); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</div>

<?php require_once '../includes/footer.php'; ?>
