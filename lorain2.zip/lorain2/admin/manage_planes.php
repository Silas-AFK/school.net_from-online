<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

if (!is_admin_logged_in()) {
    header('Location: ../auth/login.php?admin=1');
    exit();
}

$page_title = 'Manage Planes';
$base_url = '../';

// Handle plane operations
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_plane'])) {
        $plane_name = clean_input($_POST['plane_name']);
        $plane_model = clean_input($_POST['plane_model']);
        $capacity = (int)$_POST['capacity'];
        $status = clean_input($_POST['status']);
        
        $query = "INSERT INTO planes (plane_name, plane_model, capacity, status) 
                  VALUES ('$plane_name', '$plane_model', $capacity, '$status')";
        
        if (mysqli_query($conn, $query)) {
            $success = "Plane added successfully!";
        } else {
            $error = "Failed to add plane.";
        }
    } elseif (isset($_POST['delete_plane'])) {
        $plane_id = (int)$_POST['plane_id'];
        $query = "DELETE FROM planes WHERE plane_id = $plane_id";
        mysqli_query($conn, $query);
        $success = "Plane deleted successfully!";
    }
}

$planes = mysqli_query($conn, "SELECT * FROM planes ORDER BY plane_id DESC");

require_once '../includes/header.php';
?>

<link rel="stylesheet" href="../assets/css/admin.css">

<div class="admin-wrapper">
    <aside class="admin-sidebar">
        <div class="admin-sidebar-header">
            <h2><i class="fas fa-plane"></i> Lorain Admin</h2>
            <p style="margin: 5px 0 0 0; font-size: 0.9rem; opacity: 0.9;">Welcome, <?php echo $_SESSION['admin_username']; ?></p>
        </div>
        <nav class="admin-nav">
            <a href="dashboard.php" class="admin-nav-item">
                <i class="fas fa-tachometer-alt"></i> Dashboard
            </a>
            <a href="manage_flights.php" class="admin-nav-item">
                <i class="fas fa-plane"></i> Manage Flights
            </a>
            <a href="manage_planes.php" class="admin-nav-item active">
                <i class="fas fa-plane-departure"></i> Manage Planes
            </a>
            <a href="bookings.php" class="admin-nav-item">
                <i class="fas fa-ticket-alt"></i> Bookings
            </a>
            <a href="manage_users.php" class="admin-nav-item">
                <i class="fas fa-users"></i> Users
            </a>
            <a href="reports.php" class="admin-nav-item">
                <i class="fas fa-chart-bar"></i> Reports
            </a>
            <a href="../index.php" class="admin-nav-item">
                <i class="fas fa-home"></i> View Website
            </a>
            <a href="../auth/logout.php" class="admin-nav-item">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </nav>
    </aside>

    <main class="admin-content">
        <div class="admin-header">
            <h1><i class="fas fa-plane-departure"></i> Manage Planes</h1>
            <button class="btn btn-primary" onclick="openModal()">
                <i class="fas fa-plus"></i> Add New Plane
            </button>
        </div>

        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <div class="admin-section">
            <div class="cards-grid">
                <?php while($plane = mysqli_fetch_assoc($planes)): ?>
                    <div class="card">
                        <div class="card-header">
                            <h3><?php echo $plane['plane_name']; ?></h3>
                        </div>
                        <div class="card-body">
                            <p><strong><i class="fas fa-plane"></i> Model:</strong><br><?php echo $plane['plane_model']; ?></p>
                            <p><strong><i class="fas fa-chair"></i> Capacity:</strong><br><?php echo $plane['capacity']; ?> passengers</p>
                            <p><strong><i class="fas fa-info-circle"></i> Status:</strong><br>
                                <span class="badge <?php 
                                    echo $plane['status'] == 'active' ? 'badge-success' : 
                                         ($plane['status'] == 'maintenance' ? 'badge-warning' : 'badge-danger'); 
                                ?>">
                                    <?php echo ucfirst($plane['status']); ?>
                                </span>
                            </p>
                        </div>
                        <div class="card-footer">
                            <form method="POST" onsubmit="return confirm('Are you sure you want to delete this plane?')">
                                <input type="hidden" name="plane_id" value="<?php echo $plane['plane_id']; ?>">
                                <button type="submit" name="delete_plane" class="btn btn-danger btn-sm">
                                    <i class="fas fa-trash"></i> Delete
                                </button>
                            </form>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>
    </main>
</div>

<!-- Add Plane Modal -->
<div id="planeModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fas fa-plane"></i> Add New Plane</h3>
            <button class="modal-close" onclick="closeModal()">&times;</button>
        </div>
        <form method="POST">
            <div class="form-group">
                <label for="plane_name">Plane Name *</label>
                <input type="text" id="plane_name" name="plane_name" required placeholder="e.g., Lorain Express 5">
            </div>
            <div class="form-group">
                <label for="plane_model">Plane Model *</label>
                <input type="text" id="plane_model" name="plane_model" required placeholder="e.g., Boeing 737">
            </div>
            <div class="form-group">
                <label for="capacity">Capacity *</label>
                <input type="number" id="capacity" name="capacity" required min="1" placeholder="Number of passengers">
            </div>
            <div class="form-group">
                <label for="status">Status *</label>
                <select id="status" name="status" required>
                    <option value="active">Active</option>
                    <option value="maintenance">Maintenance</option>
                    <option value="inactive">Inactive</option>
                </select>
            </div>
            <button type="submit" name="add_plane" class="btn btn-primary" style="width: 100%; margin-top: 20px;">
                <i class="fas fa-save"></i> Add Plane
            </button>
        </form>
    </div>
</div>

<script>
function openModal() {
    document.getElementById('planeModal').classList.add('active');
}

function closeModal() {
    document.getElementById('planeModal').classList.remove('active');
}

window.onclick = function(event) {
    const modal = document.getElementById('planeModal');
    if (event.target == modal) {
        closeModal();
    }
}
</script>

<?php require_once '../includes/footer.php'; ?>
