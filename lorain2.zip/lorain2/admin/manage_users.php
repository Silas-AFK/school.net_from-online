<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

if (!is_admin_logged_in()) {
    header('Location: ../auth/login.php?admin=1');
    exit();
}

$page_title = 'Manage Users';
$base_url = '../';

$users = mysqli_query($conn, "SELECT * FROM users ORDER BY created_at DESC");

require_once '../includes/header.php';
?>

<link rel="stylesheet" href="../assets/css/admin.css">

<div class="admin-wrapper">
    <aside class="admin-sidebar">
        <div class="admin-sidebar-header">
            <h2><i class="fas fa-plane"></i> Lorain Admin</h2>
            <p style="margin: 5px 0 0 0; font-size: 0.9rem; opacity: 0.9;">Welcome, <?php echo $_SESSION['admin_username']; ?></p>
        </div>
        <nav class="admin-nav">
            <a href="dashboard.php" class="admin-nav-item">
                <i class="fas fa-tachometer-alt"></i> Dashboard
            </a>
            <a href="manage_flights.php" class="admin-nav-item">
                <i class="fas fa-plane"></i> Manage Flights
            </a>
            <a href="manage_planes.php" class="admin-nav-item">
                <i class="fas fa-plane-departure"></i> Manage Planes
            </a>
            <a href="bookings.php" class="admin-nav-item">
                <i class="fas fa-ticket-alt"></i> Bookings
            </a>
            <a href="manage_users.php" class="admin-nav-item active">
                <i class="fas fa-users"></i> Users
            </a>
            <a href="reports.php" class="admin-nav-item">
                <i class="fas fa-chart-bar"></i> Reports
            </a>
            <a href="../index.php" class="admin-nav-item">
                <i class="fas fa-home"></i> View Website
            </a>
            <a href="../auth/logout.php" class="admin-nav-item">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </nav>
    </aside>

    <main class="admin-content">
        <div class="admin-header">
            <h1><i class="fas fa-users"></i> Registered Users</h1>
        </div>

        <div class="admin-section">
            <div style="overflow-x: auto;">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Full Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Registered On</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($user = mysqli_fetch_assoc($users)): ?>
                            <tr>
                                <td><?php echo $user['user_id']; ?></td>
                                <td><?php echo $user['full_name']; ?></td>
                                <td><?php echo $user['email']; ?></td>
                                <td><?php echo $user['phone']; ?></td>
                                <td><?php echo date('d M Y, h:i A', strtotime($user['created_at'])); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</div>

<?php require_once '../includes/footer.php'; ?>
