<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

if (!is_admin_logged_in()) {
    header('Location: ../auth/login.php?admin=1');
    exit();
}

$page_title = 'Manage Flights';
$base_url = '../';

// Handle flight operations
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_flight'])) {
        $flight_number = clean_input($_POST['flight_number']);
        $plane_id = (int)$_POST['plane_id'];
        $departure_city = clean_input($_POST['departure_city']);
        $arrival_city = clean_input($_POST['arrival_city']);
        $departure_date = clean_input($_POST['departure_date']);
        $departure_time = clean_input($_POST['departure_time']);
        $arrival_date = clean_input($_POST['arrival_date']);
        $arrival_time = clean_input($_POST['arrival_time']);
        $price = (float)$_POST['price'];
        $available_seats = (int)$_POST['available_seats'];
        
        $query = "INSERT INTO flights (flight_number, plane_id, departure_city, arrival_city, departure_date, 
                  departure_time, arrival_date, arrival_time, price, available_seats) 
                  VALUES ('$flight_number', $plane_id, '$departure_city', '$arrival_city', '$departure_date', 
                  '$departure_time', '$arrival_date', '$arrival_time', $price, $available_seats)";
        
        if (mysqli_query($conn, $query)) {
            $success = "Flight added successfully!";
        } else {
            $error = "Failed to add flight: " . mysqli_error($conn);
        }
    } elseif (isset($_POST['delete_flight'])) {
        $flight_id = (int)$_POST['flight_id'];
        $query = "DELETE FROM flights WHERE flight_id = $flight_id";
        mysqli_query($conn, $query);
        $success = "Flight deleted successfully!";
    }
}

// Get all flights
$flights = mysqli_query($conn, "SELECT f.*, p.plane_name, p.plane_model 
                                FROM flights f 
                                LEFT JOIN planes p ON f.plane_id = p.plane_id 
                                ORDER BY f.departure_date DESC, f.departure_time DESC");

// Get all planes for dropdown
$planes = mysqli_query($conn, "SELECT * FROM planes WHERE status = 'active'");

require_once '../includes/header.php';
?>

<link rel="stylesheet" href="../assets/css/admin.css">

<div class="admin-wrapper">
    <aside class="admin-sidebar">
        <div class="admin-sidebar-header">
            <h2><i class="fas fa-plane"></i> Lorain Admin</h2>
            <p style="margin: 5px 0 0 0; font-size: 0.9rem; opacity: 0.9;">Welcome, <?php echo $_SESSION['admin_username']; ?></p>
        </div>
        <nav class="admin-nav">
            <a href="dashboard.php" class="admin-nav-item">
                <i class="fas fa-tachometer-alt"></i> Dashboard
            </a>
            <a href="manage_flights.php" class="admin-nav-item active">
                <i class="fas fa-plane"></i> Manage Flights
            </a>
            <a href="manage_planes.php" class="admin-nav-item">
                <i class="fas fa-plane-departure"></i> Manage Planes
            </a>
            <a href="bookings.php" class="admin-nav-item">
                <i class="fas fa-ticket-alt"></i> Bookings
            </a>
            <a href="manage_users.php" class="admin-nav-item">
                <i class="fas fa-users"></i> Users
            </a>
            <a href="reports.php" class="admin-nav-item">
                <i class="fas fa-chart-bar"></i> Reports
            </a>
            <a href="../index.php" class="admin-nav-item">
                <i class="fas fa-home"></i> View Website
            </a>
            <a href="../auth/logout.php" class="admin-nav-item">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </nav>
    </aside>

    <main class="admin-content">
        <div class="admin-header">
            <h1><i class="fas fa-plane"></i> Manage Flights</h1>
            <button class="btn btn-primary" onclick="openModal()">
                <i class="fas fa-plus"></i> Add New Flight
            </button>
        </div>

        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <div class="admin-section">
            <div style="overflow-x: auto;">
                <table>
                    <thead>
                        <tr>
                            <th>Flight No.</th>
                            <th>Aircraft</th>
                            <th>Route</th>
                            <th>Departure</th>
                            <th>Arrival</th>
                            <th>Price</th>
                            <th>Seats</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($flight = mysqli_fetch_assoc($flights)): ?>
                            <tr>
                                <td><strong><?php echo $flight['flight_number']; ?></strong></td>
                                <td><?php echo $flight['plane_name']; ?><br><small><?php echo $flight['plane_model']; ?></small></td>
                                <td><?php echo $flight['departure_city'] . ' → ' . $flight['arrival_city']; ?></td>
                                <td><?php echo format_date($flight['departure_date']) . '<br>' . format_time($flight['departure_time']); ?></td>
                                <td><?php echo format_date($flight['arrival_date']) . '<br>' . format_time($flight['arrival_time']); ?></td>
                                <td><?php echo format_currency($flight['price']); ?></td>
                                <td><?php echo $flight['available_seats']; ?></td>
                                <td>
                                    <span class="badge <?php 
                                        echo $flight['status'] == 'scheduled' ? 'badge-success' : 
                                             ($flight['status'] == 'boarding' ? 'badge-warning' : 'badge-info'); 
                                    ?>">
                                        <?php echo ucfirst($flight['status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="action-buttons">
                                        <form method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this flight?')">
                                            <input type="hidden" name="flight_id" value="<?php echo $flight['flight_id']; ?>">
                                            <button type="submit" name="delete_flight" class="btn btn-delete btn-sm">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</div>

<!-- Add Flight Modal -->
<div id="flightModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3><i class="fas fa-plane"></i> Add New Flight</h3>
            <button class="modal-close" onclick="closeModal()">&times;</button>
        </div>
        <form method="POST">
            <div class="form-row">
                <div class="form-group">
                    <label for="flight_number">Flight Number *</label>
                    <input type="text" id="flight_number" name="flight_number" required placeholder="e.g., LR109">
                </div>
                <div class="form-group">
                    <label for="plane_id">Aircraft *</label>
                    <select id="plane_id" name="plane_id" required>
                        <option value="">Select Aircraft</option>
                        <?php mysqli_data_seek($planes, 0); ?>
                        <?php while($plane = mysqli_fetch_assoc($planes)): ?>
                            <option value="<?php echo $plane['plane_id']; ?>">
                                <?php echo $plane['plane_name'] . ' (' . $plane['plane_model'] . ')'; ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label for="departure_city">Departure City *</label>
                    <input type="text" id="departure_city" name="departure_city" required>
                </div>
                <div class="form-group">
                    <label for="arrival_city">Arrival City *</label>
                    <input type="text" id="arrival_city" name="arrival_city" required>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label for="departure_date">Departure Date *</label>
                    <input type="date" id="departure_date" name="departure_date" required min="<?php echo date('Y-m-d'); ?>">
                </div>
                <div class="form-group">
                    <label for="departure_time">Departure Time *</label>
                    <input type="time" id="departure_time" name="departure_time" required>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label for="arrival_date">Arrival Date *</label>
                    <input type="date" id="arrival_date" name="arrival_date" required min="<?php echo date('Y-m-d'); ?>">
                </div>
                <div class="form-group">
                    <label for="arrival_time">Arrival Time *</label>
                    <input type="time" id="arrival_time" name="arrival_time" required>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <!-- Updated price label to show FCFA instead of KSh -->
                    <label for="price">Price (FCFA) *</label>
                    <input type="number" id="price" name="price" step="0.01" required min="0">
                </div>
                <div class="form-group">
                    <label for="available_seats">Available Seats *</label>
                    <input type="number" id="available_seats" name="available_seats" required min="1">
                </div>
            </div>
            <button type="submit" name="add_flight" class="btn btn-primary" style="width: 100%; margin-top: 20px;">
                <i class="fas fa-save"></i> Add Flight
            </button>
        </form>
    </div>
</div>

<script>
function openModal() {
    document.getElementById('flightModal').classList.add('active');
}

function closeModal() {
    document.getElementById('flightModal').classList.remove('active');
}

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('flightModal');
    if (event.target == modal) {
        closeModal();
    }
}
</script>

<?php require_once '../includes/footer.php'; ?>
