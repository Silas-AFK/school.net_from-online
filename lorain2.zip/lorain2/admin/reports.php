<?php
session_start();
require_once '../includes/db.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

if (!is_admin_logged_in()) {
    header('Location: ../auth/login.php?admin=1');
    exit();
}

$page_title = 'Reports';
$base_url = '../';

// Get monthly revenue
$monthly_revenue = mysqli_query($conn, "SELECT DATE_FORMAT(booking_date, '%Y-%m') as month, 
                                        SUM(total_amount) as revenue 
                                        FROM bookings 
                                        WHERE payment_status = 'confirmed' 
                                        GROUP BY DATE_FORMAT(booking_date, '%Y-%m') 
                                        ORDER BY month DESC 
                                        LIMIT 6");

// Get popular routes
$popular_routes = mysqli_query($conn, "SELECT CONCAT(f.departure_city, ' → ', f.arrival_city) as route, 
                                       COUNT(b.booking_id) as bookings, 
                                       SUM(b.total_amount) as revenue 
                                       FROM bookings b 
                                       JOIN flights f ON b.flight_id = f.flight_id 
                                       WHERE b.payment_status = 'confirmed' 
                                       GROUP BY f.departure_city, f.arrival_city 
                                       ORDER BY bookings DESC 
                                       LIMIT 5");

require_once '../includes/header.php';
?>

<link rel="stylesheet" href="../assets/css/admin.css">

<div class="admin-wrapper">
    <aside class="admin-sidebar">
        <div class="admin-sidebar-header">
            <h2><i class="fas fa-plane"></i> Lorain Admin</h2>
            <p style="margin: 5px 0 0 0; font-size: 0.9rem; opacity: 0.9;">Welcome, <?php echo $_SESSION['admin_username']; ?></p>
        </div>
        <nav class="admin-nav">
            <a href="dashboard.php" class="admin-nav-item">
                <i class="fas fa-tachometer-alt"></i> Dashboard
            </a>
            <a href="manage_flights.php" class="admin-nav-item">
                <i class="fas fa-plane"></i> Manage Flights
            </a>
            <a href="manage_planes.php" class="admin-nav-item">
                <i class="fas fa-plane-departure"></i> Manage Planes
            </a>
            <a href="bookings.php" class="admin-nav-item">
                <i class="fas fa-ticket-alt"></i> Bookings
            </a>
            <a href="manage_users.php" class="admin-nav-item">
                <i class="fas fa-users"></i> Users
            </a>
            <a href="reports.php" class="admin-nav-item active">
                <i class="fas fa-chart-bar"></i> Reports
            </a>
            <a href="../index.php" class="admin-nav-item">
                <i class="fas fa-home"></i> View Website
            </a>
            <a href="../auth/logout.php" class="admin-nav-item">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </nav>
    </aside>

    <main class="admin-content">
        <div class="admin-header">
            <h1><i class="fas fa-chart-bar"></i> Reports & Analytics</h1>
        </div>

        <div class="admin-section">
            <div class="admin-section-header">
                <h2><i class="fas fa-money-bill-wave"></i> Monthly Revenue</h2>
            </div>
            <div style="overflow-x: auto;">
                <table>
                    <thead>
                        <tr>
                            <th>Month</th>
                            <th>Revenue</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($month = mysqli_fetch_assoc($monthly_revenue)): ?>
                            <tr>
                                <td><?php echo date('F Y', strtotime($month['month'] . '-01')); ?></td>
                                <td><strong><?php echo format_currency($month['revenue']); ?></strong></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="admin-section">
            <div class="admin-section-header">
                <h2><i class="fas fa-fire"></i> Popular Routes</h2>
            </div>
            <div style="overflow-x: auto;">
                <table>
                    <thead>
                        <tr>
                            <th>Route</th>
                            <th>Total Bookings</th>
                            <th>Total Revenue</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($route = mysqli_fetch_assoc($popular_routes)): ?>
                            <tr>
                                <td><strong><?php echo $route['route']; ?></strong></td>
                                <td><?php echo $route['bookings']; ?></td>
                                <td><strong><?php echo format_currency($route['revenue']); ?></strong></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</div>

<?php require_once '../includes/footer.php'; ?>
