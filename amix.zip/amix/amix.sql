-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 16, 2025 at 11:13 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `amix`
--

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `id` int(11) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `caption` varchar(255) DEFAULT NULL,
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`id`, `filename`, `caption`, `uploaded_at`) VALUES
(1, '68b806e5eb23f.jpg', 'SILAS', '2025-09-03 09:14:13'),
(2, '68b8186cc2573.jpg', 'CEDRCUIT', '2025-09-03 10:29:00'),
(3, 'img_68b81a05c4fc17.25081943.jpg', 'CEDRCUIT', '2025-09-03 10:35:49'),
(4, '68b81b5411732.jpg', 'HI', '2025-09-03 10:41:24'),
(5, '68b81de9088c1.jpg', 'CEDRCUIT', '2025-09-03 10:52:25'),
(6, '6933e535b6766.jpg', 'SUN RICE', '2025-12-06 08:11:33'),
(7, '6941d6a94c446.jpeg', 'INCUBATOR MANCHIN', '2025-12-16 22:01:13'),
(8, '6941d6e0629bd.jpeg', 'HEALTH CARE', '2025-12-16 22:02:08'),
(9, '6941d709ecbdb.jpeg', '3D PRINTER', '2025-12-16 22:02:49'),
(10, '6941d734352b1.jpeg', 'WEARABLE SENSOR', '2025-12-16 22:03:32');

-- --------------------------------------------------------

--
-- Table structure for table `updates`
--

CREATE TABLE `updates` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `posted_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `updates`
--

INSERT INTO `updates` (`id`, `title`, `content`, `posted_at`) VALUES
(1, 'CALLL ', 'CGVBDBCHWCWKLFJWEHDLWEI', '2025-09-03 09:16:31'),
(2, 'TODAYS CLASS', 'VDJEFVHBWEJF;WEVHFKWEJL;FHBWEKFJWE;FVWE./JF;LKLFBLWEKFHHWEFHLWEFGKELFJLWEFVWELH;FBWEGFB', '2025-09-04 10:51:12'),
(3, 'OPEN DOOR DAY', 'WE WILL BE AT THE SCHOOL CAMPUS FOR THE OCCATION ', '2025-12-16 22:04:40'),
(4, 'FOOT BALL MATCH ', 'We will be having a match to play this week end ', '2025-12-16 22:05:34'),
(5, 'WEDDING INVITATION', 'All interns are invited to the teachers wedding', '2025-12-16 22:06:28');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` enum('admin') NOT NULL DEFAULT 'admin',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password_hash`, `role`, `created_at`) VALUES
(2, 'SILAS', 'SILAS123', 'admin', '2025-09-03 08:14:12');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `updates`
--
ALTER TABLE `updates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `updates`
--
ALTER TABLE `updates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
