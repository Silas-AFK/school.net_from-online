<?php
session_start();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $username = $_POST['name'] ?? '';
  $password = $_POST['password'] ?? '';

  // Connect to the database
  $conn = new mysqli('localhost', 'root', '', 'amix');
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  // Prepare statement to check admin credentials
  $stmt = $conn->prepare("SELECT password_hash FROM users WHERE username = ? AND role = 'admin'");
  if (!$stmt) {
    die("Prepare failed: " . $conn->error);
  }

  $stmt->bind_param("s", $username);
  $stmt->execute();
  $result = $stmt->get_result();

  if ($result && $result->num_rows === 1) {
    $row = $result->fetch_assoc();
    if (password_verify($password, $row['password_hash'])) {
      $_SESSION['admin'] = $username;
      header('Location: admin_panel.php');
      exit;
    } else {
      $error = 'Invalid password';
    }
  } else {
    $error = 'Admin not found';
  }

  $stmt->close();
  $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Admin Login - SMCC</title>
  <style>
    /* Your existing CSS styles here */
  </style>
</head>
<body>

  <header>
    <img src="joys.jpg" alt="SMCC Logo" class="logo" />
  </header>

  <h2>Admin Login</h2>

  <?php if ($error): ?>
    <p class="error"><?= htmlspecialchars($error) ?></p>
  <?php endif; ?>

  <form method="POST">
    <input type="text" name="name" placeholder="Name" required />
    <input type="password" name="password" placeholder="Password" required />
    <button type="submit">Log In</button>
  </form>

  <div class="home-link">
    <a href="index.html">← Back to Home</a>
  </div>

  <footer>
    <p>&copy; <?= date('Y') ?> SMCC Santa. All Rights Reserved.</p>
    <p>Powered by <span style="color: goldenrod;">OSIRIS</span> Tech</p>
  </footer>

</body>
</html>
