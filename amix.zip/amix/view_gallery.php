<?php
include_once 'db.php';

// Fetch all gallery items
$gallery_items = [];
$result = $conn->query("SELECT * FROM gallery ORDER BY uploaded_at DESC");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $gallery_items[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Gallery - AMXIS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: #f5f5f5;
            color: #333;
        }
        
        .header {
            background-color: #1a2a6c;
            color: white;
            padding: 15px 0;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
        }
        
        .header-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .logo {
            display: flex;
            align-items: center;
        }
        
        .logo img {
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
        }
        
        .logo a {
            color: white;
            text-decoration: none;
            font-size: 24px;
            font-weight: 600;
        }
        
        .nav-links {
            display: flex;
            list-style: none;
        }
        
        .nav-links li {
            margin-left: 20px;
        }
        
        .nav-links a {
            color: white;
            text-decoration: none;
            font-weight: 500;
            transition: opacity 0.3s;
        }
        
        .nav-links a:hover {
            opacity: 0.8;
        }
        
        .nav-links a.active {
            border-bottom: 2px solid white;
            padding-bottom: 2px;
        }
        
        .hamburger {
            display: none;
            font-size: 24px;
            cursor: pointer;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 40px 20px;
        }
        
        .page-title {
            text-align: center;
            margin-bottom: 40px;
        }
        
        .page-title h1 {
            font-size: 36px;
            color: #1a2a6c;
            margin-bottom: 10px;
        }
        
        .page-title p {
            color: #666;
            max-width: 700px;
            margin: 0 auto;
        }
        
        .gallery-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 25px;
        }
        
        .gallery-item {
            background: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            overflow: hidden;
            transition: transform 0.3s, box-shadow 0.3s;
        }
        
        .gallery-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        }
        
        .gallery-item img {
            width: 100%;
            height: 250px;
            object-fit: cover;
            transition: transform 0.5s;
        }
        
        .gallery-item:hover img {
            transform: scale(1.05);
        }
        
        .gallery-item-content {
            padding: 20px;
        }
        
        .gallery-item-title {
            font-size: 20px;
            margin-bottom: 10px;
            color: #333;
        }
        
        .gallery-item-date {
            font-size: 14px;
            color: #777;
            display: flex;
            align-items: center;
        }
        
        .gallery-item-date i {
            margin-right: 5px;
        }
        
        .empty-gallery {
            text-align: center;
            padding: 60px 20px;
            color: #777;
        }
        
        .empty-gallery i {
            font-size: 64px;
            margin-bottom: 20px;
            color: #ddd;
        }
        
        .empty-gallery h3 {
            font-size: 24px;
            margin-bottom: 10px;
            color: #555;
        }
        
        .back-to-home {
            text-align: center;
            margin-top: 40px;
        }
        
        .back-to-home a {
            display: inline-block;
            padding: 10px 20px;
            background-color: #1a2a6c;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background 0.3s;
        }
        
        .back-to-home a:hover {
            background-color: #0d1a4a;
        }
        
        .back-to-home a i {
            margin-right: 5px;
        }
        
        .footer {
            background-color: #1a2a6c;
            color: white;
            padding: 30px 0;
            margin-top: 60px;
        }
        
        .footer-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            text-align: center;
        }
        
        .footer p {
            margin-bottom: 10px;
        }
        
        .social-icons {
            margin-top: 15px;
        }
        
        .social-icons a {
            color: white;
            font-size: 20px;
            margin: 0 10px;
            transition: opacity 0.3s;
        }
        
        .social-icons a:hover {
            opacity: 0.8;
        }
        
        /* Sidebar for mobile */
        .sidebar {
            height: 100%;
            width: 0;
            position: fixed;
            z-index: 1000;
            top: 0;
            left: 0;
            background-color: #1a2a6c;
            overflow-x: hidden;
            transition: 0.5s;
            padding-top: 60px;
        }
        
        .sidebar a {
            padding: 10px 15px;
            text-decoration: none;
            font-size: 18px;
            color: white;
            display: block;
            transition: 0.3s;
        }
        
        .sidebar a:hover {
            background-color: rgba(255, 255, 255, 0.1);
        }
        
        .sidebar .closebtn {
            position: absolute;
            top: 0;
            right: 25px;
            font-size: 36px;
            margin-left: 50px;
        }
        
        @media (max-width: 768px) {
            .nav-links {
                display: none;
            }
            
            .hamburger {
                display: block;
            }
            
            .gallery-grid {
                grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
                gap: 20px;
            }
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="header-container">
            <div class="logo">
                <img src="joys.jpg" alt="AMXIS">
                <a href="index.html">AMXIS</a>
            </div>
            <nav>
                <ul class="nav-links">
                    <li><a href="index.html">Home</a></li>
                    <li><a href="index.html#aboutus">About Us</a></li>
                    <li><a href="services.html">Services</a></li>
                    <li><a href="projects.html">Projects</a></li>
                    <li><a href="basics.html">Basics</a></li>
                    <li><a href="view_gallery.php" class="active">Gallery</a></li>
                    <li><a href="view_updates.php">Updates</a></li>
                    <li><a href="contact.html">Contact</a></li>
                    <li><a href="login.php">Admin</a></li>
                </ul>
                <div class="hamburger" onclick="toggleSidebar()">☰</div>
            </nav>
        </div>
    </header>
    
    <!-- Sidebar for mobile -->
    <div id="sidebar" class="sidebar">
        <a href="javascript:void(0)" class="closebtn" onclick="closeSidebar()">×</a>
        <a href="index.html">Home</a>
        <a href="index.html#aboutus">About Us</a>
        <a href="services.html">Services</a>
        <a href="projects.html">Projects</a>
        <a href="basics.html">Basics</a>
        <a href="view_gallery.php" class="active">Gallery</a>
        <a href="view_updates.php">Updates</a>
        <a href="contact.html">Contact</a>
        <a href="login.php">Admin</a>
    </div>
    
    <div class="container">
        <div class="page-title">
            <h1>Our Gallery</h1>
            <p>Explore our collection of images showcasing our work, events, and achievements.</p>
        </div>
        
        <?php if (empty($gallery_items)): ?>
            <div class="empty-gallery">
                <i class="fas fa-images"></i>
                <h3>No Images in Gallery</h3>
                <p>There are no images to display at the moment. Please check back later.</p>
            </div>
        <?php else: ?>
            <div class="gallery-grid">
                <?php foreach ($gallery_items as $item): ?>
                    <div class="gallery-item">
                        <img src="uploads/gallery/<?php echo $item['filename']; ?>" alt="<?php echo $item['caption']; ?>">
                        <div class="gallery-item-content">
                            <h3 class="gallery-item-title"><?php echo $item['caption']; ?></h3>
                            <p class="gallery-item-date">
                                <i class="fas fa-calendar-alt"></i> 
                                <?php echo date('F d, Y', strtotime($item['uploaded_at'])); ?>
                            </p>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        
        <div class="back-to-home">
            <a href="index.html">
                <i class="fas fa-arrow-left"></i> Back to Home
            </a>
        </div>
    </div>
    
    <footer class="footer">
        <div class="footer-container">
            <p>© 2025 AMXIS. All Rights Reserved.</p>
            <p>Powered By <span style="color: goldenrod; opacity: 80%;">OSIRIS</span> Tech</p>
            <div class="social-icons">
                <a href="https://wa.me/237676763842" target="_blank" title="Chat with us on WhatsApp">
                    <i class="fab fa-whatsapp"></i>
                </a>
            </div>
        </div>
    </footer>
    
    <script>
        function toggleSidebar() {
            document.getElementById("sidebar").style.width = "250px";
        }
        
        function closeSidebar() {
            document.getElementById("sidebar").style.width = "0";
        }
    </script>
</body>
</html>
