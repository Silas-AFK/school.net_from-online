<?php
session_start();
include_once 'db.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

$message = '';
$message_type = '';

// Handle form submission for adding new update
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_update'])) {
    $title = $_POST['title'];
    $content = $_POST['content'];
    
    // Insert into database
    $stmt = $conn->prepare("INSERT INTO updates (title, content) VALUES (?, ?)");
    $stmt->bind_param("ss", $title, $content);
    
    if ($stmt->execute()) {
        $message = "Update posted successfully!";
        $message_type = "success";
    } else {
        $message = "Error: " . $stmt->error;
        $message_type = "error";
    }
    
    $stmt->close();
}

// Handle delete request
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $id = $_GET['delete'];
    
    // Delete from database
    $stmt = $conn->prepare("DELETE FROM updates WHERE id = ?");
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        $message = "Update deleted successfully!";
        $message_type = "success";
    } else {
        $message = "Error deleting update: " . $stmt->error;
        $message_type = "error";
    }
    
    $stmt->close();
}

// Fetch all updates
$updates = [];
$result = $conn->query("SELECT * FROM updates ORDER BY posted_at DESC");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $updates[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Updates - AMXIS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: #f5f5f5;
            color: #333;
        }
        
        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }
        
        .sidebar {
            width: 250px;
            background-color: #1a2a6c;
            color: white;
            padding: 20px 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            transition: all 0.3s;
        }
        
        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            margin-bottom: 20px;
        }
        
        .sidebar-header h2 {
            font-size: 24px;
            margin-bottom: 5px;
        }
        
        .sidebar-header p {
            font-size: 14px;
            opacity: 0.8;
        }
        
        .sidebar-menu {
            list-style: none;
        }
        
        .sidebar-menu li {
            margin-bottom: 5px;
        }
        
        .sidebar-menu a {
            display: block;
            padding: 12px 20px;
            color: white;
            text-decoration: none;
            transition: background 0.3s;
        }
        
        .sidebar-menu a:hover, .sidebar-menu a.active {
            background-color: rgba(255, 255, 255, 0.1);
        }
        
        .sidebar-menu i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
            flex: 1;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid #ddd;
        }
        
        .header h1 {
            font-size: 28px;
            color: #1a2a6c;
        }
        
        .back-btn {
            background-color: #1a2a6c;
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            transition: background 0.3s;
        }
        
        .back-btn:hover {
            background-color: #0d1a4a;
        }
        
        .back-btn i {
            margin-right: 5px;
        }
        
        .message {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        
        .message.success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .message.error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            padding: 20px;
            margin-bottom: 30px;
        }
        
        .card h2 {
            margin-bottom: 20px;
            color: #1a2a6c;
            font-size: 22px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
        }
        
        .form-group input[type="text"],
        .form-group textarea {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            transition: border-color 0.3s;
        }
        
        .form-group textarea {
            min-height: 150px;
            resize: vertical;
        }
        
        .form-group input[type="text"]:focus,
        .form-group textarea:focus {
            border-color: #1a2a6c;
            outline: none;
        }
        
        .btn {
            background-color: #1a2a6c;
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 500;
            transition: background 0.3s;
        }
        
        .btn:hover {
            background-color: #0d1a4a;
        }
        
        .updates-list {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }
        
        .update-item {
            background: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            overflow: hidden;
            transition: transform 0.3s;
        }
        
        .update-item:hover {
            transform: translateY(-5px);
        }
        
        .update-item-header {
            padding: 15px 20px;
            background-color: #f8f9fa;
            border-bottom: 1px solid #eee;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .update-item-title {
            font-size: 18px;
            font-weight: 600;
            color: #333;
        }
        
        .update-item-date {
            font-size: 14px;
            color: #777;
        }
        
        .update-item-content {
            padding: 20px;
            line-height: 1.6;
        }
        
        .update-item-actions {
            padding: 0 20px 20px;
            display: flex;
            justify-content: flex-end;
        }
        
        .btn-delete {
            background-color: #e74c3c;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            transition: background 0.3s;
        }
        
        .btn-delete:hover {
            background-color: #c0392b;
        }
        
        .btn-delete i {
            margin-right: 5px;
        }
        
        .empty-updates {
            text-align: center;
            padding: 40px;
            color: #777;
        }
        
        .empty-updates i {
            font-size: 48px;
            margin-bottom: 15px;
            color: #ddd;
        }
        
        .mobile-menu-btn {
            display: none;
            position: fixed;
            top: 20px;
            left: 20px;
            z-index: 1000;
            background-color: #1a2a6c;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 10px;
            cursor: pointer;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                z-index: 999;
            }
            
            .sidebar.active {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .mobile-menu-btn {
                display: block;
            }
        }
    </style>
</head>
<body>
    <button class="mobile-menu-btn" id="mobileMenuBtn">
        <i class="fas fa-bars"></i>
    </button>
    
    <div class="dashboard-container">
        <div class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <h2>AMXIS</h2>
                <p>Admin Panel</p>
            </div>
            
            <ul class="sidebar-menu">
                <li>
                    <a href="admin_dashboard.php">
                        <i class="fas fa-tachometer-alt"></i> Dashboard
                    </a>
                </li>
                <li>
                    <a href="manage_gallery.php">
                        <i class="fas fa-images"></i> Manage Gallery
                    </a>
                </li>
                <li>
                    <a href="manage_updates.php" class="active">
                        <i class="fas fa-newspaper"></i> Manage Updates
                    </a>
                </li>
                <li>
                    <a href="view_gallery.php" target="_blank">
                        <i class="fas fa-eye"></i> View Gallery
                    </a>
                </li>
                <li>
                    <a href="view_updates.php" target="_blank">
                        <i class="fas fa-eye"></i> View Updates
                    </a>
                </li>
                <li>
                    <a href="index.html" target="_blank">
                        <i class="fas fa-home"></i> View Website
                    </a>
                </li>
            </ul>
        </div>
        
        <div class="main-content">
            <div class="header">
                <h1>Manage Updates</h1>
                <a href="admin_dashboard.php" class="back-btn">
                    <i class="fas fa-arrow-left"></i> Back to Dashboard
                </a>
            </div>
            
            <?php if (!empty($message)): ?>
                <div class="message <?php echo $message_type; ?>">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>
            
            <div class="card">
                <h2>Add New Update</h2>
                <form action="manage_updates.php" method="post">
                    <div class="form-group">
                        <label for="title">Update Title</label>
                        <input type="text" id="title" name="title" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="content">Update Content</label>
                        <textarea id="content" name="content" required></textarea>
                    </div>
                    
                    <button type="submit" name="add_update" class="btn">
                        <i class="fas fa-plus"></i> Post Update
                    </button>
                </form>
            </div>
            
            <div class="card">
                <h2>All Updates</h2>
                
                <?php if (empty($updates)): ?>
                    <div class="empty-updates">
                        <i class="fas fa-newspaper"></i>
                        <p>No updates posted yet.</p>
                    </div>
                <?php else: ?>
                    <div class="updates-list">
                        <?php foreach ($updates as $update): ?>
                            <div class="update-item">
                                <div class="update-item-header">
                                    <h3 class="update-item-title"><?php echo $update['title']; ?></h3>
                                    <span class="update-item-date">
                                        <i class="fas fa-calendar-alt"></i> 
                                        <?php echo date('F d, Y', strtotime($update['posted_at'])); ?>
                                    </span>
                                </div>
                                <div class="update-item-content">
                                    <?php echo nl2br($update['content']); ?>
                                </div>
                                <div class="update-item-actions">
                                    <a href="manage_updates.php?delete=<?php echo $update['id']; ?>" class="btn-delete" onclick="return confirm('Are you sure you want to delete this update?')">
                                        <i class="fas fa-trash"></i> Delete
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <script>
        document.getElementById('mobileMenuBtn').addEventListener('click', function() {
            document.getElementById('sidebar').classList.toggle('active');
        });
    </script>
</body>
</html>
