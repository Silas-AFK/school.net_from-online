<?php
session_start();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $name = $_POST['username'] ?? '';
  $pass = $_POST['password'] ?? '';
  if ($name === 'SILAS' && $pass === 'SILAS123') {
    $_SESSION['admin_logged_in'] = true;  // Changed from $_SESSION['admin'] to match dashboard
    header('Location: admin_dashboard.php');
    exit;
  } else {
    header('Location: login.php?error=1');
    exit;
  }
}

// Display error message if redirected with error parameter
$error = '';
if (isset($_GET['error']) && $_GET['error'] == 1) {
    $error = "Invalid username or password";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - AMXIS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #1a2a6c, #b21f1f, #fdbb2d);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }
        
        .login-container {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 15px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 400px;
            padding: 40px 30px;
            text-align: center;
        }
        
        .login-container h1 {
            color: #333;
            margin-bottom: 30px;
            font-size: 28px;
        }
        
        .login-container .logo {
            margin-bottom: 20px;
        }
        
        .login-container .logo img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            object-fit: cover;
        }
        
        .form-group {
            margin-bottom: 20px;
            text-align: left;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #555;
            font-weight: 500;
        }
        
        .form-group input {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            transition: border-color 0.3s;
        }
        
        .form-group input:focus {
            border-color: #1a2a6c;
            outline: none;
        }
        
        .btn-login {
            background: #1a2a6c;
            color: white;
            border: none;
            border-radius: 8px;
            padding: 12px 20px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            width: 100%;
            transition: background 0.3s;
        }
        
        .btn-login:hover {
            background: #0d1a4a;
        }
        
        .error-message {
            color: #e74c3c;
            margin-bottom: 20px;
            padding: 10px;
            border-radius: 5px;
            background: rgba(231, 76, 60, 0.1);
        }
        
        .back-to-site {
            margin-top: 20px;
        }
        
        .back-to-site a {
            color: #1a2a6c;
            text-decoration: none;
            font-weight: 500;
        }
        
        .back-to-site a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="logo">
            <img src="joys.jpg" alt="AMXIS">
        </div>
        <h1>Admin Login</h1>
        
        <?php if (!empty($error)): ?>
            <div class="error-message"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <form action="login.php" method="post">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
            </div>
            
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            
            <button type="submit" class="btn-login">Login</button>
        </form>
        
        <div class="back-to-site">
            <a href="index.html">← Back to Website</a>
        </div>
    </div>
</body>
</html>
