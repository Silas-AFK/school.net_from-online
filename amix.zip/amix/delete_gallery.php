<?php
// delete_gallery.php
session_start();
require 'db.php';
if (!isset($_SESSION['admin_logged']) || $_SESSION['admin_logged'] !== true) {
    header("Location: admin_login.php");
    exit;
}
$id = intval($_GET['id'] ?? 0);
if ($id <= 0) { header("Location: admin_panel.php"); exit; }

// fetch filename
$stmt = $conn->prepare("SELECT filename FROM gallery WHERE id = ? LIMIT 1");
$stmt->bind_param("i", $id);
$stmt->execute();
$res = $stmt->get_result();
if ($res->num_rows === 1) {
    $row = $res->fetch_assoc();
    $file = __DIR__ . '/uploads/gallery/' . $row['filename'];
    if (file_exists($file)) @unlink($file);
    $del = $conn->prepare("DELETE FROM gallery WHERE id = ?");
    $del->bind_param("i", $id);
    $del->execute();
    $del->close();
}
$stmt->close();
header("Location: admin_panel.php");
exit;
