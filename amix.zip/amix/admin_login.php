<?php
session_start();
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $username = $_POST['name'] ?? '';
  $password = $_POST['password'] ?? '';

  $conn = new mysqli('localhost', 'root', '', 'amix');
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  $stmt = $conn->prepare("SELECT password_hash FROM users WHERE username = ? AND role = 'admin'");
  if (!$stmt) {
    die("Prepare failed: " . $conn->error);
  }

  $stmt->bind_param("s", $username);
  $stmt->execute();
  $result = $stmt->get_result();

  if ($result && $result->num_rows === 1) {
    $row = $result->fetch_assoc();
    if (password_verify($password, $row['password_hash'])) {
      $_SESSION['admin'] = $username;
      header('Location: admin_panel.php');
      exit;
    } else {
      $error = 'Invalid password';
    }
  } else {
    $error = 'Admin not found';
  }

  $stmt->close();
  $conn->close();
}
?>
