<?php
session_start();
include_once 'db.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}

// Get counts for dashboard
$gallery_count = 0;
$updates_count = 0;

$result = $conn->query("SELECT COUNT(*) as count FROM gallery");
if ($result) {
    $row = $result->fetch_assoc();
    $gallery_count = $row['count'];
}

$result = $conn->query("SELECT COUNT(*) as count FROM updates");
if ($result) {
    $row = $result->fetch_assoc();
    $updates_count = $row['count'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - AMXIS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: #f5f5f5;
            color: #333;
        }
        
        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }
        
        .sidebar {
            width: 250px;
            background-color: #1a2a6c;
            color: white;
            padding: 20px 0;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
            transition: all 0.3s;
        }
        
        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            margin-bottom: 20px;
        }
        
        .sidebar-header h2 {
            font-size: 24px;
            margin-bottom: 5px;
        }
        
        .sidebar-header p {
            font-size: 14px;
            opacity: 0.8;
        }
        
        .sidebar-menu {
            list-style: none;
        }
        
        .sidebar-menu li {
            margin-bottom: 5px;
        }
        
        .sidebar-menu a {
            display: block;
            padding: 12px 20px;
            color: white;
            text-decoration: none;
            transition: background 0.3s;
        }
        
        .sidebar-menu a:hover, .sidebar-menu a.active {
            background-color: rgba(255, 255, 255, 0.1);
        }
        
        .sidebar-menu i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 20px;
            flex: 1;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 1px solid #ddd;
        }
        
        .header h1 {
            font-size: 28px;
            color: #1a2a6c;
        }
        
        .logout-btn {
            background-color: #e74c3c;
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            transition: background 0.3s;
        }
        
        .logout-btn:hover {
            background-color: #c0392b;
        }
        
        .logout-btn i {
            margin-right: 5px;
        }
        
        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            padding: 20px;
            display: flex;
            align-items: center;
        }
        
        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            font-size: 24px;
            color: white;
        }
        
        .stat-icon.gallery {
            background-color: #3498db;
        }
        
        .stat-icon.updates {
            background-color: #2ecc71;
        }
        
        .stat-info h3 {
            font-size: 24px;
            margin-bottom: 5px;
        }
        
        .stat-info p {
            color: #777;
            font-size: 14px;
        }
        
        .actions-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
        }
        
        .action-card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            padding: 20px;
        }
        
        .action-card h3 {
            margin-bottom: 15px;
            color: #1a2a6c;
        }
        
        .action-card p {
            margin-bottom: 15px;
            color: #555;
        }
        
        .action-btn {
            display: inline-block;
            padding: 10px 15px;
            background-color: #1a2a6c;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background 0.3s;
        }
        
        .action-btn:hover {
            background-color: #0d1a4a;
        }
        
        .action-btn i {
            margin-right: 5px;
        }
        
        .mobile-menu-btn {
            display: none;
            position: fixed;
            top: 20px;
            left: 20px;
            z-index: 1000;
            background-color: #1a2a6c;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 10px;
            cursor: pointer;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                z-index: 999;
            }
            
            .sidebar.active {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .mobile-menu-btn {
                display: block;
            }
        }
    </style>
</head>
<body>
    <button class="mobile-menu-btn" id="mobileMenuBtn">
        <i class="fas fa-bars"></i>
    </button>
    
    <div class="dashboard-container">
        <div class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <h2>AMXIS</h2>
                <p>Admin Panel</p>
            </div>
            
            <ul class="sidebar-menu">
                <li>
                    <a href="admin_dashboard.php" class="active">
                        <i class="fas fa-tachometer-alt"></i> Dashboard
                    </a>
                </li>
                <li>
                    <a href="manage_gallery.php">
                        <i class="fas fa-images"></i> Manage Gallery
                    </a>
                </li>
                <li>
                    <a href="manage_updates.php">
                        <i class="fas fa-newspaper"></i> Manage Updates
                    </a>
                </li>
                <li>
                    <a href="view_gallery.php" target="_blank">
                        <i class="fas fa-eye"></i> View Gallery
                    </a>
                </li>
                <li>
                    <a href="view_updates.php" target="_blank">
                        <i class="fas fa-eye"></i> View Updates
                    </a>
                </li>
                <li>
                    <a href="index.html" target="_blank">
                        <i class="fas fa-home"></i> View Website
                    </a>
                </li>
            </ul>
        </div>
        
        <div class="main-content">
            <div class="header">
                <h1>Dashboard</h1>
                <a href="logout.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </div>
            
            <div class="stats-container">
                <div class="stat-card">
                    <div class="stat-icon gallery">
                        <i class="fas fa-images"></i>
                    </div>
                    <div class="stat-info">
                        <h3><?php echo $gallery_count; ?></h3>
                        <p>Gallery Items</p>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon updates">
                        <i class="fas fa-newspaper"></i>
                    </div>
                    <div class="stat-info">
                        <h3><?php echo $updates_count; ?></h3>
                        <p>Updates Posted</p>
                    </div>
                </div>
            </div>
            
            <div class="actions-container">
                <div class="action-card">
                    <h3>Gallery Management</h3>
                    <p>Upload, view, and delete images in the gallery section.</p>
                    <a href="manage_gallery.php" class="action-btn">
                        <i class="fas fa-cog"></i> Manage Gallery
                    </a>
                </div>
                
                <div class="action-card">
                    <h3>Updates Management</h3>
                    <p>Create, view, and delete updates for your visitors.</p>
                    <a href="manage_updates.php" class="action-btn">
                        <i class="fas fa-cog"></i> Manage Updates
                    </a>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        document.getElementById('mobileMenuBtn').addEventListener('click', function() {
            document.getElementById('sidebar').classList.toggle('active');
        });
    </script>
</body>
</html>
