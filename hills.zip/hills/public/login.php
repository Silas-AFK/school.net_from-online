<?php
require_once '../config.php';

// Check if user is already logged in
if (isset($_SESSION['user_id'])) {
    if ($_SESSION['user_type'] === 'admin') {
        header('Location: dashboard.php');
    } else {
        header('Location: user/shop.php');
    }
    exit();
}

// Handle login form submission
$login_error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');
    
    if (!empty($username) && !empty($password)) {
        $stmt = $conn->prepare("SELECT id, username, password, user_type, full_name FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            // Password verification - comparing plain text with hardcoded credentials
            if ($username === 'hilary' && $password === 'hilary123') {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['user_type'] = $user['user_type'];
                $_SESSION['full_name'] = $user['full_name'];
                
                header('Location: admin/dashboard.php');
                exit();
            } else {
                $login_error = 'Invalid username or password';
            }
        } else {
            $login_error = 'User not found';
        }
        $stmt->close();
    } else {
        $login_error = 'Please enter username and password';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo SITE_NAME; ?> - Login</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/login.css">
</head>
<body class="login-page">
    <div class="login-container">
        <div class="login-content">
            <!-- Admin Login Card -->
            <div class="login-box admin-login animate-slide-in">
                <div class="login-header">
                    <img src="../logo.png" alt="Hills Pharmacy Logo" class="logo-image">
                    <h1><?php echo SITE_NAME; ?></h1>
                    <p class="tagline">Pharmacy Management System</p>
                </div>
                
                <form method="POST" class="login-form">
                    <?php if ($login_error): ?>
                        <div class="alert alert-error animate-shake">
                            <strong>Error:</strong> <?php echo htmlspecialchars($login_error); ?>
                        </div>
                    <?php endif; ?>
                    
                    <div class="form-group">
                        <label for="username">
                            <span class="label-icon">👤</span>
                            Username
                        </label>
                        <input type="text" id="username" name="username" required placeholder="Enter your username" class="form-input" autofocus>
                    </div>
                    
                    <div class="form-group">
                        <label for="password">
                            <span class="label-icon">🔐</span>
                            Password
                        </label>
                        <input type="password" id="password" name="password" required placeholder="Enter your password" class="form-input">
                    </div>
                    
                    <button type="submit" class="btn btn-primary btn-block btn-login">
                        <span class="btn-icon">🚪</span>
                        Login
                    </button>
                </form>
                
                <div class="login-footer">
                    <div class="demo-info">
                        <h4>Demo Admin Account</h4>
                        <p><strong>Username:</strong> hilary</p>
                        <p><strong>Password:</strong> hilary123</p>
                    </div>
                    <div class="footer-links">
                        <a href="about.html" class="link">Learn About Us</a>
                        <a href="../user/shop.php" class="link">Browse Products</a>
                    </div>
                </div>
            </div>
            
            <!-- Right Side Info -->
            <div class="login-info animate-fade-in" style="animation-delay: 0.2s;">
                <div class="info-card">
                    <h2>Welcome to Hills Pharmacy</h2>
                    <p>Your trusted pharmacy management solution for efficient inventory and sales tracking.</p>
                    
                    <div class="features">
                        <div class="feature">
                            <span class="feature-icon">📊</span>
                            <h4>Admin Dashboard</h4>
                            <p>Monitor sales, inventory, and business metrics in real-time</p>
                        </div>
                        <div class="feature">
                            <span class="feature-icon">💊</span>
                            <h4>Product Management</h4>
                            <p>Manage pharmaceutical products with expiry dates and stock levels</p>
                        </div>
                        <div class="feature">
                            <span class="feature-icon">🛒</span>
                            <h4>Point of Sale</h4>
                            <p>Quick checkout system with multiple payment methods</p>
                        </div>
                        <div class="feature">
                            <span class="feature-icon">📈</span>
                            <h4>Analytics</h4>
                            <p>Detailed reports on sales trends and product performance</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
