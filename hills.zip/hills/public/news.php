<?php
require_once '../config.php';

// Get published news
$news_items = [];

$sql = "SELECT n.*, u.full_name 
        FROM news n 
        LEFT JOIN users u ON n.created_by = u.id 
        WHERE n.status = 'published' 
        ORDER BY n.created_at DESC";

$result = $conn->query($sql);

if ($result === false) {
    die("SQL Error: " . $conn->error);
}

while ($row = $result->fetch_assoc()) {
    $news_items[] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>News - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/about.css">
    <style>
        .news-section {
            padding: 60px 20px;
            background: #f9f9f9;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .section-title {
            text-align: center;
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 50px;
            color: #27ae60;
        }
        
        .news-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 30px;
            margin-bottom: 40px;
        }
        
        .news-card {
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: transform 0.3s, box-shadow 0.3s;
            animation: fadeIn 0.6s ease-in;
        }
        
        .news-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 12px rgba(0,0,0,0.15);
        }
        
        .news-card-image {
            width: 100%;
            height: 200px;
            object-fit: cover;
            background: #f0f0f0;
        }
        
        .news-card-content {
            padding: 20px;
        }
        
        .news-card-title {
            font-size: 1.25rem;
            font-weight: 600;
            margin-bottom: 10px;
            color: #333;
        }
        
        .news-card-excerpt {
            font-size: 0.95rem;
            color: #666;
            margin-bottom: 15px;
            line-height: 1.5;
        }
        
        .news-card-meta {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.85rem;
            color: #999;
            border-top: 1px solid #eee;
            padding-top: 10px;
        }
        
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #999;
        }
        
        .empty-state-icon {
            font-size: 3rem;
            margin-bottom: 20px;
        }
        
        @media (max-width: 768px) {
            .section-title {
                font-size: 1.8rem;
                margin-bottom: 30px;
            }
            
            .news-grid {
                grid-template-columns: 1fr;
                gap: 20px;
            }
        }
        
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar">
        <div class="navbar-container">
            <div class="navbar-logo">
                <!-- Fixed logo path to go up one directory -->
                <img src="../logo.png" alt="Hills Pharmacy Logo" class="logo-img">
                <span class="logo-text">Hills Pharmacy</span>
            </div>
            <div class="nav-menu">
                <a href="about.html" class="nav-link">About Us</a>
                <a href="news.php" class="nav-link active">News</a>
                <a href="../user/shop.php" class="nav-link">Shop</a>
                <a href="#contact" class="nav-link">Contact</a>
                <a href="login.php" class="btn btn-primary btn-sm">Login</a>
            </div>
            <div class="hamburger">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    </nav>
    
    <!-- News Section -->
    <section class="news-section">
        <div class="container">
            <h2 class="section-title">Latest News & Updates</h2>
            
            <?php if (count($news_items) > 0): ?>
                <div class="news-grid">
                    <?php foreach ($news_items as $news): ?>
                        <div class="news-card">
                            <?php if (!empty($news['image_path'])): ?>
                                <img src="../<?php echo htmlspecialchars($news['image_path']); ?>" alt="<?php echo htmlspecialchars($news['title']); ?>" class="news-card-image">
                            <?php else: ?>
                                <div class="news-card-image" style="display: flex; align-items: center; justify-content: center; background: linear-gradient(135deg, #27ae60, #2ecc71);">
                                    <span style="font-size: 3rem; color: white;">📰</span>
                                </div>
                            <?php endif; ?>
                            
                            <div class="news-card-content">
                                <h3 class="news-card-title"><?php echo htmlspecialchars($news['title']); ?></h3>
                                <p class="news-card-excerpt">
                                    <?php echo htmlspecialchars(substr($news['content'], 0, 150)); ?>...
                                </p>
                                <div class="news-card-meta">
                                    <span><?php echo date('M d, Y', strtotime($news['created_at'])); ?></span>
                                    <span>By: <?php echo htmlspecialchars($news['full_name'] ?? 'Admin'); ?></span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <div class="empty-state-icon">📰</div>
                    <h3>No News Available</h3>
                    <p>Check back soon for updates from Hills Pharmacy</p>
                </div>
            <?php endif; ?>
        </div>
    </section>
    
    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h4>Contact Us</h4>
                    <p>📧 ndehilary25@gmail.com</p>
                    <p>📱 +237674756931</p>
                    <p>📍 Bambili, Cameroon</p>
                </div>
                <div class="footer-section">
                    <h4>Quick Links</h4>
                    <a href="about.html">About Us</a>
                    <a href="news.php">News</a>
                    <!-- Fixed Shop link to point to correct user/shop.php page -->
                    <a href="../user/shop.php">Shop</a>
                </div>
                <div class="footer-section">
                    <h4>Hours</h4>
                    <p>Monday - Friday: 8AM - 6PM</p>
                    <p>Saturday: 9AM - 4PM</p>
                    <p>Sunday: Closed</p>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2026 Hills Pharmacy. All rights reserved.</p>
            </div>
        </div>
    </footer>
    
    <script>
        // Mobile menu toggle
        document.querySelector('.hamburger').addEventListener('click', function() {
            document.querySelector('.nav-menu').classList.toggle('active');
        });
    </script>
</body>
</html>
