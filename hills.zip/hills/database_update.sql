-- Add image support to products table
ALTER TABLE products ADD COLUMN image_path VARCHAR(255);
ALTER TABLE products ADD COLUMN detailed_description LONGTEXT;

-- Create news/announcements table
CREATE TABLE IF NOT EXISTS news (
  id INT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(255) NOT NULL,
  content LONGTEXT NOT NULL,
  image_path VARCHAR(255),
  created_by INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  status ENUM('published', 'draft') DEFAULT 'published',
  FOREIGN KEY (created_by) REFERENCES users(id)
);

-- Create uploads directory folder (manual step)
-- ALTER TABLE products MODIFY image_path VARCHAR(255) AFTER batch_number;
