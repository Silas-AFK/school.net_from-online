<?php
require_once '../config.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ../index.php');
    exit();
}

// Get all products
$products = [];
$search = trim($_GET['search'] ?? '');
$category = trim($_GET['category'] ?? '');

$query = "SELECT * FROM products WHERE quantity_in_stock > 0";

if (!empty($search)) {
    $search_escaped = $conn->real_escape_string($search);
    $query .= " AND (product_name LIKE '%$search_escaped%' OR description LIKE '%$search_escaped%')";
}

if (!empty($category)) {
    $category_escaped = $conn->real_escape_string($category);
    $query .= " AND category = '$category_escaped'";
}

$query .= " ORDER BY product_name ASC";
$result = $conn->query($query);

while ($row = $result->fetch_assoc()) {
    $products[] = $row;
}

// Get categories
$categories = [];
$result = $conn->query("SELECT DISTINCT category FROM products WHERE quantity_in_stock > 0 ORDER BY category");
while ($row = $result->fetch_assoc()) {
    $categories[] = $row['category'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shop - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/shop.css">
</head>
<body>
    <div class="shop-container">
        <!-- Header -->
        <header class="shop-header">
            <div class="header-content">
                <div class="logo-section">
                    <h1 class="site-title">💊 <?php echo SITE_NAME; ?></h1>
                    <p class="tagline">Your Trusted Pharmacy Partner</p>
                </div>
                
                <div class="user-section">
                    <span>Welcome, <?php echo htmlspecialchars($_SESSION['full_name'] ?? $_SESSION['username']); ?></span>
                    <!-- Fixed logout link to point to index.php with proper logout action -->
                    <a href="logout.php" class="btn btn-sm btn-danger">Logout</a>
                </div>
            </div>
        </header>
        
        <!-- Main Content -->
        <div class="shop-main">
            <!-- Sidebar Filters -->
            <aside class="shop-sidebar animate-slide-in">
                <div class="filter-card">
                    <h3>Search Products</h3>
                    <form method="GET" class="filter-form">
                        <input type="text" name="search" placeholder="Search products..." value="<?php echo htmlspecialchars($search); ?>" class="form-input">
                        
                        <?php if (count($categories) > 0): ?>
                            <label>Category</label>
                            <select name="category" class="form-input">
                                <option value="">All Categories</option>
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?php echo htmlspecialchars($cat); ?>" <?php echo $category === $cat ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($cat); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        <?php endif; ?>
                        
                        <button type="submit" class="btn btn-primary btn-block">Search</button>
                    </form>
                </div>
            </aside>
            
            <!-- Products Grid -->
            <main class="shop-content">
                <div class="products-header">
                    <h2>Available Products</h2>
                    <!-- Fixed cart link from ../user/cart.php to cart.php (unnecessary parent traversal) -->
                    <a href="cart.php" class="btn btn-secondary cart-btn">🛒 View Cart</a>
                </div>
                
                <?php if (count($products) > 0): ?>
                    <div class="products-grid">
                        <?php foreach ($products as $product): ?>
                            <div class="product-card animate-fade-in">
                                <!-- Display actual drug image if available, otherwise use placeholder -->
                                <div class="product-image">
                                    <?php if (!empty($product['image_path'])): ?>
                                        <img src="../<?php echo htmlspecialchars($product['image_path']); ?>" alt="<?php echo htmlspecialchars($product['product_name']); ?>" style="width: 100%; height: 100%; object-fit: cover;">
                                    <?php else: ?>
                                        <span>💊</span>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="product-info">
                                    <h3 class="product-name"><?php echo htmlspecialchars($product['product_name']); ?></h3>
                                    <p class="product-category"><?php echo htmlspecialchars($product['category']); ?></p>
                                    
                                    <!-- Show detailed description if available, otherwise show basic description -->
                                    <?php if (!empty($product['detailed_description'])): ?>
                                        <p class="product-description"><?php echo nl2br(htmlspecialchars(substr($product['detailed_description'], 0, 100))); ?></p>
                                    <?php elseif (!empty($product['description'])): ?>
                                        <p class="product-description"><?php echo htmlspecialchars($product['description']); ?></p>
                                    <?php endif; ?>
                                    
                                    <div class="product-meta">
                                        <span class="stock-info">
                                            <?php echo $product['quantity_in_stock']; ?> in stock
                                        </span>
                                        <?php if (!empty($product['expiry_date'])): ?>
                                            <span class="expiry-info">
                                                Expires: <?php echo date('M Y', strtotime($product['expiry_date'])); ?>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <div class="product-footer">
                                        <span class="product-price">$<?php echo number_format($product['price'], 2); ?></span>
                                        <button class="btn btn-primary btn-sm" onclick="addToCart(<?php echo $product['id']; ?>, '<?php echo htmlspecialchars($product['product_name']); ?>', <?php echo $product['price']; ?>)">Add to Cart</button>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <p class="empty-icon">🔍</p>
                        <h3>No Products Found</h3>
                        <p>Try adjusting your search or filters</p>
                    </div>
                <?php endif; ?>
            </main>
        </div>
    </div>
    
    <script src="../js/shop.js"></script>
</body>
</html>
