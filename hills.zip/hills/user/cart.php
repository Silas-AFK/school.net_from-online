<?php
require_once '../config.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ../index.php');
    exit();
}

// Get cart items from session
$cart_items = $_SESSION['cart'] ?? [];
$total = 0;

// Fetch product details for cart items
$cart = [];
foreach ($cart_items as $product_id => $quantity) {
    $stmt = $conn->prepare("SELECT id, product_name, price, quantity_in_stock FROM products WHERE id = ?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        $subtotal = $row['price'] * $quantity;
        $total += $subtotal;
        $cart[] = [
            'id' => $row['id'],
            'name' => $row['product_name'],
            'price' => $row['price'],
            'quantity' => $quantity,
            'subtotal' => $subtotal,
            'stock' => $row['quantity_in_stock']
        ];
    }
    $stmt->close();
}

// Handle checkout
$checkout_message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'checkout') {
    if (count($cart) === 0) {
        $checkout_message = 'Cart is empty';
    } else {
        // Create sale record
        $user_id = $_SESSION['user_id'];
        $payment_method = trim($_POST['payment_method'] ?? 'Cash');
        
        $stmt = $conn->prepare("INSERT INTO sales (user_id, total_amount, payment_method, status) VALUES (?, ?, ?, 'completed')");
        $stmt->bind_param("ids", $user_id, $total, $payment_method);
        
        if ($stmt->execute()) {
            $sale_id = $conn->insert_id;
            
            // Insert sale items and update stock
            $success = true;
            foreach ($cart as $item) {
                // Insert sale item
                $stmt2 = $conn->prepare("INSERT INTO sale_items (sale_id, product_id, quantity, unit_price, subtotal) VALUES (?, ?, ?, ?, ?)");
                $stmt2->bind_param("iiids", $sale_id, $item['id'], $item['quantity'], $item['price'], $item['subtotal']);
                
                if (!$stmt2->execute()) {
                    $success = false;
                    break;
                }
                $stmt2->close();
                
                // Update product stock
                $new_quantity = $item['stock'] - $item['quantity'];
                $stmt3 = $conn->prepare("UPDATE products SET quantity_in_stock = ? WHERE id = ?");
                $stmt3->bind_param("ii", $new_quantity, $item['id']);
                
                if (!$stmt3->execute()) {
                    $success = false;
                    break;
                }
                $stmt3->close();
            }
            
            if ($success) {
                unset($_SESSION['cart']);
                $checkout_message = 'Purchase successful! Sale #' . $sale_id;
                $cart = [];
                $total = 0;
            }
        }
        $stmt->close();
    }
}

// Handle remove from cart
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'remove') {
    $product_id = intval($_POST['product_id'] ?? 0);
    if (isset($_SESSION['cart'][$product_id])) {
        unset($_SESSION['cart'][$product_id]);
        header('Location: cart.php');
        exit();
    }
}

// Handle update quantity
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update') {
    $product_id = intval($_POST['product_id'] ?? 0);
    $quantity = intval($_POST['quantity'] ?? 0);
    
    if ($product_id > 0 && $quantity > 0) {
        $_SESSION['cart'][$product_id] = $quantity;
    }
    
    header('Location: cart.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/shop.css">
</head>
<body>
    <div class="shop-container">
        <!-- Header -->
        <header class="shop-header">
            <div class="header-content">
                <div class="logo-section">
                    <h1 class="site-title">💊 <?php echo SITE_NAME; ?></h1>
                    <a href="shop.php" class="btn btn-sm btn-secondary">Back to Shop</a>
                </div>
                
                <div class="user-section">
                    <!-- Fixed logout link to point to logout.php -->
                    <a href="logout.php" class="btn btn-sm btn-danger">Logout</a>
                </div>
            </div>
        </header>
        
        <!-- Cart Content -->
        <div class="cart-container">
            <h1>Shopping Cart</h1>
            
            <?php if ($checkout_message): ?>
                <div class="alert alert-success animate-slide-down">
                    <?php echo htmlspecialchars($checkout_message); ?>
                </div>
            <?php endif; ?>
            
            <?php if (count($cart) > 0): ?>
                <div class="cart-wrapper">
                    <!-- Cart Items -->
                    <div class="cart-items">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Price</th>
                                    <th>Quantity</th>
                                    <th>Subtotal</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($cart as $item): ?>
                                    <tr class="animate-table-row">
                                        <td><?php echo htmlspecialchars($item['name']); ?></td>
                                        <td class="price">$<?php echo number_format($item['price'], 2); ?></td>
                                        <td>
                                            <form method="POST" style="display: inline; margin: 0;">
                                                <input type="hidden" name="action" value="update">
                                                <input type="hidden" name="product_id" value="<?php echo $item['id']; ?>">
                                                <input type="number" name="quantity" value="<?php echo $item['quantity']; ?>" min="1" max="<?php echo $item['stock']; ?>" style="width: 60px; padding: 5px; border: 1px solid #ddd; border-radius: 4px;">
                                                <button type="submit" class="btn btn-xs btn-secondary">Update</button>
                                            </form>
                                        </td>
                                        <td class="price">$<?php echo number_format($item['subtotal'], 2); ?></td>
                                        <td>
                                            <form method="POST" style="display: inline;" onsubmit="return confirm('Remove from cart?');">
                                                <input type="hidden" name="action" value="remove">
                                                <input type="hidden" name="product_id" value="<?php echo $item['id']; ?>">
                                                <button type="submit" class="btn btn-xs btn-danger">Remove</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Checkout Summary -->
                    <div class="cart-summary">
                        <div class="summary-card">
                            <h2>Order Summary</h2>
                            
                            <div class="summary-row">
                                <span>Subtotal:</span>
                                <span class="price">$<?php echo number_format($total, 2); ?></span>
                            </div>
                            
                            <div class="summary-row">
                                <span>Tax (0%):</span>
                                <span class="price">$0.00</span>
                            </div>
                            
                            <div class="summary-row total">
                                <span>Total:</span>
                                <span class="price">$<?php echo number_format($total, 2); ?></span>
                            </div>
                            
                            <form method="POST" class="checkout-form">
                                <input type="hidden" name="action" value="checkout">
                                
                                <div class="form-group">
                                    <label>Payment Method</label>
                                    <select name="payment_method" class="form-input" required>
                                        <option value="Cash">Cash</option>
                                        <option value="Card">Credit/Debit Card</option>
                                        <option value="Mobile Money">Mobile Money</option>
                                    </select>
                                </div>
                                
                                <button type="submit" class="btn btn-primary btn-block">Complete Purchase</button>
                                <a href="shop.php" class="btn btn-secondary btn-block">Continue Shopping</a>
                            </form>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <p class="empty-icon">🛒</p>
                    <h3>Your Cart is Empty</h3>
                    <p>Add some products to get started</p>
                    <a href="shop.php" class="btn btn-primary">Start Shopping</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
