<?php
require_once '../config.php';

// Check authentication
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: ../index.php');
    exit();
}

// Get all sales
$sales = [];
$result = $conn->query("
    SELECT s.id, s.sale_date, s.total_amount, s.status, COUNT(si.id) as item_count
    FROM sales s
    LEFT JOIN sale_items si ON s.id = si.sale_id
    GROUP BY s.id
    ORDER BY s.sale_date DESC
");

while ($row = $result->fetch_assoc()) {
    $sales[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/admin.css">
</head>
<body>
    <div class="admin-container">
        <nav class="sidebar">
            <div class="sidebar-header">
                <div class="logo">💊</div>
                <h2><?php echo SITE_NAME; ?></h2>
            </div>
            
            <ul class="nav-menu">
                <li><a href="dashboard.php" class="nav-link"><span class="icon">📊</span> Dashboard</a></li>
                <li><a href="products.php" class="nav-link"><span class="icon">💊</span> Products</a></li>
                <li><a href="sales.php" class="nav-link active"><span class="icon">💰</span> Sales</a></li>
                <li><a href="inventory.php" class="nav-link"><span class="icon">📦</span> Inventory</a></li>
                <li><a href="users.php" class="nav-link"><span class="icon">👥</span> Users</a></li>
                <li><a href="reports.php" class="nav-link"><span class="icon">📈</span> Reports</a></li>
                <li><a href="logout.php" class="nav-link logout"><span class="icon">🚪</span> Logout</a></li>
            </ul>
        </nav>
        
        <main class="main-content">
            <header class="top-bar">
                <h1>Sales Management</h1>
            </header>
            
            <div class="dashboard-content">
                <div class="card">
                    <div class="card-header">
                        <h2>All Sales</h2>
                    </div>
                    
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Sale ID</th>
                                <th>Date</th>
                                <th>Items</th>
                                <th>Total Amount</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($sales as $sale): ?>
                                <tr class="animate-table-row">
                                    <td>#<?php echo $sale['id']; ?></td>
                                    <td><?php echo date('M d, Y H:i', strtotime($sale['sale_date'])); ?></td>
                                    <td><?php echo $sale['item_count']; ?></td>
                                    <td class="price">$<?php echo number_format($sale['total_amount'], 2); ?></td>
                                    <td>
                                        <span class="badge <?php echo $sale['status'] === 'completed' ? 'badge-success' : 'badge-warning'; ?>">
                                            <?php echo ucfirst($sale['status']); ?>
                                        </span>
                                    </td>
                                    <td><a href="sale-detail.php?id=<?php echo $sale['id']; ?>" class="btn btn-xs btn-primary">View</a></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
