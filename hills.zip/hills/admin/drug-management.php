<?php
require_once '../config.php';

// Check authentication
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: ../index.php');
    exit();
}

$message = '';
$message_type = '';

// Handle file upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'upload') {
    $product_id = intval($_POST['product_id'] ?? 0);
    $detailed_description = trim($_POST['detailed_description'] ?? '');
    
    if ($product_id > 0) {
        // Create uploads directory if it doesn't exist
        $upload_dir = '../uploads/drugs/';
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }
        
        $image_path = '';
        
        // Handle file upload
        if (isset($_FILES['drug_image']) && $_FILES['drug_image']['error'] === UPLOAD_ERR_OK) {
            $file_tmp = $_FILES['drug_image']['tmp_name'];
            $file_name = $_FILES['drug_image']['name'];
            $file_ext = pathinfo($file_name, PATHINFO_EXTENSION);
            
            // Validate file type
            $allowed_ext = ['jpg', 'jpeg', 'png', 'gif'];
            if (in_array(strtolower($file_ext), $allowed_ext)) {
                // Create unique filename
                $new_filename = 'drug_' . $product_id . '_' . time() . '.' . $file_ext;
                $file_path = $upload_dir . $new_filename;
                
                if (move_uploaded_file($file_tmp, $file_path)) {
                    $image_path = 'uploads/drugs/' . $new_filename;
                    
                    // Update product with image and description
                    $stmt = $conn->prepare("UPDATE products SET image_path = ?, detailed_description = ? WHERE id = ?");
                    $stmt->bind_param("ssi", $image_path, $detailed_description, $product_id);
                    
                    if ($stmt->execute()) {
                        $message = 'Drug information updated successfully!';
                        $message_type = 'success';
                    } else {
                        $message = 'Error updating product';
                        $message_type = 'error';
                    }
                    $stmt->close();
                } else {
                    $message = 'Error uploading file';
                    $message_type = 'error';
                }
            } else {
                $message = 'Invalid file format. Use JPG, PNG, or GIF';
                $message_type = 'error';
            }
        } else if (!empty($detailed_description)) {
            // Update description only if no file upload
            $stmt = $conn->prepare("UPDATE products SET detailed_description = ? WHERE id = ?");
            $stmt->bind_param("si", $detailed_description, $product_id);
            
            if ($stmt->execute()) {
                $message = 'Description updated successfully!';
                $message_type = 'success';
            }
            $stmt->close();
        }
    }
}

// Get all products
$products = [];
$result = $conn->query("SELECT id, product_name, category, image_path, detailed_description FROM products ORDER BY product_name ASC");
while ($row = $result->fetch_assoc()) {
    $products[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Drug Management - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/admin.css">
    <style>
        .drug-card {
            background: white;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            border: 1px solid #e0e0e0;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .drug-image {
            width: 150px;
            height: 150px;
            object-fit: cover;
            border-radius: 8px;
            margin-bottom: 15px;
            background: #f5f5f5;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .drug-form {
            display: grid;
            gap: 15px;
        }
        
        .form-group {
            display: grid;
            gap: 5px;
        }
        
        .form-group label {
            font-weight: 600;
            color: #333;
        }
        
        .form-group input,
        .form-group textarea {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-family: inherit;
        }
        
        .form-group textarea {
            min-height: 100px;
            resize: vertical;
        }
        
        @media (max-width: 768px) {
            .drug-card {
                padding: 15px;
            }
            
            .drug-form {
                gap: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <nav class="sidebar">
            <div class="sidebar-header">
                <div class="logo">💊</div>
                <h2><?php echo SITE_NAME; ?></h2>
            </div>
            
            <ul class="nav-menu">
                <li><a href="dashboard.php" class="nav-link"><span class="icon">📊</span> Dashboard</a></li>
                <li><a href="products.php" class="nav-link"><span class="icon">💊</span> Products</a></li>
                <li><a href="drug-management.php" class="nav-link active"><span class="icon">📸</span> Drug Info</a></li>
                <li><a href="news.php" class="nav-link"><span class="icon">📰</span> News</a></li>
                <li><a href="sales.php" class="nav-link"><span class="icon">💰</span> Sales</a></li>
                <li><a href="inventory.php" class="nav-link"><span class="icon">📦</span> Inventory</a></li>
                <li><a href="reports.php" class="nav-link"><span class="icon">📈</span> Reports</a></li>
                <li><a href="logout.php" class="nav-link logout"><span class="icon">🚪</span> Logout</a></li>
            </ul>
        </nav>
        
        <!-- Main Content -->
        <main class="main-content">
            <header class="top-bar">
                <h1>Drug Information Management</h1>
                <div class="user-info">
                    <span>Welcome, <?php echo htmlspecialchars($_SESSION['full_name']); ?></span>
                    <div class="avatar">👤</div>
                </div>
            </header>
            
            <div class="dashboard-content">
                <?php if ($message): ?>
                    <div class="alert alert-<?php echo $message_type; ?> animate-slide-down">
                        <?php echo htmlspecialchars($message); ?>
                    </div>
                <?php endif; ?>
                
                <?php foreach ($products as $product): ?>
                    <div class="drug-card animate-fade-in">
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; align-items: start;">
                            <div>
                                <?php if (!empty($product['image_path'])): ?>
                                    <img src="../<?php echo htmlspecialchars($product['image_path']); ?>" alt="<?php echo htmlspecialchars($product['product_name']); ?>" class="drug-image" style="width: 150px; height: 150px;">
                                <?php else: ?>
                                    <div class="drug-image" style="width: 150px; height: 150px; border: 2px dashed #ccc;">
                                        <span style="font-size: 24px;">📷</span>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <form method="POST" enctype="multipart/form-data" class="drug-form">
                                <input type="hidden" name="action" value="upload">
                                <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                                
                                <h3><?php echo htmlspecialchars($product['product_name']); ?></h3>
                                <p style="color: #666; margin: 0;">Category: <?php echo htmlspecialchars($product['category']); ?></p>
                                
                                <div class="form-group">
                                    <label for="drug_image_<?php echo $product['id']; ?>">Upload Image</label>
                                    <input type="file" id="drug_image_<?php echo $product['id']; ?>" name="drug_image" accept="image/*">
                                    <small style="color: #999;">JPG, PNG, or GIF (Max 5MB)</small>
                                </div>
                                
                                <div class="form-group">
                                    <label for="description_<?php echo $product['id']; ?>">Detailed Description</label>
                                    <textarea id="description_<?php echo $product['id']; ?>" name="detailed_description" placeholder="Add detailed information about this drug..."><?php echo htmlspecialchars($product['detailed_description'] ?? ''); ?></textarea>
                                </div>
                                
                                <button type="submit" class="btn btn-primary">Save Changes</button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </main>
    </div>
</body>
</html>
