<?php
require_once '../config.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: ../index.php');
    exit();
}

// Get dashboard statistics
$stats = [];

// Total products
$result = $conn->query("SELECT COUNT(*) as total FROM products");
$stats['total_products'] = $result->fetch_assoc()['total'];

// Total sales
$result = $conn->query("SELECT SUM(total_amount) as total FROM sales WHERE status = 'completed'");
$row = $result->fetch_assoc();
$stats['total_sales'] = $row['total'] ?? 0;

// Low stock items
$result = $conn->query("SELECT COUNT(*) as total FROM products WHERE quantity_in_stock <= reorder_level");
$stats['low_stock'] = $result->fetch_assoc()['total'];

// Today's sales
$result = $conn->query("SELECT SUM(total_amount) as total FROM sales WHERE DATE(sale_date) = CURDATE() AND status = 'completed'");
$row = $result->fetch_assoc();
$stats['today_sales'] = $row['total'] ?? 0;

// Recent sales
$recent_sales = [];
$result = $conn->query("SELECT s.id, s.sale_date, s.total_amount, COUNT(si.id) as items FROM sales s LEFT JOIN sale_items si ON s.id = si.sale_id WHERE s.status = 'completed' GROUP BY s.id ORDER BY s.sale_date DESC LIMIT 5");
while ($row = $result->fetch_assoc()) {
    $recent_sales[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/admin.css">
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar Navigation -->
        <nav class="sidebar">
            <div class="sidebar-header">
                <div class="logo">💊</div>
                <h2><?php echo SITE_NAME; ?></h2>
            </div>
            
            <ul class="nav-menu">
                <li><a href="dashboard.php" class="nav-link active"><span class="icon">📊</span> Dashboard</a></li>
                <li><a href="products.php" class="nav-link"><span class="icon">💊</span> Products</a></li>
                <li><a href="drug-management.php" class="nav-link"><span class="icon">📸</span> Drug Info</a></li>
                <li><a href="news.php" class="nav-link"><span class="icon">📰</span> News</a></li>
                <li><a href="sales.php" class="nav-link"><span class="icon">💰</span> Sales</a></li>
                <li><a href="inventory.php" class="nav-link"><span class="icon">📦</span> Inventory</a></li>
                <li><a href="reports.php" class="nav-link"><span class="icon">📈</span> Reports</a></li>
                <li><a href="logout.php" class="nav-link logout"><span class="icon">🚪</span> Logout</a></li>
            </ul>
        </nav>
        
        <!-- Main Content -->
        <main class="main-content">
            <header class="top-bar">
                <h1>Dashboard</h1>
                <div class="user-info">
                    <span>Welcome, <?php echo htmlspecialchars($_SESSION['full_name']); ?></span>
                    <div class="avatar">👤</div>
                </div>
            </header>
            
            <div class="dashboard-content">
                <!-- Stats Cards -->
                <div class="stats-grid">
                    <div class="stat-card animate-fade-in">
                        <div class="stat-icon primary">💊</div>
                        <div class="stat-info">
                            <p class="stat-label">Total Products</p>
                            <p class="stat-value"><?php echo $stats['total_products']; ?></p>
                        </div>
                    </div>
                    
                    <div class="stat-card animate-fade-in">
                        <div class="stat-icon success">💰</div>
                        <div class="stat-info">
                            <p class="stat-label">Total Sales</p>
                            <p class="stat-value">$<?php echo number_format($stats['total_sales'], 2); ?></p>
                        </div>
                    </div>
                    
                    <div class="stat-card animate-fade-in">
                        <div class="stat-icon warning">⚠️</div>
                        <div class="stat-info">
                            <p class="stat-label">Low Stock Items</p>
                            <p class="stat-value"><?php echo $stats['low_stock']; ?></p>
                        </div>
                    </div>
                    
                    <div class="stat-card animate-fade-in">
                        <div class="stat-icon info">📅</div>
                        <div class="stat-info">
                            <p class="stat-label">Today's Sales</p>
                            <p class="stat-value">$<?php echo number_format($stats['today_sales'], 2); ?></p>
                        </div>
                    </div>
                </div>
                
                <!-- Recent Sales Table -->
                <div class="card animate-slide-up">
                    <div class="card-header">
                        <h2>Recent Sales</h2>
                        <a href="sales.php" class="btn btn-sm btn-secondary">View All</a>
                    </div>
                    
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Sale ID</th>
                                <th>Date</th>
                                <th>Items</th>
                                <th>Total Amount</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recent_sales as $sale): ?>
                                <tr class="animate-table-row">
                                    <td>#<?php echo $sale['id']; ?></td>
                                    <td><?php echo date('M d, Y H:i', strtotime($sale['sale_date'])); ?></td>
                                    <td><?php echo $sale['items']; ?></td>
                                    <td class="price">$<?php echo number_format($sale['total_amount'], 2); ?></td>
                                    <td><a href="sale-detail.php?id=<?php echo $sale['id']; ?>" class="btn btn-xs btn-primary">View</a></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
