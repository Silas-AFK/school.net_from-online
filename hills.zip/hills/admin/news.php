<?php
require_once '../config.php';

// Check authentication
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: ../index.php');
    exit();
}

$message = '';
$message_type = '';

// Handle news operations
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'add') {
        $title = trim($_POST['title'] ?? '');
        $content = trim($_POST['content'] ?? '');
        $status = $_POST['status'] ?? 'published';
        $user_id = $_SESSION['user_id'];
        
        if (!empty($title) && !empty($content)) {
            // Create uploads directory if it doesn't exist
            $upload_dir = '../uploads/news/';
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }
            
            $image_path = NULL;
            
            // Handle file upload
            if (isset($_FILES['news_image']) && $_FILES['news_image']['error'] === UPLOAD_ERR_OK) {
                $file_tmp = $_FILES['news_image']['tmp_name'];
                $file_name = $_FILES['news_image']['name'];
                $file_ext = pathinfo($file_name, PATHINFO_EXTENSION);
                
                $allowed_ext = ['jpg', 'jpeg', 'png', 'gif'];
                if (in_array(strtolower($file_ext), $allowed_ext)) {
                    $new_filename = 'news_' . time() . '.' . $file_ext;
                    $file_path = $upload_dir . $new_filename;
                    
                    if (move_uploaded_file($file_tmp, $file_path)) {
                        $image_path = 'uploads/news/' . $new_filename;
                    }
                }
            }
            
            $stmt = $conn->prepare("INSERT INTO news (title, content, image_path, created_by, status) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("sssss", $title, $content, $image_path, $user_id, $status);
            
            if ($stmt->execute()) {
                $message = 'News posted successfully!';
                $message_type = 'success';
            } else {
                $message = 'Error posting news';
                $message_type = 'error';
            }
            $stmt->close();
        }
    } elseif (isset($_POST['action']) && $_POST['action'] === 'delete') {
        $news_id = intval($_POST['news_id'] ?? 0);
        if ($news_id > 0) {
            $stmt = $conn->prepare("DELETE FROM news WHERE id = ?");
            $stmt->bind_param("i", $news_id);
            if ($stmt->execute()) {
                $message = 'News deleted successfully!';
                $message_type = 'success';
            }
            $stmt->close();
        }
    }
}

// Get all news
$news_items = [];
$result = $conn->query("SELECT n.*, u.full_name FROM news n LEFT JOIN users u ON n.created_by = u.id ORDER BY n.created_at DESC");
while ($row = $result->fetch_assoc()) {
    $news_items[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>News Management - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/admin.css">
    <style>
        .news-modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }
        
        .news-modal.active {
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .news-modal-content {
            background: white;
            padding: 30px;
            border-radius: 8px;
            max-width: 600px;
            width: 90%;
            max-height: 90vh;
            overflow-y: auto;
        }
        
        .close-btn {
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }
        
        .close-btn:hover {
            color: #e74c3c;
        }
        
        .news-grid {
            display: grid;
            gap: 20px;
        }
        
        .news-item {
            background: white;
            border-radius: 8px;
            overflow: hidden;
            border: 1px solid #e0e0e0;
            display: grid;
            grid-template-columns: 200px 1fr;
            gap: 20px;
            padding: 15px;
        }
        
        .news-image {
            width: 200px;
            height: 150px;
            object-fit: cover;
            border-radius: 4px;
            background: #f5f5f5;
        }
        
        .news-content {
            display: grid;
            gap: 10px;
        }
        
        @media (max-width: 768px) {
            .news-item {
                grid-template-columns: 1fr;
            }
            
            .news-image {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <nav class="sidebar">
            <div class="sidebar-header">
                <div class="logo">💊</div>
                <h2><?php echo SITE_NAME; ?></h2>
            </div>
            
            <ul class="nav-menu">
                <li><a href="dashboard.php" class="nav-link"><span class="icon">📊</span> Dashboard</a></li>
                <li><a href="products.php" class="nav-link"><span class="icon">💊</span> Products</a></li>
                <li><a href="drug-management.php" class="nav-link"><span class="icon">📸</span> Drug Info</a></li>
                <li><a href="news.php" class="nav-link active"><span class="icon">📰</span> News</a></li>
                <li><a href="sales.php" class="nav-link"><span class="icon">💰</span> Sales</a></li>
                <li><a href="inventory.php" class="nav-link"><span class="icon">📦</span> Inventory</a></li>
                <li><a href="reports.php" class="nav-link"><span class="icon">📈</span> Reports</a></li>
                <li><a href="logout.php" class="nav-link logout"><span class="icon">🚪</span> Logout</a></li>
            </ul>
        </nav>
        
        <!-- Main Content -->
        <main class="main-content">
            <header class="top-bar">
                <h1>News & Announcements</h1>
                <button class="btn btn-primary" onclick="openNewsModal()">+ Post News</button>
            </header>
            
            <div class="dashboard-content">
                <?php if ($message): ?>
                    <div class="alert alert-<?php echo $message_type; ?> animate-slide-down">
                        <?php echo htmlspecialchars($message); ?>
                    </div>
                <?php endif; ?>
                
                <div class="news-grid">
                    <?php foreach ($news_items as $item): ?>
                        <div class="news-item animate-fade-in">
                            <?php if (!empty($item['image_path'])): ?>
                                <img src="../<?php echo htmlspecialchars($item['image_path']); ?>" alt="<?php echo htmlspecialchars($item['title']); ?>" class="news-image">
                            <?php else: ?>
                                <div class="news-image" style="display: flex; align-items: center; justify-content: center; background: #f5f5f5;">
                                    <span style="font-size: 32px;">📰</span>
                                </div>
                            <?php endif; ?>
                            
                            <div class="news-content">
                                <h3><?php echo htmlspecialchars($item['title']); ?></h3>
                                <p><?php echo substr(htmlspecialchars($item['content']), 0, 150) . '...'; ?></p>
                                <div style="display: flex; gap: 10px; justify-content: space-between; align-items: center;">
                                    <small style="color: #999;">By: <?php echo htmlspecialchars($item['full_name'] ?? 'Admin'); ?> | <?php echo date('M d, Y', strtotime($item['created_at'])); ?></small>
                                    <form method="POST" style="display: inline;" onsubmit="return confirm('Delete this news?');">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="news_id" value="<?php echo $item['id']; ?>">
                                        <button type="submit" class="btn btn-xs btn-danger">Delete</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </main>
    </div>
    
    <!-- News Modal -->
    <div id="newsModal" class="news-modal">
        <div class="news-modal-content animate-slide-in">
            <span class="close-btn" onclick="closeNewsModal()">&times;</span>
            <h2>Post New News</h2>
            <form method="POST" enctype="multipart/form-data" style="display: grid; gap: 15px;">
                <input type="hidden" name="action" value="add">
                
                <div class="form-group">
                    <label>Title</label>
                    <input type="text" name="title" placeholder="News title" required class="form-input">
                </div>
                
                <div class="form-group">
                    <label>Content</label>
                    <textarea name="content" placeholder="News content" required class="form-input" style="min-height: 120px;"></textarea>
                </div>
                
                <div class="form-group">
                    <label>Image</label>
                    <input type="file" name="news_image" accept="image/*" class="form-input">
                </div>
                
                <div class="form-group">
                    <label>Status</label>
                    <select name="status" class="form-input">
                        <option value="published">Published</option>
                        <option value="draft">Draft</option>
                    </select>
                </div>
                
                <button type="submit" class="btn btn-primary btn-block">Post News</button>
            </form>
        </div>
    </div>
    
    <script>
        function openNewsModal() {
            document.getElementById('newsModal').classList.add('active');
        }
        
        function closeNewsModal() {
            document.getElementById('newsModal').classList.remove('active');
        }
        
        window.onclick = function(event) {
            const modal = document.getElementById('newsModal');
            if (event.target === modal) {
                modal.classList.remove('active');
            }
        }
    </script>
</body>
</html>
