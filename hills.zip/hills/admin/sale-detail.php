<?php
require_once '../config.php';

// Check authentication
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: ../index.php');
    exit();
}

$sale_id = intval($_GET['id'] ?? 0);
if ($sale_id === 0) {
    header('Location: sales.php');
    exit();
}

// Get sale details
$sale = null;
$stmt = $conn->prepare("SELECT * FROM sales WHERE id = ?");
$stmt->bind_param("i", $sale_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows > 0) {
    $sale = $result->fetch_assoc();
} else {
    header('Location: sales.php');
    exit();
}
$stmt->close();

// Get sale items
$items = [];
$result = $conn->query("
    SELECT si.*, p.product_name
    FROM sale_items si
    JOIN products p ON si.product_id = p.id
    WHERE si.sale_id = $sale_id
");
while ($row = $result->fetch_assoc()) {
    $items[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sale Details - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/admin.css">
</head>
<body>
    <div class="admin-container">
        <nav class="sidebar">
            <div class="sidebar-header">
                <div class="logo">💊</div>
                <h2><?php echo SITE_NAME; ?></h2>
            </div>
            
            <ul class="nav-menu">
                <li><a href="dashboard.php" class="nav-link"><span class="icon">📊</span> Dashboard</a></li>
                <li><a href="products.php" class="nav-link"><span class="icon">💊</span> Products</a></li>
                <li><a href="sales.php" class="nav-link active"><span class="icon">💰</span> Sales</a></li>
                <li><a href="inventory.php" class="nav-link"><span class="icon">📦</span> Inventory</a></li>
                <li><a href="users.php" class="nav-link"><span class="icon">👥</span> Users</a></li>
                <li><a href="reports.php" class="nav-link"><span class="icon">📈</span> Reports</a></li>
                <li><a href="logout.php" class="nav-link logout"><span class="icon">🚪</span> Logout</a></li>
            </ul>
        </nav>
        
        <main class="main-content">
            <header class="top-bar">
                <div>
                    <h1>Sale #<?php echo $sale['id']; ?></h1>
                    <p style="margin: 5px 0 0 0; color: var(--gray);">
                        <?php echo date('F d, Y H:i:s', strtotime($sale['sale_date'])); ?>
                    </p>
                </div>
                <a href="sales.php" class="btn btn-secondary">Back to Sales</a>
            </header>
            
            <div class="dashboard-content">
                <div class="card animate-slide-up">
                    <h2 style="margin-bottom: 20px;">Items Purchased</h2>
                    
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Quantity</th>
                                <th>Unit Price</th>
                                <th>Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($items as $item): ?>
                                <tr class="animate-table-row">
                                    <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                                    <td><?php echo $item['quantity']; ?></td>
                                    <td class="price">$<?php echo number_format($item['unit_price'], 2); ?></td>
                                    <td class="price">$<?php echo number_format($item['subtotal'], 2); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    
                    <div style="text-align: right; margin-top: 20px; padding-top: 20px; border-top: 2px solid #e0e0e0;">
                        <h3 style="color: var(--primary); font-size: 24px;">
                            Total: $<?php echo number_format($sale['total_amount'], 2); ?>
                        </h3>
                        <p style="color: var(--gray); margin-top: 10px;">
                            Payment Method: <?php echo htmlspecialchars($sale['payment_method'] ?? 'Not specified'); ?>
                        </p>
                    </div>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
