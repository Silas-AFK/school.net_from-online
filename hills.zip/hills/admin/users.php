<?php
require_once '../config.php';

// Check authentication
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: ../index.php');
    exit();
}

// Get all users
$users = [];
$result = $conn->query("SELECT id, username, email, full_name, phone, user_type, created_at FROM users ORDER BY created_at DESC");
while ($row = $result->fetch_assoc()) {
    $users[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Users - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/admin.css">
</head>
<body>
    <div class="admin-container">
        <nav class="sidebar">
            <div class="sidebar-header">
                <div class="logo">💊</div>
                <h2><?php echo SITE_NAME; ?></h2>
            </div>
            
            <ul class="nav-menu">
                <li><a href="dashboard.php" class="nav-link"><span class="icon">📊</span> Dashboard</a></li>
                <li><a href="products.php" class="nav-link"><span class="icon">💊</span> Products</a></li>
                <li><a href="sales.php" class="nav-link"><span class="icon">💰</span> Sales</a></li>
                <li><a href="inventory.php" class="nav-link"><span class="icon">📦</span> Inventory</a></li>
                <li><a href="users.php" class="nav-link active"><span class="icon">👥</span> Users</a></li>
                <li><a href="reports.php" class="nav-link"><span class="icon">📈</span> Reports</a></li>
                <li><a href="logout.php" class="nav-link logout"><span class="icon">🚪</span> Logout</a></li>
            </ul>
        </nav>
        
        <main class="main-content">
            <header class="top-bar">
                <h1>Users Management</h1>
            </header>
            
            <div class="dashboard-content">
                <div class="card animate-slide-up">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Username</th>
                                <th>Full Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Type</th>
                                <th>Joined</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $user): ?>
                                <tr class="animate-table-row">
                                    <td><?php echo htmlspecialchars($user['username']); ?></td>
                                    <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                                    <td><?php echo htmlspecialchars($user['email']); ?></td>
                                    <td><?php echo htmlspecialchars($user['phone'] ?? '-'); ?></td>
                                    <td>
                                        <span class="badge <?php echo $user['user_type'] === 'admin' ? 'badge-warning' : 'badge-success'; ?>">
                                            <?php echo ucfirst($user['user_type']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
