<?php
require_once '../config.php';

// Check authentication
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: ../index.php');
    exit();
}

// Handle product operations
$message = '';
$message_type = '';

// Add product
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $product_name = trim($_POST['product_name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $price = floatval($_POST['price'] ?? 0);
    $quantity = intval($_POST['quantity'] ?? 0);
    $supplier = trim($_POST['supplier'] ?? '');
    $expiry_date = trim($_POST['expiry_date'] ?? '');
    
    if ($product_name && $category && $price > 0) {
        $stmt = $conn->prepare("INSERT INTO products (product_name, description, category, price, quantity_in_stock, supplier, expiry_date) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssidis", $product_name, $description, $category, $price, $quantity, $supplier, $expiry_date);
        
        if ($stmt->execute()) {
            $message = 'Product added successfully!';
            $message_type = 'success';
        } else {
            $message = 'Error adding product';
            $message_type = 'error';
        }
        $stmt->close();
    }
}

// Delete product
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    $product_id = intval($_POST['product_id'] ?? 0);
    if ($product_id > 0) {
        $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
        $stmt->bind_param("i", $product_id);
        if ($stmt->execute()) {
            $message = 'Product deleted successfully!';
            $message_type = 'success';
        }
        $stmt->close();
    }
}

// Get all products
$products = [];
$result = $conn->query("SELECT * FROM products ORDER BY product_name ASC");
while ($row = $result->fetch_assoc()) {
    $products[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/admin.css">
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <nav class="sidebar">
            <div class="sidebar-header">
                <div class="logo">💊</div>
                <h2><?php echo SITE_NAME; ?></h2>
            </div>
            
            <ul class="nav-menu">
                <li><a href="dashboard.php" class="nav-link"><span class="icon">📊</span> Dashboard</a></li>
                <li><a href="products.php" class="nav-link active"><span class="icon">💊</span> Products</a></li>
                <li><a href="sales.php" class="nav-link"><span class="icon">💰</span> Sales</a></li>
                <li><a href="inventory.php" class="nav-link"><span class="icon">📦</span> Inventory</a></li>
                <li><a href="users.php" class="nav-link"><span class="icon">👥</span> Users</a></li>
                <li><a href="reports.php" class="nav-link"><span class="icon">📈</span> Reports</a></li>
                <li><a href="logout.php" class="nav-link logout"><span class="icon">🚪</span> Logout</a></li>
            </ul>
        </nav>
        
        <!-- Main Content -->
        <main class="main-content">
            <header class="top-bar">
                <h1>Products Management</h1>
                <button class="btn btn-primary" onclick="openAddModal()">+ Add Product</button>
            </header>
            
            <div class="dashboard-content">
                <?php if ($message): ?>
                    <div class="alert alert-<?php echo $message_type; ?> animate-slide-down">
                        <?php echo htmlspecialchars($message); ?>
                    </div>
                <?php endif; ?>
                
                <div class="card">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Product Name</th>
                                <th>Category</th>
                                <th>Price</th>
                                <th>Stock</th>
                                <th>Supplier</th>
                                <th>Expiry Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($products as $product): ?>
                                <tr class="animate-table-row">
                                    <td class="product-name"><?php echo htmlspecialchars($product['product_name']); ?></td>
                                    <td><?php echo htmlspecialchars($product['category']); ?></td>
                                    <td class="price">$<?php echo number_format($product['price'], 2); ?></td>
                                    <td>
                                        <span class="badge <?php echo $product['quantity_in_stock'] <= $product['reorder_level'] ? 'badge-warning' : 'badge-success'; ?>">
                                            <?php echo $product['quantity_in_stock']; ?>
                                        </span>
                                    </td>
                                    <td><?php echo htmlspecialchars($product['supplier'] ?? '-'); ?></td>
                                    <td><?php echo $product['expiry_date'] ? date('M d, Y', strtotime($product['expiry_date'])) : '-'; ?></td>
                                    <td>
                                        <button class="btn btn-xs btn-secondary" onclick="editProduct(<?php echo $product['id']; ?>)">Edit</button>
                                        <form method="POST" style="display: inline;" onsubmit="return confirm('Delete this product?');">
                                            <input type="hidden" name="action" value="delete">
                                            <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                                            <button type="submit" class="btn btn-xs btn-danger">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
    
    <!-- Add/Edit Product Modal -->
    <div id="productModal" class="modal">
        <div class="modal-content animate-slide-in">
            <span class="close" onclick="closeAddModal()">&times;</span>
            <h2>Add New Product</h2>
            
            <form method="POST">
                <input type="hidden" name="action" value="add">
                
                <div class="form-group">
                    <label>Product Name *</label>
                    <input type="text" name="product_name" required class="form-input">
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Category *</label>
                        <input type="text" name="category" required class="form-input">
                    </div>
                    <div class="form-group">
                        <label>Price *</label>
                        <input type="number" name="price" step="0.01" required class="form-input">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label>Quantity</label>
                        <input type="number" name="quantity" value="0" class="form-input">
                    </div>
                    <div class="form-group">
                        <label>Expiry Date</label>
                        <input type="date" name="expiry_date" class="form-input">
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Supplier</label>
                    <input type="text" name="supplier" class="form-input">
                </div>
                
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" class="form-textarea"></textarea>
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Add Product</button>
                    <button type="button" class="btn btn-secondary" onclick="closeAddModal()">Cancel</button>
                </div>
            </form>
        </div>
    </div>
    
    <script src="../js/admin.js"></script>
</body>
</html>
