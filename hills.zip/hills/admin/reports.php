<?php
require_once '../config.php';

// Check authentication
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: ../index.php');
    exit();
}

// Sales by month
$monthly_sales = [];
$result = $conn->query("
    SELECT DATE_TRUNC(sale_date, MONTH) as month, SUM(total_amount) as total
    FROM sales
    WHERE status = 'completed'
    GROUP BY DATE_TRUNC(sale_date, MONTH)
    ORDER BY month DESC
    LIMIT 12
");

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $monthly_sales[] = $row;
    }
}

// Top selling products
$top_products = [];
$result = $conn->query("
    SELECT p.product_name, SUM(si.quantity) as total_sold, SUM(si.subtotal) as revenue
    FROM sale_items si
    JOIN products p ON si.product_id = p.id
    GROUP BY p.id
    ORDER BY total_sold DESC
    LIMIT 10
");

while ($row = $result->fetch_assoc()) {
    $top_products[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reports - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/admin.css">
</head>
<body>
    <div class="admin-container">
        <nav class="sidebar">
            <div class="sidebar-header">
                <div class="logo">💊</div>
                <h2><?php echo SITE_NAME; ?></h2>
            </div>
            
            <ul class="nav-menu">
                <li><a href="dashboard.php" class="nav-link"><span class="icon">📊</span> Dashboard</a></li>
                <li><a href="products.php" class="nav-link"><span class="icon">💊</span> Products</a></li>
                <li><a href="sales.php" class="nav-link"><span class="icon">💰</span> Sales</a></li>
                <li><a href="inventory.php" class="nav-link"><span class="icon">📦</span> Inventory</a></li>
                <li><a href="users.php" class="nav-link"><span class="icon">👥</span> Users</a></li>
                <li><a href="reports.php" class="nav-link active"><span class="icon">📈</span> Reports</a></li>
                <li><a href="logout.php" class="nav-link logout"><span class="icon">🚪</span> Logout</a></li>
            </ul>
        </nav>
        
        <main class="main-content">
            <header class="top-bar">
                <h1>Reports & Analytics</h1>
            </header>
            
            <div class="dashboard-content">
                <div class="card animate-slide-up">
                    <h2 style="margin-bottom: 20px;">Top Selling Products</h2>
                    
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Product Name</th>
                                <th>Total Sold</th>
                                <th>Revenue</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($top_products as $product): ?>
                                <tr class="animate-table-row">
                                    <td><?php echo htmlspecialchars($product['product_name']); ?></td>
                                    <td><?php echo $product['total_sold']; ?> units</td>
                                    <td class="price">$<?php echo number_format($product['revenue'], 2); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
