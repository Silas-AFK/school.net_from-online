<?php
require_once '../config.php';

// Check authentication
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: ../index.php');
    exit();
}

// Get low stock items
$low_stock = [];
$result = $conn->query("
    SELECT id, product_name, quantity_in_stock, reorder_level, category
    FROM products
    WHERE quantity_in_stock <= reorder_level
    ORDER BY quantity_in_stock ASC
");

while ($row = $result->fetch_assoc()) {
    $low_stock[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventory - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/admin.css">
</head>
<body>
    <div class="admin-container">
        <nav class="sidebar">
            <div class="sidebar-header">
                <div class="logo">💊</div>
                <h2><?php echo SITE_NAME; ?></h2>
            </div>
            
            <ul class="nav-menu">
                <li><a href="dashboard.php" class="nav-link"><span class="icon">📊</span> Dashboard</a></li>
                <li><a href="products.php" class="nav-link"><span class="icon">💊</span> Products</a></li>
                <li><a href="sales.php" class="nav-link"><span class="icon">💰</span> Sales</a></li>
                <li><a href="inventory.php" class="nav-link active"><span class="icon">📦</span> Inventory</a></li>
                <li><a href="users.php" class="nav-link"><span class="icon">👥</span> Users</a></li>
                <li><a href="reports.php" class="nav-link"><span class="icon">📈</span> Reports</a></li>
                <li><a href="logout.php" class="nav-link logout"><span class="icon">🚪</span> Logout</a></li>
            </ul>
        </nav>
        
        <main class="main-content">
            <header class="top-bar">
                <h1>Inventory Management</h1>
            </header>
            
            <div class="dashboard-content">
                <div class="card animate-slide-up">
                    <div class="card-header">
                        <h2>Low Stock Items</h2>
                    </div>
                    
                    <?php if (count($low_stock) > 0): ?>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Product Name</th>
                                    <th>Category</th>
                                    <th>Current Stock</th>
                                    <th>Reorder Level</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($low_stock as $item): ?>
                                    <tr class="animate-table-row">
                                        <td class="product-name"><?php echo htmlspecialchars($item['product_name']); ?></td>
                                        <td><?php echo htmlspecialchars($item['category']); ?></td>
                                        <td><?php echo $item['quantity_in_stock']; ?></td>
                                        <td><?php echo $item['reorder_level']; ?></td>
                                        <td>
                                            <span class="badge badge-warning">Reorder needed</span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div style="text-align: center; padding: 40px; color: var(--gray);">
                            <p style="font-size: 48px; margin-bottom: 10px;">✓</p>
                            <p>All items are in good stock!</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
