<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Hills Pharmacy - Quality Healthcare Products</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="about.css">
</head>
<body class="about-page">
    <!-- Navigation Bar -->
    <nav class="navbar">
        <div class="navbar-container">
            <div class="navbar-logo">
                <img src="logo.png" alt="Hills Pharmacy Logo" class="logo-img">
                <span class="logo-text">Hills Pharmacy</span>
            </div>
            <div class="nav-menu">
                <a href="public/about.html" class="nav-link active">About Us</a>
                <a href="public/news.php" class="nav-link">News</a>
                <a href="user/shop.php" class="nav-link">Shop</a>
                <a href="#contact" class="nav-link">Contact</a>
                <a href="public/login.php" class="btn btn-primary btn-sm">Login</a>
            </div>
            <div class="hamburger">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero">
       <div class="hero-text">
                <h1 class="hero-title animate-slide-down">Welcome to Hills Pharmacy</h1>
                <p class="hero-subtitle">Your Trusted Healthcare Partner in Bambili, Cameroon</p>
                <p class="hero-description">Providing quality pharmaceutical products and healthcare solutions since our establishment</p>
                <div class="hero-buttons">
                    <a href="#section-title" class="btn btn-primary btn-lg">Why shoose Us</a>
                    <a href="#contact" class="btn btn-secondary btn-lg">Contact Us</a>
                </div>
    </section>

    <!-- About Section -->
    <section class="about-section">
        <div class="container">
            <h2 class="section-title animate-fade-in">About Us</h2>
            <div class="about-grid">
                <div class="about-text animate-slide-up">
                    <h3>Quality Healthcare, Locally Delivered</h3>
                    <p>Hills Pharmacy is dedicated to providing premium pharmaceutical products and healthcare solutions to the Bambili community. With years of experience in the healthcare industry, we ensure every customer receives authentic, high-quality medications and wellness products.</p>
                    <p>Our mission is to make healthcare accessible, affordable, and reliable for everyone in our community.</p>
                </div>
                <div class="about-stats">
                    <div class="stat-card animate-slide-up">
                        <h4>100+</h4>
                        <p>Products</p>
                    </div>
                    <div class="stat-card animate-slide-up">
                        <h4>24/7</h4>
                        <p>Support</p>
                    </div>
                    <div class="stat-card animate-slide-up">
                        <h4>5000+</h4>
                        <p>Happy Customers</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="features-section">
        <div class="container">
            <h2 class="section-title">Why Choose Us</h2>
            <div class="features-grid">
                <div class="feature-card animate-fade-in">
                    <div class="feature-icon">🏥</div>
                    <h3>Licensed Pharmacy</h3>
                    <p>Fully licensed and regulated healthcare provider meeting all regulatory standards</p>
                </div>
                <div class="feature-card animate-fade-in">
                    <div class="feature-icon">💊</div>
                    <h3>Authentic Products</h3>
                    <p>100% genuine pharmaceutical products from trusted manufacturers</p>
                </div>
                <div class="feature-card animate-fade-in">
                    <div class="feature-icon">🚚</div>
                    <h3>Fast Delivery</h3>
                    <p>Quick and reliable delivery across Bambili and surrounding areas</p>
                </div>
                <div class="feature-card animate-fade-in">
                    <div class="feature-icon">💰</div>
                    <h3>Affordable Prices</h3>
                    <p>Competitive pricing without compromising on quality</p>
                </div>
                <div class="feature-card animate-fade-in">
                    <div class="feature-icon">👨‍⚕️</div>
                    <h3>Expert Advice</h3>
                    <p>Professional pharmacists available for health consultations</p>
                </div>
                <div class="feature-card animate-fade-in">
                    <div class="feature-icon">🛡️</div>
                    <h3>Secure Transactions</h3>
                    <p>Safe and secure payment methods for your peace of mind</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section class="contact-section" id="contact">
        <div class="container">
            <h2 class="section-title">Get In Touch</h2>
            <div class="contact-content">
                <div class="contact-info">
                    <div class="contact-card">
                        <h3>📍 Location</h3>
                        <p>Bambili, Cameroon</p>
                    </div>
                    <div class="contact-card">
                        <h3>📧 Email</h3>
                        <a href="mailto:ndehilary25@gmail.com">ndehilary25@gmail.com</a>
                    </div>
                    <div class="contact-card">
                        <h3>📞 Phone</h3>
                        <a href="tel:+237674756931">+237 674 756 931</a>
                    </div>
                    <div class="contact-card">
                        <h3>⏰ Hours</h3>
                        <p>Mon - Sat: 8AM - 6PM</p>
                        <p>Sunday: 9AM - 4PM</p>
                    </div>
                </div>
                <div class="contact-map">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3969.5!2d10.3!3d5.9!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2sBambili!5e0!3m2!1sen!2scm!4v1234567890" width="100%" height="300" style="border:0; border-radius:8px;" allowfullscreen="" loading="lazy"></iframe>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h4>Hills Pharmacy</h4>
                    <p>Your trusted healthcare partner since 2020</p>
                </div>
                <div class="footer-section">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="public/about.html">About Us</a></li>
                        <li><a href="public/news.php">News</a></li>
                        <li><a href="user/shop.php">Shop</a></li>
                        <li><a href="#contact">Contact</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Contact Info</h4>
                    <p>Email: ndehilary25@gmail.com</p>
                    <p>Phone: +237 674 756 931</p>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2026 Hills Pharmacy. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="js/responsive.js"></script>
</body>
</html>
