<?php
// Database configuration for XAMPP
define('DB_HOST', 'localhost');
define('DB_USER', 'root'); // Default XAMPP user
define('DB_PASS', ''); // Default XAMPP password is empty
define('DB_NAME', 'hills_pharmacy');

// Site information
define('SITE_NAME', 'Hills Pharmacy');
define('SITE_EMAIL', 'ndehilary25@gmail.com');
define('SITE_PHONE', '+237674756931');
define('SITE_LOCATION', 'Bambili, Cameroon');

// Create connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set charset to utf8
$conn->set_charset("utf8");

// Session settings
session_start();
?>
