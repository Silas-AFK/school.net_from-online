-- Hills Pharmacy Management System Database
-- Create this database in your XAMPP MySQL

CREATE DATABASE IF NOT EXISTS hills_pharmacy;
USE hills_pharmacy;

-- Users/Admin Table
CREATE TABLE IF NOT EXISTS users (
  id INT PRIMARY KEY AUTO_INCREMENT,
  username VARCHAR(50) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  email VARCHAR(100) NOT NULL,
  full_name VARCHAR(100) NOT NULL,
  phone VARCHAR(20),
  user_type ENUM('admin', 'user') DEFAULT 'user',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Products Table
CREATE TABLE IF NOT EXISTS products (
  id INT PRIMARY KEY AUTO_INCREMENT,
  product_name VARCHAR(255) NOT NULL,
  description TEXT,
  category VARCHAR(100) NOT NULL,
  price DECIMAL(10, 2) NOT NULL,
  quantity_in_stock INT NOT NULL DEFAULT 0,
  reorder_level INT DEFAULT 10,
  supplier VARCHAR(100),
  expiry_date DATE,
  batch_number VARCHAR(50),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Sales Table
CREATE TABLE IF NOT EXISTS sales (
  id INT PRIMARY KEY AUTO_INCREMENT,
  sale_date DATETIME DEFAULT CURRENT_TIMESTAMP,
  total_amount DECIMAL(10, 2) NOT NULL,
  payment_method VARCHAR(50),
  user_id INT,
  status ENUM('completed', 'pending', 'cancelled') DEFAULT 'completed',
  FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Sale Items Table
CREATE TABLE IF NOT EXISTS sale_items (
  id INT PRIMARY KEY AUTO_INCREMENT,
  sale_id INT NOT NULL,
  product_id INT NOT NULL,
  quantity INT NOT NULL,
  unit_price DECIMAL(10, 2) NOT NULL,
  subtotal DECIMAL(10, 2) NOT NULL,
  FOREIGN KEY (sale_id) REFERENCES sales(id) ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id)
);

-- Insert admin user (username: hilary, password: hilary123)
INSERT INTO users (username, password, email, full_name, phone, user_type) 
VALUES ('hilary', '$2y$10$YourHashedPasswordHere', 'ndehilary25@gmail.com', 'Hilary Admin', '+237674756931', 'admin');

-- Sample Products
INSERT INTO products (product_name, description, category, price, quantity_in_stock, supplier, expiry_date) VALUES
('Paracetamol 500mg', 'Pain reliever and fever reducer', 'Pain Relief', 2.50, 100, 'PharmaCorp', '2026-12-31'),
('Amoxicillin 250mg', 'Antibiotic capsules', 'Antibiotics', 5.00, 50, 'MediSupply', '2026-06-30'),
('Vitamin C 1000mg', 'Immune support supplement', 'Vitamins', 3.75, 75, 'HealthPlus', '2027-03-15'),
('Ibuprofen 400mg', 'Anti-inflammatory pain reliever', 'Pain Relief', 3.25, 60, 'PharmaCorp', '2026-10-20'),
('Cough Syrup', 'Effective cough suppressant', 'Cough & Cold', 4.50, 40, 'MediSupply', '2026-08-10');
