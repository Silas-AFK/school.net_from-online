// Shopping cart management using localStorage
const cart = JSON.parse(localStorage.getItem("hills_pharmacy_cart")) || {}

function addToCart(productId, productName, price) {
  const quantity = cart[productId] || 0
  cart[productId] = quantity + 1

  localStorage.setItem("hills_pharmacy_cart", JSON.stringify(cart))

  // Send to server
  const form = new FormData()
  form.append("product_id", productId)
  form.append("quantity", cart[productId])

  fetch("../api/add-to-cart.php", {
    method: "POST",
    body: form,
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        alert(productName + " added to cart!")
      }
    })
}

// Initialize cart on page load
document.addEventListener("DOMContentLoaded", () => {
  updateCartDisplay()
})

function updateCartDisplay() {
  const cartCount = Object.keys(cart).length
  const cartBtn = document.querySelector(".cart-btn")
  if (cartBtn && cartCount > 0) {
    cartBtn.innerHTML = "🛒 View Cart (" + cartCount + ")"
  }
}
