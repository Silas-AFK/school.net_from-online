// Open add product modal
function openAddModal() {
  const modal = document.getElementById("productModal")
  modal.classList.add("show")
}

// Close add product modal
function closeAddModal() {
  const modal = document.getElementById("productModal")
  modal.classList.remove("show")
}

// Close modal when clicking outside of it
window.addEventListener("click", (event) => {
  const modal = document.getElementById("productModal")
  if (modal && event.target === modal) {
    modal.classList.remove("show")
  }
})

// Edit product function
function editProduct(productId) {
  alert("Edit product " + productId + " - Coming soon")
}

// Sidebar toggle for mobile
function toggleSidebar() {
  const sidebar = document.querySelector(".sidebar")
  sidebar.classList.toggle("active")
}
