<?php
session_start();
include("db.php");

// Protect admin page
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit();
}

$booking_id = $_GET['id'] ?? 0;

// Fetch booking details
$booking = $conn->query("
    SELECT b.*, u.name AS user_name, u.email AS user_email, u.phone AS user_phone
    FROM bookings b
    JOIN users u ON b.user_id = u.id
    WHERE b.id = $booking_id
")->fetch_assoc();

// Fetch all drivers
$drivers = $conn->query("SELECT id, name, vehicle, email FROM drivers");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $driver_id = $_POST['driver_id'];

    $stmt = $conn->prepare("UPDATE bookings SET driver_id=?, status='assigned' WHERE id=?");
    $stmt->bind_param("ii", $driver_id, $booking_id);
    $stmt->execute();

    // Get driver details
    $driver_result = $conn->query("SELECT name, email FROM drivers WHERE id = $driver_id");
    $driver = $driver_result->fetch_assoc();

// Build driver notification message
$driver_message = "New ride assigned! Pickup: {$booking['pickup']}, Destination: {$booking['destination']}, Time: {$booking['time']}";

// Prepare insert safely
$stmt_driver_notif = $conn->prepare("
    INSERT INTO notifications (driver_id, booking_id, message) 
    VALUES (?, ?, ?)
");

// If prepare() failed, show the real MySQL error
if (!$stmt_driver_notif) {
    die("SQL ERROR (driver notification): " . $conn->error);
}

// Bind and execute safely
$stmt_driver_notif->bind_param("iis", $driver_id, $booking_id, $driver_message);
$stmt_driver_notif->execute();
$stmt_driver_notif->close();


    $user_message = "Your ride has been assigned to {$driver['name']}. Your driver will contact you shortly.";
    $stmt_user_notif = $conn->prepare("INSERT INTO notifications (user_id, booking_id, message) VALUES (?, ?, ?)");
    $stmt_user_notif->bind_param("iis", $booking['user_id'], $booking_id, $user_message);
    $stmt_user_notif->execute();

    $to_driver = $driver['email'];
    $subject_driver = "New Ride Assignment - Fast Drop";
    $body_driver = "Hello {$driver['name']},\n\nYou have been assigned a new ride:\n\n";
    $body_driver .= "Passenger: {$booking['user_name']}\n";
    $body_driver .= "Phone: {$booking['user_phone']}\n";
    $body_driver .= "Pickup: {$booking['pickup']}\n";
    $body_driver .= "Destination: {$booking['destination']}\n";
    $body_driver .= "Time: {$booking['time']}\n\n";
    $body_driver .= "Please login to your dashboard for more details.\n\nThank you,\nFast Drop Team";
    $headers_driver = "From: wankahpride0@gmail.com";
    
    @mail($to_driver, $subject_driver, $body_driver, $headers_driver);

    $to_user = $booking['user_email'];
    $subject_user = "Ride Confirmed - Fast Drop";
    $body_user = "Hello {$booking['user_name']},\n\nYour ride has been confirmed!\n\n";
    $body_user .= "Driver: {$driver['name']}\n";
    $body_user .= "Pickup: {$booking['pickup']}\n";
    $body_user .= "Destination: {$booking['destination']}\n";
    $body_user .= "Time: {$booking['time']}\n\n";
    $body_user .= "Your driver will contact you shortly.\n\nThank you for choosing Fast Drop!";
    $headers_user = "From: wankahpride0@gmail.com";
    
    @mail($to_user, $subject_user, $body_user, $headers_user);

    header("Location: admin_dashboard.php?assigned=1");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Assign Ride - Fast Drop</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body {font-family: Arial; background:#f4f4f4; padding:20px;}
        .box {
            max-width:500px; margin:auto; background:#fff; padding:20px;
            border-radius:10px; box-shadow:0 4px 10px rgba(0,0,0,0.1);
        }
        select, button {
            width:100%; padding:12px; margin:10px 0;
            border-radius:6px; border:1px solid #ccc;
        }
        button {
            background:#ffcc00; border:none; font-weight:bold; cursor:pointer;
        }
        button:hover {background:#000; color:#fff;}
        a {text-decoration:none; display:block; margin-top:10px; text-align:center;}
        
        /* Responsive improvements */
        @media (max-width: 600px) {
            body {padding: 10px;}
            .box {padding: 15px;}
        }
    </style>
</head>
<body>

<div class="box">
    <h2>Assign Ride</h2>

    <p><strong>Passenger:</strong> <?= $booking['user_name'] ?></p>
    <p><strong>Pickup:</strong> <?= $booking['pickup'] ?></p>
    <p><strong>Destination:</strong> <?= $booking['destination'] ?></p>

    <form method="POST">
        <label>Select Driver:</label>
        <select name="driver_id" required>
            <option value="">-- Choose Driver --</option>
            <?php while ($d = $drivers->fetch_assoc()): ?>
                <option value="<?= $d['id'] ?>">
                    <?= $d['name'] ?> — <?= $d['vehicle'] ?>
                </option>
            <?php endwhile; ?>
        </select>

        <button type="submit">Assign Ride</button>
    </form>

    <a href="admin_dashboard.php">⬅ Back to Dashboard</a>
</div>

</body>
</html>
