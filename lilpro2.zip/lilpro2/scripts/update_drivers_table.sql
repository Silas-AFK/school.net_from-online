-- Add email column to drivers table if it doesn't exist
ALTER TABLE drivers 
ADD COLUMN IF NOT EXISTS email VARCHAR(255) AFTER name;

-- Add index for faster email lookups
CREATE INDEX IF NOT EXISTS idx_driver_email ON drivers(email);
