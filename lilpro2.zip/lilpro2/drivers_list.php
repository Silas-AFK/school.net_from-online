<?php
session_start();
include("db.php");

// Protect admin page
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit();
}

// Handle delete request
if (isset($_GET['delete'])) {
    $driver_id = intval($_GET['delete']);

    // Delete driver safely
    $stmt = $conn->prepare("DELETE FROM drivers WHERE id = ?");
    $stmt->bind_param("i", $driver_id);
    $stmt->execute();
    $stmt->close();

    header("Location: drivers_list.php?deleted=1");
    exit();
}

// Fetch all drivers
$drivers = $conn->query("SELECT * FROM drivers ORDER BY id DESC");
?>
<!DOCTYPE html>
<html>
<head>
    <title>All Drivers - Fast Drop Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {font-family: Arial; background:#f4f4f4; margin:0; padding:20px;}
        h1 {text-align:center;}
        table {
            width:100%; border-collapse:collapse; background:#fff;
            border-radius:10px; overflow:hidden; margin-top:20px;
        }
        th, td {padding:14px; border-bottom:1px solid #ddd; text-align:left;}
        th {background:#000; color:#fff;}
        tr:hover {background:#f1f1f1;}
        .btn-delete {
            background:#dc3545; color:#fff; padding:6px 12px;
            border-radius:6px; text-decoration:none; font-weight:bold;
        }
        .btn-delete:hover {background:#b52a37;}
        .back-btn {
            display:inline-block; margin-bottom:20px; padding:10px 16px;
            background:#007bff; color:#fff; border-radius:6px; text-decoration:none;
        }
        .back-btn:hover {background:#0056b3;}
    </style>
</head>
<body>

<a class="back-btn" href="admin_dashboard.php">⬅ Back to Dashboard</a>

<h1>All Registered Drivers</h1>

<?php if (isset($_GET['deleted'])): ?>
    <p style="color:green; text-align:center; font-weight:bold;">Driver deleted successfully.</p>
<?php endif; ?>

<table>
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Vehicle</th>
        <th>Email</th>
        <th>Phone</th>
        <th>License Number</th>
        <th>Action</th>
    </tr>

    <?php while ($d = $drivers->fetch_assoc()): ?>
        <tr>
            <td><?= $d['id'] ?></td>
            <td><?= htmlspecialchars($d['name']) ?></td>
            <td><?= htmlspecialchars($d['vehicle']) ?></td>
            <td><?= htmlspecialchars($d['email']) ?></td>
            <td><?= htmlspecialchars($d['phone']) ?></td>
            <td><?= htmlspecialchars($d['license_number']) ?></td>
            <td>
                <a class="btn-delete"
                   href="drivers_list.php?delete=<?= $d['id'] ?>"
                   onclick="return confirm('Are you sure you want to delete this driver?');">
                   Delete
                </a>
            </td>
        </tr>
    <?php endwhile; ?>
</table>

</body>
</html>
