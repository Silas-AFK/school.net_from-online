<?php
// db.php – Central database connection file

$host     = "localhost";     // Database host
$user     = "root";          // Database username
$pass     = "";              // Database password
$dbname   = "fastdrop";      // Database name

// Create connection
$conn = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}

// Optional: Set charset to avoid encoding issues
$conn->set_charset("utf8mb4");
?>
