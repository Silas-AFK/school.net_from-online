<?php
// booking.php – Handles ride booking requests
include("db.php");

$response = [
    "status" => "error",
    "message" => "Unknown error occurred."
];

// Ensure request is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Collect form data
    $name        = $_POST['name'] ?? '';
    $email       = $_POST['email'] ?? '';
    $phone       = $_POST['phone'] ?? '';
    $pickup      = $_POST['pickup'] ?? '';
    $destination = $_POST['destination'] ?? '';
    $time        = $_POST['time'] ?? '';

    // Validate required fields
    if (empty($name) || empty($email) || empty($phone) || empty($pickup) || empty($destination) || empty($time)) {
        $response["message"] = "Please fill in all fields.";
        echo json_encode($response);
        exit();
    }

    // Insert or update user
    $hashed = password_hash("default123", PASSWORD_DEFAULT);

    $stmt = $conn->prepare("
        INSERT INTO users (name, email, phone, password)
        VALUES (?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE name = VALUES(name), phone = VALUES(phone)
    ");
    $stmt->bind_param("ssss", $name, $email, $phone, $hashed);
    $stmt->execute();

    // Get user ID
    if ($conn->insert_id > 0) {
        $user_id = $conn->insert_id;
    } else {
        $result = $conn->query("SELECT id FROM users WHERE email='$email'");
        $user_id = $result->fetch_assoc()['id'];
    }

    // Insert booking
    $status = "pending";
    $stmt2 = $conn->prepare("
        INSERT INTO bookings (user_id, pickup, destination, time, status)
        VALUES (?, ?, ?, ?, ?)
    ");
    $stmt2->bind_param("issss", $user_id, $pickup, $destination, $time, $status);

    if ($stmt2->execute()) {
        $response["status"] = "success";
        $response["message"] = "Ride booked successfully! A driver will contact you soon.";
    } else {
        $response["message"] = "Failed to book ride. Please try again.";
    }

    echo json_encode($response);
    exit();
}

// If accessed directly
$response["message"] = "Invalid request.";
echo json_encode($response);
exit();
?>
