<?php
// about.php – Fast Drop About Page
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>About Us - Fast Drop</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="assets/css/style.css">

    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f4f4f4;
        }

        header {
            background: #ffcc00;
            padding: 25px;
            text-align: center;
            animation: slideDown 1s ease;
        }

        header h1 {
            margin: 0;
            font-size: 32px;
            color: #000;
        }

        .container {
            max-width: 900px;
            margin: 30px auto;
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            animation: fadeIn 1s ease;
        }

        h2 {
            color: #333;
            margin-top: 0;
        }

        p {
            line-height: 1.7;
            color: #555;
        }

        .section {
            margin-bottom: 30px;
        }

        .values {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }

        .value-box {
            flex: 1 1 calc(33% - 20px);
            background: #ffcc00;
            padding: 20px;
            border-radius: 8px;
            color: #000;
            text-align: center;
            font-weight: bold;
            box-shadow: 0 3px 8px rgba(0,0,0,0.1);
            transition: 0.3s;
        }

        .value-box:hover {
            background: #000;
            color: #fff;
            transform: translateY(-5px);
        }

        footer {
            text-align: center;
            padding: 20px;
            background: #222;
            color: #fff;
            margin-top: 40px;
        }

        @keyframes slideDown {
            from { transform: translateY(-100%); }
            to   { transform: translateY(0); }
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: scale(0.95); }
            to   { opacity: 1; transform: scale(1); }
        }

        @media (max-width: 768px) {
            .value-box {
                flex: 1 1 100%;
            }
        }
    </style>
</head>

<body>

<!-- Added consistent navigation -->
<nav>
    <div class="logo">
        <a href="index.php">🚖 Fast Drop</a>
    </div>

    <button class="menu-btn" id="menu-btn" aria-label="Toggle Menu">☰</button>

    <div class="nav-menu" id="nav-menu">
        <a href="index.php">Home</a>
        <a href="about.php">About</a>
        <a href="contact.php">Contact</a>
        <a href="driver_register.php">Become a Driver</a>
        <a href="login.php">Admin Login</a>
        <a href="driver_login.php">Driver Login</a>
    </div>
</nav>

<header>
    <h1>About Fast Drop</h1>
    <p>Your trusted ride service in Bamenda, Cameroon</p>
</header>

<div class="container">

    <div class="section">
        <h2>Who We Are</h2>
        <p>
            Fast Drop is a modern ride‑booking service based in Bamenda, Cameroon.  
            We connect passengers with reliable drivers to ensure safe, fast, and affordable transportation across the city.
        </p>
    </div>

    <div class="section">
        <h2>Our Mission</h2>
        <p>
            Our mission is to make transportation easier for everyone.  
            Whether you're heading to work, school, or an event, Fast Drop ensures you get there comfortably and on time.
        </p>
    </div>

    <div class="section">
        <h2>Why Choose Us?</h2>
        <div class="values">
            <div class="value-box">✅ Safe Rides</div>
            <div class="value-box">✅ Professional Drivers</div>
            <div class="value-box">✅ Affordable Prices</div>
            <div class="value-box">✅ Fast Pickup</div>
            <div class="value-box">✅ 24/7 Availability</div>
            <div class="value-box">✅ Easy Booking</div>
        </div>
    </div>

    <div class="section">
        <h2>Contact Information</h2>
        <p><strong>Email:</strong> wankahpride0@gmail.com</p>
        <p><strong>Phone:</strong> 678677863</p>
        <p><strong>Location:</strong> Bamenda, Cameroon</p>
    </div>

</div>

<footer>
    <p>&copy; <?= date("Y") ?> Fast Drop. All Rights Reserved.</p>
</footer>

<script src="assets/js/script.js"></script>

</body>
</html>
