<?php
// driver_dashboard.php – Driver Panel
session_start();
include("db.php");

// Require real driver login
if (!isset($_SESSION['driver_id'])) {
    header("Location: driver_login.php");
    exit();
}

$driver_id = $_SESSION['driver_id'];

/* ---------------------------------------------------------
   FETCH DRIVER DETAILS
--------------------------------------------------------- */
$driver = [];
$stmt = $conn->prepare("SELECT * FROM drivers WHERE id = ?");
$stmt->bind_param("i", $driver_id);
$stmt->execute();
$driver = $stmt->get_result()->fetch_assoc();
$stmt->close();

/* ---------------------------------------------------------
   MARK RIDE AS COMPLETED
--------------------------------------------------------- */
if (isset($_GET['complete'])) {
    $booking_id = intval($_GET['complete']);

    $stmt = $conn->prepare("UPDATE bookings SET status='completed' WHERE id=? AND driver_id=?");
    if ($stmt) {
        $stmt->bind_param("ii", $booking_id, $driver_id);
        $stmt->execute();
        $stmt->close();
    }

    $stmt2 = $conn->prepare("UPDATE notifications SET is_read=1 WHERE booking_id=? AND driver_id=?");
    if ($stmt2) {
        $stmt2->bind_param("ii", $booking_id, $driver_id);
        $stmt2->execute();
        $stmt2->close();
    }
}

/* ---------------------------------------------------------
   MARK NOTIFICATION AS READ
--------------------------------------------------------- */
if (isset($_GET['read_notif'])) {
    $notif_id = intval($_GET['read_notif']);

    $stmt = $conn->prepare("UPDATE notifications SET is_read=1 WHERE id=? AND driver_id=?");
    if ($stmt) {
        $stmt->bind_param("ii", $notif_id, $driver_id);
        $stmt->execute();
        $stmt->close();
    }
}

/* ---------------------------------------------------------
   FETCH UNREAD NOTIFICATION COUNT
--------------------------------------------------------- */
$unread_count = 0;
$stmt = $conn->prepare("SELECT COUNT(*) AS count FROM notifications WHERE driver_id=? AND is_read=0");
$stmt->bind_param("i", $driver_id);
$stmt->execute();
$result = $stmt->get_result();
$unread_count = $result->fetch_assoc()['count'];
$stmt->close();

/* ---------------------------------------------------------
   FETCH NOTIFICATIONS
--------------------------------------------------------- */
$stmt = $conn->prepare("
    SELECT n.*, b.pickup, b.destination
    FROM notifications n
    LEFT JOIN bookings b ON n.booking_id = b.id
    WHERE n.driver_id = ?
    ORDER BY n.created_at DESC
    LIMIT 10
");
$stmt->bind_param("i", $driver_id);
$stmt->execute();
$notifications = $stmt->get_result();
$stmt->close();

/* ---------------------------------------------------------
   FETCH ASSIGNED RIDES
--------------------------------------------------------- */
$stmt = $conn->prepare("
    SELECT b.*, u.name AS user_name, u.phone AS user_phone
    FROM bookings b
    JOIN users u ON b.user_id = u.id
    WHERE b.driver_id = ?
    ORDER BY b.id DESC
");
$stmt->bind_param("i", $driver_id);
$stmt->execute();
$rides = $stmt->get_result();
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Driver Dashboard - Fast Drop</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <style>
        body { margin: 0; font-family: Arial, sans-serif; background: #f4f4f4; }
        header { background: #ffcc00; padding: 25px; text-align: center; position: relative; }
        header h1 { margin: 0; font-size: 32px; color: #000; }
        .logout, .back-home { position: absolute; top: 20px; padding: 10px 18px; border-radius: 6px; text-decoration: none; font-weight: bold; color: #fff; }
        .logout { right: 20px; background: #000; }
        .back-home { left: 20px; background: #007bff; }
        .container { max-width: 900px; margin: 30px auto; padding: 20px; }

        .profile-box {
            background:#fff; padding:20px; border-radius:10px;
            box-shadow:0 4px 12px rgba(0,0,0,0.1); margin-bottom:20px;
        }
        .profile-box h2 { margin-top:0; }

        .notification-section { background: #fff; padding: 20px; border-radius: 10px; margin-bottom: 20px; }
        .notification-badge { background: #dc3545; color: #fff; padding: 5px 10px; border-radius: 20px; }
        .notification-item { padding: 15px; border-bottom: 1px solid #ddd; display: flex; justify-content: space-between; }
        .notification-item.unread { background: #fff3cd; border-left: 4px solid #ffcc00; }

        table { width: 100%; margin-top: 20px; border-collapse: collapse; background: #fff; border-radius: 10px; overflow: hidden; }
        th, td { padding: 14px; border-bottom: 1px solid #ddd; }
        th { background: #000; color: #fff; }
        .btn-complete { background: #28a745; color: #fff; padding: 8px 14px; border-radius: 6px; text-decoration: none; }
    </style>
</head>

<body>

<header>
    <h1>Driver Dashboard</h1>
    <a class="back-home" href="index.php">⬅ Main Website</a>
    <a class="logout" href="driver_logout.php">Logout</a>
</header>

<div class="container">

    <!-- DRIVER PROFILE -->
    <div class="profile-box">
        <h2>Your Profile</h2>
        <p><strong>Name:</strong> <?= htmlspecialchars($driver['name']) ?></p>
        <p><strong>Email:</strong> <?= htmlspecialchars($driver['email']) ?></p>
        <p><strong>Phone:</strong> <?= htmlspecialchars($driver['phone']) ?></p>
        <p><strong>Vehicle:</strong> <?= htmlspecialchars($driver['vehicle']) ?></p>
        <p><strong>License Number:</strong> <?= htmlspecialchars($driver['license_number']) ?></p>
        <p><strong>Joined:</strong> <?= htmlspecialchars($driver['created_at']) ?></p>
    </div>

    <!-- Notifications -->
    <div class="notification-section">
        <h2>Notifications 
            <?php if ($unread_count > 0): ?>
                <span class="notification-badge"><?= $unread_count ?> New</span>
            <?php endif; ?>
        </h2>

        <?php if ($notifications->num_rows > 0): ?>
            <?php while ($notif = $notifications->fetch_assoc()): ?>
                <div class="notification-item <?= $notif['is_read'] ? '' : 'unread' ?>">
                    <div>
                        <strong><?= htmlspecialchars($notif['message']) ?></strong><br>
                        <small><?= date('M d, Y h:i A', strtotime($notif['created_at'])) ?></small>
                    </div>
                    <?php if (!$notif['is_read']): ?>
                        <a href="?read_notif=<?= $notif['id'] ?>" class="btn-complete">Mark Read</a>
                    <?php endif; ?>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>No notifications yet.</p>
        <?php endif; ?>
    </div>

    <!-- Rides -->
    <h2>Your Assigned Rides</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Passenger</th>
            <th>Pickup</th>
            <th>Destination</th>
            <th>Time</th>
            <th>Status</th>
            <th>Action</th>
        </tr>

        <?php if ($rides->num_rows > 0): ?>
            <?php while ($row = $rides->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['id'] ?></td>
                    <td><?= $row['user_name'] ?> (<?= $row['user_phone'] ?>)</td>
                    <td><?= $row['pickup'] ?></td>
                    <td><?= $row['destination'] ?></td>
                    <td><?= $row['time'] ?></td>
                    <td><?= $row['status'] ?></td>
                    <td>
                        <?php if ($row['status'] !== 'completed'): ?>
                            <a class="btn-complete" href="?complete=<?= $row['id'] ?>">Mark Completed</a>
                        <?php else: ?>
                            ✔ Done
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="7">No rides assigned yet.</td></tr>
        <?php endif; ?>
    </table>

</div>

<footer style="text-align:center; padding:20px; background:#222; color:#fff;">
    <p>&copy; <?= date("Y") ?> Fast Drop. All Rights Reserved.</p>
</footer>

</body>
</html>
