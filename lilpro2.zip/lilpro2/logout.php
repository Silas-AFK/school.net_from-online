<?php
// logout.php – Ends admin session
session_start();

// Destroy all admin session data
session_unset();
session_destroy();

// Redirect back to login page
header("Location: login.php");
exit();
?>
