<?php
session_start();
include("db.php");

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $phone = $_POST['phone'];
    $license = $_POST['license'];

    $stmt = $conn->prepare("SELECT id FROM drivers WHERE phone=? AND license=?");
    $stmt->bind_param("ss", $phone, $license);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows == 1) {
        $stmt->bind_result($driver_id);
        $stmt->fetch();

        $_SESSION['driver_id'] = $driver_id;
        header("Location: driver_dashboard.php");
        exit();
    } else {
        $error = "❌ Invalid phone or license number.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Driver Login - Fast Drop</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="assets/css/style.css">

    <style>
        body {font-family: Arial; background:#f4f4f4; margin:0;}
        .container {
            max-width:400px; margin:60px auto; background:#fff;
            padding:25px; border-radius:10px; box-shadow:0 4px 12px rgba(0,0,0,0.1);
        }
        input, button {
            width:100%; padding:12px; margin:10px 0;
            border-radius:6px; border:1px solid #ccc;
        }
        button {
            background:#ffcc00; border:none; font-weight:bold; cursor:pointer;
        }
        button:hover {background:#000; color:#fff;}
        .error {background:#f8d7da; padding:10px; border-radius:6px; color:#721c24; margin-bottom: 15px;}
        .back-btn {
            display:block; text-align:center; padding:12px; background:#000;
            color:#fff; text-decoration:none; border-radius:6px; margin-top:10px;
        }
        .back-btn:hover {
            background:#333;
        }
        
        /* Responsive improvements */
        @media (max-width: 600px) {
            .container {
                margin: 20px;
            }
        }
    </style>
</head>
<body>

<!-- Added navigation bar -->
<nav>
    <div class="logo">
        <a href="index.php">🚖 Fast Drop</a>
    </div>

    <button class="menu-btn" id="menu-btn" aria-label="Toggle Menu">☰</button>

    <div class="nav-menu" id="nav-menu">
        <a href="index.php">Home</a>
        <a href="about.php">About</a>
        <a href="contact.php">Contact</a>
        <a href="driver_register.php">Become a Driver</a>
        <a href="login.php">Admin Login</a>
        <a href="driver_login.php">Driver Login</a>
    </div>
</nav>

<div class="container">
    <h2>Driver Login</h2>

    <?php if ($error): ?>
        <div class="error"><?= $error ?></div>
    <?php endif; ?>

    <form method="POST">
        <input type="text" name="phone" placeholder="Phone Number" required>
        <input type="text" name="license" placeholder="Driver License Number" required>
        <button type="submit">Login</button>
    </form>

    <a href="index.php" class="back-btn">⬅ Back to Main Website</a>
</div>

<script src="assets/js/script.js"></script>

</body>
</html>
