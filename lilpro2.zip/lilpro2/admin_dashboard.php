<?php
// admin_dashboard.php – Admin Panel
session_start();
include("db.php");

// Redirect if not logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit();
}

// Fetch counts
$users_count    = $conn->query("SELECT COUNT(*) AS total FROM users")->fetch_assoc()['total'];
$drivers_count  = $conn->query("SELECT COUNT(*) AS total FROM drivers")->fetch_assoc()['total'];
$bookings_count = $conn->query("SELECT COUNT(*) AS total FROM bookings")->fetch_assoc()['total'];

// Fetch latest bookings with driver info
$latest_bookings = $conn->query("
    SELECT b.id, u.name AS user_name, b.pickup, b.destination, b.time, b.status,
           d.name AS driver_name
    FROM bookings b
    JOIN users u ON b.user_id = u.id
    LEFT JOIN drivers d ON b.driver_id = d.id
    ORDER BY b.id DESC LIMIT 20
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard - Fast Drop</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/style.css">

    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f4f4f4;
        }

        header {
            background: #ffcc00;
            padding: 25px;
            text-align: center;
            position: relative;
            animation: slideDown 1s ease;
        }

        header h1 {
            margin: 0;
            font-size: 32px;
            color: #000;
        }

        .logout, .back-home {
            position: absolute;
            top: 20px;
            padding: 10px 18px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: bold;
            color: #fff;
        }

        .logout {
            right: 20px;
            background: #000;
        }

        .logout:hover { background: #333; }

        .back-home {
            left: 20px;
            background: #007bff;
        }

        .back-home:hover { background: #0056b3; }

        .container {
            max-width: 1100px;
            margin: 30px auto;
            padding: 20px;
        }

        .stats {
            display: flex;
            gap: 20px;
            flex-wrap: wrap;
        }

        .stat-box {
            flex: 1 1 calc(33% - 20px);
            background: #fff;
            padding: 25px;
            border-radius: 10px;
            text-align: center;
            font-size: 22px;
            font-weight: bold;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            animation: fadeIn 1s ease;
        }

        .stat-box span {
            display: block;
            font-size: 40px;
            margin-top: 10px;
            color: #ffcc00;
        }

        table {
            width: 100%;
            margin-top: 30px;
            border-collapse: collapse;
            background: #fff;
            border-radius: 10px;
            overflow: hidden;
            animation: fadeIn 1.2s ease;
        }

        th, td {
            padding: 14px;
            border-bottom: 1px solid #ddd;
            text-align: left;
        }

        th {
            background: #000;
            color: #fff;
        }

        tr:hover {
            background: #f1f1f1;
        }

        .btn-assign {
            background: #007bff;
            color: #fff;
            padding: 6px 12px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: bold;
        }

        .btn-assign:hover {
            background: #0056b3;
        }

        .status {
            font-weight: bold;
            text-transform: capitalize;
        }

        .status.pending { color: #ff8800; }
        .status.assigned { color: #007bff; }
        .status.completed { color: #28a745; }

        footer {
            text-align: center;
            padding: 20px;
            background: #222;
            color: #fff;
            margin-top: 40px;
        }

        @keyframes slideDown {
            from { transform: translateY(-100%); }
            to   { transform: translateY(0); }
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: scale(0.95); }
            to   { opacity: 1; transform: scale(1); }
        }

        /* Enhanced responsive design */
        @media (max-width: 768px) {
            .stat-box {
                flex: 1 1 100%;
            }
            .container {
                padding: 10px;
            }
            .logout, .back-home {
                position: relative;
                display: inline-block;
                margin: 5px;
            }
            header {
                padding-bottom: 60px;
            }
        }
    </style>
</head>

<body>

<header>
    <h1>Fast Drop Admin Dashboard</h1>
    <a class="back-home" href="index.php">⬅ Main Website</a>
    <a class="logout" href="logout.php">Logout</a>
</header>

<div class="container">

    <!-- Display assignment success message -->
    <?php if (isset($_GET['assigned'])): ?>
        <div class="success">✅ Ride assigned successfully! Driver and user have been notified.</div>
    <?php endif; ?>

    <h2>Overview</h2>

    <div class="stats">
        <div class="stat-box">
            Total Users
            <span><?= $users_count ?></span>
        </div>

        <div class="stat-box">
    <a href="drivers_list.php" style="text-decoration:none; color:inherit;">
        Total Drivers
        <span><?= $drivers_count ?></span>
    </a>
</div>


      <div class="stat-box">
    <a href="bookings_list.php" style="text-decoration:none; color:inherit;">
        Total Bookings
        <span><?= $bookings_count ?></span>
    </a>
</div>

    </div>

    <h2>Latest Bookings</h2>

    <div class="table-container">
        <table>
            <tr>
                <th>ID</th>
                <th>User</th>
                <th>Pickup</th>
                <th>Destination</th>
                <th>Time</th>
                <th>Driver</th>
                <th>Status</th>
                <th>Action</th>
            </tr>

            <?php while ($row = $latest_bookings->fetch_assoc()): ?>
            <tr>
                <td><?= $row['id'] ?></td>
                <td><?= $row['user_name'] ?></td>
                <td><?= $row['pickup'] ?></td>
                <td><?= $row['destination'] ?></td>
                <td><?= $row['time'] ?></td>
                <td><?= $row['driver_name'] ? $row['driver_name'] : '—' ?></td>

                <td class="status <?= $row['status'] ?>">
                    <?= ucfirst($row['status']) ?>
                </td>

                <td>
                    <?php if ($row['status'] == 'pending'): ?>
                        <a class="btn-assign" href="assign_ride.php?id=<?= $row['id'] ?>">Assign</a>
                    <?php else: ?>
                        ✅
                    <?php endif; ?>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>

    <h2>Update Price List</h2>

    <?php
    if (isset($_POST['update_price'])) {
        $id = $_POST['id'];
        $amount = $_POST['amount'];

        $stmt = $conn->prepare("UPDATE prices SET amount=? WHERE id=?");
        $stmt->bind_param("ii", $amount, $id);
        $stmt->execute();

        echo "<div class='success'>✅ Price Updated</div>";
    }

    $prices = $conn->query("SELECT * FROM prices");
    ?>

    <div class="table-container">
        <table>
            <tr>
                <th>Description</th>
                <th>Amount (FCFA)</th>
                <th>Action</th>
            </tr>

            <?php while ($p = $prices->fetch_assoc()): ?>
            <tr>
                <td><?= $p['description'] ?></td>
                <td><?= $p['amount'] ?></td>
                <td>
                    <form method="POST" style="display:flex; gap:10px; align-items:center;">
                        <input type="hidden" name="id" value="<?= $p['id'] ?>">
                        <input type="number" name="amount" value="<?= $p['amount'] ?>" required style="max-width: 150px; margin: 0;">
                        <button type="submit" name="update_price" style="background:#ffcc00; padding:6px 12px; border:none; border-radius:6px; width:auto;">Update</button>
                    </form>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>

</div>

<footer>
    <p>&copy; <?= date("Y") ?> Fast Drop. All Rights Reserved.</p>
</footer>

<script src="assets/js/script.js"></script>

</body>
</html>
