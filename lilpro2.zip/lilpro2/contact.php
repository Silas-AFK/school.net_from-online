<?php
// contact.php – Fast Drop Contact Page

$success = "";
$error = "";

// Handle contact form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['send_message'])) {

    // Sanitize inputs
    $name    = trim($_POST['name']);
    $email   = trim($_POST['email']);
    $message = trim($_POST['message']);

    if ($name === "" || $email === "" || $message === "") {
        $error = "❌ Please fill in all fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "❌ Please enter a valid email address.";
    } else {
        // Email settings
        $to      = "silasafanwi6@gmail.com";
        $subject = "Fast Drop Contact Message from $name";
        $body    = "Name: $name\nEmail: $email\n\nMessage:\n$message";

        // Better email headers
        $headers  = "From: Fast Drop <no-reply@fastdrop.com>\r\n";
        $headers .= "Reply-To: $email\r\n";
        $headers .= "X-Mailer: PHP/" . phpversion();

        // Attempt to send email
        if (@mail($to, $subject, $body, $headers)) {
            $success = "✅ Your message has been sent successfully!";
        } else {
            $error = "❌ Failed to send message. Please try again later.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Contact Us - Fast Drop</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="assets/css/style.css">

    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f4f4f4;
        }

        header {
            background: #ffcc00;
            padding: 25px;
            text-align: center;
            animation: slideDown 1s ease;
        }

        header h1 {
            margin: 0;
            font-size: 32px;
            color: #000;
        }

        .container {
            max-width: 700px;
            margin: 30px auto;
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            animation: fadeIn 1s ease;
        }

        h2 {
            margin-top: 0;
            color: #333;
        }

        input, textarea, button {
            width: 100%;
            padding: 12px;
            margin: 12px 0;
            border-radius: 6px;
            border: 1px solid #ccc;
            font-size: 16px;
        }

        textarea {
            height: 150px;
            resize: none;
        }

        button {
            background: #ffcc00;
            border: none;
            cursor: pointer;
            transition: 0.3s;
            font-weight: bold;
        }

        button:hover {
            background: #000;
            color: #fff;
        }

        .success {
            background: #d4edda;
            padding: 12px;
            border-radius: 6px;
            color: #155724;
            margin-bottom: 15px;
            border-left: 5px solid #28a745;
        }

        .error {
            background: #f8d7da;
            padding: 12px;
            border-radius: 6px;
            color: #721c24;
            margin-bottom: 15px;
            border-left: 5px solid #dc3545;
        }

        .info-box {
            background: #ffcc00;
            padding: 20px;
            border-radius: 8px;
            margin-top: 20px;
            color: #000;
            font-weight: bold;
            box-shadow: 0 3px 8px rgba(0,0,0,0.1);
            animation: fadeIn 1.2s ease;
        }

        footer {
            text-align: center;
            padding: 20px;
            background: #222;
            color: #fff;
            margin-top: 40px;
        }

        @keyframes slideDown {
            from { transform: translateY(-100%); }
            to   { transform: translateY(0); }
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: scale(0.95); }
            to   { opacity: 1; transform: scale(1); }
        }
    </style>
</head>

<body>

<!-- Navigation -->
<nav>
    <div class="logo">
        <a href="index.php">🚖 Fast Drop</a>
    </div>

    <button class="menu-btn" id="menu-btn" aria-label="Toggle Menu">☰</button>

    <div class="nav-menu" id="nav-menu">
        <a href="index.php">Home</a>
        <a href="about.php">About</a>
        <a href="contact.php">Contact</a>
        <a href="driver_register.php">Become a Driver</a>
        <a href="login.php">Admin Login</a>
        <a href="driver_login.php">Driver Login</a>
    </div>
</nav>

<header>
    <h1>Contact Fast Drop</h1>
    <p>We're here to help you anytime</p>
</header>

<div class="container">

    <?php if ($success): ?>
        <div class="success"><?= $success ?></div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="error"><?= $error ?></div>
    <?php endif; ?>

    <h2>Send Us a Message</h2>

    <form method="POST">
        <input type="text" name="name" placeholder="Your Name" required>

        <input type="email" name="email" placeholder="Your Email" required>

        <textarea name="message" placeholder="Your Message..." required></textarea>

        <button type="submit" name="send_message">Send Message</button>
    </form>

    <div class="info-box">
        📍 <strong>Location:</strong> Bamenda, Cameroon<br><br>
        📧 <strong>Email:</strong> wankahpride0@gmail.com<br><br>
        📞 <strong>Phone:</strong> 678677863
    </div>

</div>

<footer>
    <p>&copy; <?= date("Y") ?> Fast Drop. All Rights Reserved.</p>
</footer>

<script src="assets/js/script.js"></script>

</body>
</html>
