-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 22, 2025 at 12:32 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fastdrop`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `created_at`) VALUES
(1, 'pride', '$2y$10$examplehashdontuse', '2025-12-21 06:15:13');

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `driver_id` int(10) UNSIGNED DEFAULT NULL,
  `pickup` varchar(255) NOT NULL,
  `destination` varchar(255) NOT NULL,
  `time` datetime NOT NULL,
  `status` enum('pending','accepted','enroute','completed','cancelled') DEFAULT 'pending',
  `fare_estimate` decimal(10,2) DEFAULT NULL,
  `notes` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `user_id`, `driver_id`, `pickup`, `destination`, `time`, `status`, `fare_estimate`, `notes`, `created_at`, `updated_at`) VALUES
(1, 1, 2, 'Commercial Avenue, Bamenda', 'Up Station, Bamenda', '2025-12-20 23:15:13', 'completed', 1500.00, 'Handle with care', '2025-12-21 06:15:13', '2025-12-22 10:43:40'),
(2, 3, 5, 'newe bell', 'bambili', '2025-12-19 05:19:00', '', NULL, NULL, '2025-12-22 10:20:53', '2025-12-22 10:34:00'),
(3, 2, 6, 'food market', 'bambui', '2025-12-11 17:48:00', 'completed', NULL, NULL, '2025-12-22 10:47:06', '2025-12-22 11:03:09');

-- --------------------------------------------------------

--
-- Table structure for table `drivers`
--

CREATE TABLE `drivers` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `license` varchar(50) NOT NULL,
  `vehicle` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `status` enum('active','inactive','blocked') DEFAULT 'inactive',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `license_number` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `drivers`
--

INSERT INTO `drivers` (`id`, `name`, `email`, `license`, `vehicle`, `phone`, `status`, `created_at`, `updated_at`, `license_number`) VALUES
(1, 'Sample Driver', NULL, 'LIC-12345', 'Toyota Corolla - plate ABC123', '700000000', 'active', '2025-12-21 06:15:12', '2025-12-21 06:15:12', NULL),
(2, 'Afanwi Silas Shu', NULL, '0976865', 'toyota', '67676836', 'inactive', '2025-12-21 07:02:22', '2025-12-21 07:02:22', NULL),
(3, 'paa boy', NULL, '675875745', 'suzuki', '6757678', 'inactive', '2025-12-21 08:14:35', '2025-12-21 08:14:35', NULL),
(4, 'BLESSING BIH', 'bleesing10@gmail.com', '45676', 'baa', '678987954', 'inactive', '2025-12-21 20:56:46', '2025-12-21 20:56:46', NULL),
(5, 'Afanwi Silas Shu', 'silasafanwi6@gmail.com', '767655455', 'bodo', '676763842', 'inactive', '2025-12-22 10:21:48', '2025-12-22 10:21:48', NULL),
(6, 'mankah abinwi peace shu', 'bleesing100@gmail.com', '0000551', 'high landa', '692067701', 'inactive', '2025-12-22 10:45:39', '2025-12-22 10:45:39', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `driver_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `booking_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `driver_id`, `user_id`, `booking_id`, `message`, `is_read`, `created_at`) VALUES
(1, 5, NULL, 2, 'New ride assigned! Pickup: newe bell, Destination: bambili, Time: 2025-12-19 05:19:00', 0, '2025-12-22 10:41:46'),
(2, NULL, 3, 2, 'Your ride has been assigned to Afanwi Silas Shu. Your driver will contact you shortly.', 0, '2025-12-22 10:41:46'),
(3, 6, NULL, 3, 'New ride assigned! Pickup: food market, Destination: bambui, Time: 2025-12-11 17:48:00', 1, '2025-12-22 10:48:09'),
(4, NULL, 2, 3, 'Your ride has been assigned to mankah abinwi peace shu. Your driver will contact you shortly.', 0, '2025-12-22 10:48:09');

-- --------------------------------------------------------

--
-- Table structure for table `prices`
--

CREATE TABLE `prices` (
  `id` int(11) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `prices`
--

INSERT INTO `prices` (`id`, `description`, `amount`) VALUES
(1, 'Base Fare', 500),
(2, 'Price Per KM', 200),
(3, 'Waiting Charge Per Minute', 60);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(120) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `phone`, `password`, `created_at`, `updated_at`) VALUES
(1, 'Sample User', 'user@example.com', '600000000', '$2y$10$examplehashdontuse', '2025-12-21 06:15:12', '2025-12-21 06:15:12'),
(2, 'mama john', 'silasafanwi6@gmail.com', '676763842', '$2y$10$HyoDZkKG7yvm9WNDd/jAL.b0TIbKeSIW5u693L5wHujZCp0HhUhOO', '2025-12-21 20:48:44', '2025-12-22 10:47:06'),
(3, 'BLESSING BIH', 'bleesing10@gmail.com', '0678987954', '$2y$10$GPjfnzXT6hIguFfS3DAHfObudWLLBCZP.kUzPhHKFjvSgMPCbkGQO', '2025-12-22 10:20:53', '2025-12-22 10:20:53');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_admin_username` (`username`);

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_bookings_user` (`user_id`),
  ADD KEY `fk_bookings_driver` (`driver_id`),
  ADD KEY `idx_bookings_status` (`status`),
  ADD KEY `idx_bookings_time` (`time`);

--
-- Indexes for table `drivers`
--
ALTER TABLE `drivers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_drivers_license` (`license`),
  ADD UNIQUE KEY `uq_drivers_phone` (`phone`),
  ADD KEY `idx_driver_email` (`email`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prices`
--
ALTER TABLE `prices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_users_email` (`email`),
  ADD UNIQUE KEY `uq_users_phone` (`phone`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `drivers`
--
ALTER TABLE `drivers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `prices`
--
ALTER TABLE `prices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `fk_bookings_driver` FOREIGN KEY (`driver_id`) REFERENCES `drivers` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_bookings_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
