<?php
// driver_register.php – Driver Registration Page
include("db.php");

$success = "";
$error = "";

// Handle driver registration
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['register_driver'])) {

    $name    = $_POST['name'];
    $email   = $_POST['email'];
    $license = $_POST['license'];
    $vehicle = $_POST['vehicle'];
    $phone   = $_POST['phone'];

    // Check if driver already exists
    $check = $conn->prepare("SELECT id FROM drivers WHERE license=? OR phone=? OR email=?");
    $check->bind_param("sss", $license, $phone, $email);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        $error = "❌ A driver with this license, phone number, or email already exists.";
    } else {
        // Insert new driver
        $stmt = $conn->prepare("
            INSERT INTO drivers (name, email, license, vehicle, phone, status)
            VALUES (?, ?, ?, ?, ?, 'inactive')
        ");
        $stmt->bind_param("sssss", $name, $email, $license, $vehicle, $phone);

        if ($stmt->execute()) {
            $success = "✅ Registration successful! You will be contacted once approved.";
        } else {
            $error = "❌ Registration failed. Please try again.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Driver Registration - Fast Drop</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="assets/css/style.css">

    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f4f4f4;
        }

        header {
            background: #ffcc00;
            padding: 25px;
            text-align: center;
            animation: slideDown 1s ease;
        }

        header h1 {
            margin: 0;
            font-size: 32px;
            color: #000;
        }

        .container {
            max-width: 600px;
            margin: 30px auto;
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            animation: fadeIn 1s ease;
        }

        h2 {
            margin-top: 0;
            color: #333;
        }

        input, button {
            width: 100%;
            padding: 12px;
            margin: 12px 0;
            border-radius: 6px;
            border: 1px solid #ccc;
            font-size: 16px;
        }

        button {
            background: #ffcc00;
            border: none;
            cursor: pointer;
            transition: 0.3s;
            font-weight: bold;
        }

        button:hover {
            background: #000;
            color: #fff;
        }

        .success {
            background: #d4edda;
            padding: 12px;
            border-radius: 6px;
            color: #155724;
            margin-bottom: 15px;
            border-left: 5px solid #28a745;
        }

        .error {
            background: #f8d7da;
            padding: 12px;
            border-radius: 6px;
            color: #721c24;
            margin-bottom: 15px;
            border-left: 5px solid #dc3545;
        }

        footer {
            text-align: center;
            padding: 20px;
            background: #222;
            color: #fff;
            margin-top: 40px;
        }

        @keyframes slideDown {
            from { transform: translateY(-100%); }
            to   { transform: translateY(0); }
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: scale(0.95); }
            to   { opacity: 1; transform: scale(1); }
        }

        /* Responsive improvements */
        @media (max-width: 600px) {
            .container {
                margin: 15px;
                padding: 20px;
            }
        }
    </style>
</head>

<body>

<!-- Added consistent navigation -->
<nav>
    <div class="logo">
        <a href="index.php">🚖 Fast Drop</a>
    </div>

    <button class="menu-btn" id="menu-btn" aria-label="Toggle Menu">☰</button>

    <div class="nav-menu" id="nav-menu">
        <a href="index.php">Home</a>
        <a href="about.php">About</a>
        <a href="contact.php">Contact</a>
        <a href="driver_register.php">Become a Driver</a>
        <a href="login.php">Admin Login</a>
        <a href="driver_login.php">Driver Login</a>
    </div>
</nav>

<header>
    <h1>Driver Registration</h1>
    <p>Join Fast Drop and start earning</p>
</header>

<div class="container">

    <?php if ($success): ?>
        <div class="success"><?= $success ?></div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="error"><?= $error ?></div>
    <?php endif; ?>

    <h2>Register as a Driver</h2>

    <form method="POST">
        <input type="text" name="name" placeholder="Full Name" required>

        <!-- Added email field for notifications -->
        <input type="email" name="email" placeholder="Email Address" required>

        <input type="text" name="license" placeholder="Driver License Number" required>

        <input type="text" name="vehicle" placeholder="Vehicle Details (e.g., Toyota Corolla - Plate ABC123)" required>

        <input type="text" name="phone" placeholder="Phone Number" required>

        <button type="submit" name="register_driver">Register</button>
    </form>

</div>

<footer>
    <p>&copy; <?= date("Y") ?> Fast Drop. All Rights Reserved.</p>
</footer>

<script src="assets/js/script.js"></script>

</body>
</html>
