<?php
include("db.php");

// Handle booking form submission
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['book_ride'])) {

    // Sanitize inputs
    $name        = trim($_POST['name']);
    $email       = trim($_POST['email']);
    $phone       = trim($_POST['phone']);
    $pickup      = trim($_POST['pickup']);
    $destination = trim($_POST['destination']);
    $time        = trim($_POST['time']);

    // Default password for new users
    $default_password = password_hash("default123", PASSWORD_DEFAULT);

    // Insert user or update if email exists
    $stmt = $conn->prepare("
        INSERT INTO users (name, email, phone, password)
        VALUES (?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE 
            name = VALUES(name),
            phone = VALUES(phone)
    ");

    $stmt->bind_param("ssss", $name, $email, $phone, $default_password);
    $stmt->execute();

    // Get user ID (inserted or existing)
    if ($stmt->insert_id > 0) {
        $user_id = $stmt->insert_id;
    } else {
        $stmt_check = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt_check->bind_param("s", $email);
        $stmt_check->execute();
        $result = $stmt_check->get_result();
        $user_id = $result->fetch_assoc()['id'];
        $stmt_check->close();
    }

    // Insert booking
    $status = "pending";
    $stmt2 = $conn->prepare("
        INSERT INTO bookings (user_id, pickup, destination, time, status)
        VALUES (?, ?, ?, ?, ?)
    ");

    $stmt2->bind_param("issss", $user_id, $pickup, $destination, $time, $status);
    $stmt2->execute();

    $success = "Ride booked successfully! We'll assign a driver soon.";

    // Close statements
    $stmt->close();
    $stmt2->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Fast Drop - Book Your Ride</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <link rel="stylesheet" href="assets/css/style.css">

  <style>
    body {margin:0; font-family: Arial, sans-serif; background:#f9f9f9;}

    /* HERO SECTION */
    .hero {
        background:url('assets/images/home.jpeg') center/cover no-repeat;
        height:400px;
        display:flex;
        justify-content:center;
        align-items:center;
        text-align:center;
        color:#fff;
        padding:20px;
    }
    .hero h1 {
        font-size:40px;
        text-shadow:2px 2px 5px #000;
    }
    .hero p {
        font-size:20px;
        margin-top:10px;
        text-shadow:2px 2px 5px #000;
    }
    .hero .btn {
        margin-top:20px;
        background:#ffcc00;
        padding:12px 25px;
        border-radius:6px;
        color:#000;
        font-weight:bold;
        text-decoration:none;
        transition:0.3s;
        display: inline-block;
    }
    .hero .btn:hover {
        background:#fff;
    }

    /* BOOKING FORM */
    .container {
        max-width:600px;
        margin:30px auto;
        background:#fff;
        padding:20px;
        border-radius:8px;
        box-shadow:0 4px 10px rgba(0,0,0,0.1);
    }

    form input {
        width:100%;
        padding:10px;
        margin:10px 0;
        border:1px solid #ccc;
        border-radius:5px;
    }

    form button {
        background:#ffcc00;
        border:none;
        padding:12px;
        width:100%;
        font-size:16px;
        cursor:pointer;
        transition:0.3s;
    }
    form button:hover {
        background:#000;
        color:#fff;
    }

    .success {
        background:#d4edda;
        padding:10px;
        border-radius:5px;
        margin-bottom:15px;
        color:#155724;
    }

    footer {
        text-align:center;
        padding:20px;
        background:#222;
        color:#fff;
        margin-top:40px;
    }

    /* Responsive hero section for mobile */
    @media (max-width: 768px) {
        .hero {
            height: 300px;
        }
        .hero h1 {
            font-size: 28px;
        }
        .hero p {
            font-size: 16px;
        }
    }
  </style>
</head>

<body>

  <!-- Updated navigation with consistent structure -->
  <nav>
    <div class="logo">
        <a href="index.php">🚖 Fast Drop</a>
    </div>

    <button class="menu-btn" id="menu-btn" aria-label="Toggle Menu">☰</button>

    <div class="nav-menu" id="nav-menu">
        <a href="index.php">Home</a>
        <a href="about.php">About</a>
        <a href="contact.php">Contact</a>
        <a href="driver_register.php">Become a Driver</a>
        <a href="login.php">Admin Login</a>
        <a href="driver_login.php">Driver Login</a>
    </div>
  </nav>


  <!-- HERO SECTION WITH IMAGE -->
  <div class="hero">
      <div>
          <h1>Fast, Safe & Reliable Rides</h1>
          <p>Your trusted ride partner in Bamenda, Cameroon</p>
          <a href="driver_register.php" class="btn">Become a Driver</a>
      </div>
  </div>

  <?php
  $prices = $conn->query("SELECT * FROM prices");
  ?>

  <div class="container" style="margin-top:20px;">
    <h2>Price List</h2>
    <div class="table-container">
      <table style="width:100%; border-collapse:collapse;">
        <tr>
            <th style="background:#000; color:#fff; padding:10px;">Description</th>
            <th style="background:#000; color:#fff; padding:10px;">Amount (FCFA)</th>
        </tr>

        <?php while ($p = $prices->fetch_assoc()): ?>
        <tr>
            <td style="padding:10px; border-bottom:1px solid #ccc;"><?= $p['description'] ?></td>
            <td style="padding:10px; border-bottom:1px solid #ccc;"><?= $p['amount'] ?></td>
        </tr>
        <?php endwhile; ?>
      </table>
    </div>
  </div>


  <!-- BOOKING FORM -->
  <div class="container">
    <?php if(isset($success)) echo "<div class='success'>$success</div>"; ?>

    <h2>Book a Ride</h2>
    <form method="POST" action="">
      <input type="text" name="name" placeholder="Your Name" required>
      <input type="email" name="email" placeholder="Your Email" required>
      <input type="text" name="phone" placeholder="Phone Number" required>
      <input type="text" name="pickup" placeholder="Pickup Location" required>
      <input type="text" name="destination" placeholder="Destination" required>
      <input type="datetime-local" name="time" required>
      <button type="submit" name="book_ride">Book Ride</button>
    </form>
  </div>

  <footer>
    <p>📧 wankahpride0@gmail.com | 📞 678677863</p>
    <p>&copy; <?= date("Y") ?> Fast Drop. All rights reserved.</p>
  </footer>
  
  <script src="assets/js/script.js"></script>

</body>
</html>
