<?php
// login.php – Admin Login Page
session_start();

$error = "";

// Handle login
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {

    $username = $_POST['username'];
    $password = $_POST['password'];

    // Hardcoded admin credentials
    $admin_user = "pride";
    $admin_pass = "pride123";

    if ($username === $admin_user && $password === $admin_pass) {
        $_SESSION['admin_logged_in'] = true;
        header("Location: admin_dashboard.php");
        exit();
    } else {
        $error = "❌ Invalid username or password.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Login - Fast Drop</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="assets/css/style.css">

    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background: #f4f4f4;
        }

        header {
            background: #ffcc00;
            padding: 25px;
            text-align: center;
            animation: slideDown 1s ease;
        }

        header h1 {
            margin: 0;
            font-size: 32px;
            color: #000;
        }

        .container {
            max-width: 400px;
            margin: 50px auto;
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            animation: fadeIn 1s ease;
        }

        input, button {
            width: 100%;
            padding: 12px;
            margin: 12px 0;
            border-radius: 6px;
            border: 1px solid #ccc;
            font-size: 16px;
        }

        button {
            background: #ffcc00;
            border: none;
            cursor: pointer;
            transition: 0.3s;
            font-weight: bold;
        }

        button:hover {
            background: #000;
            color: #fff;
        }

        .error {
            background: #f8d7da;
            padding: 12px;
            border-radius: 6px;
            color: #721c24;
            margin-bottom: 15px;
            border-left: 5px solid #dc3545;
        }

        .back-btn {
            display: block;
            text-align: center;
            margin-top: 10px;
            padding: 12px;
            background: #000;
            color: #fff;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
            transition: 0.3s;
        }

        .back-btn:hover {
            background: #444;
        }

        footer {
            text-align: center;
            padding: 20px;
            background: #222;
            color: #fff;
            margin-top: 40px;
        }

        @keyframes slideDown {
            from { transform: translateY(-100%); }
            to   { transform: translateY(0); }
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: scale(0.95); }
            to   { opacity: 1; transform: scale(1); }
        }

        /* Responsive improvements */
        @media (max-width: 600px) {
            .container {
                margin: 20px;
            }
        }
    </style>
</head>

<body>

<!-- Added consistent navigation -->
<nav>
    <div class="logo">
        <a href="index.php">🚖 Fast Drop</a>
    </div>

    <button class="menu-btn" id="menu-btn" aria-label="Toggle Menu">☰</button>

    <div class="nav-menu" id="nav-menu">
        <a href="index.php">Home</a>
        <a href="about.php">About</a>
        <a href="contact.php">Contact</a>
        <a href="driver_register.php">Become a Driver</a>
        <a href="login.php">Admin Login</a>
        <a href="driver_login.php">Driver Login</a>
    </div>
</nav>

<header>
    <h1>Admin Login</h1>
    <p>Fast Drop Management Panel</p>
</header>

<div class="container">

    <?php if ($error): ?>
        <div class="error"><?= $error ?></div>
    <?php endif; ?>

    <form method="POST">
        <input type="text" name="username" placeholder="Admin Username" required>

        <input type="password" name="password" placeholder="Password" required>

        <button type="submit" name="login">Login</button>
    </form>

    <a href="index.php" class="back-btn">⬅ Back to Main Website</a>

</div>

<footer>
    <p>&copy; <?= date("Y") ?> Fast Drop. All Rights Reserved.</p>
</footer>

<script src="assets/js/script.js"></script>

</body>
</html>
