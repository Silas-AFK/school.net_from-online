/* ============================================================
   FAST DROP – GLOBAL JAVASCRIPT
   Enhances UI, animations, form validation, and mobile menu
============================================================ */

/* -------------------------------
   Fade-in on scroll animations
-------------------------------- */
const revealElements = document.querySelectorAll(".container, .value-box, table")

function revealOnScroll() {
  revealElements.forEach((el) => {
    const position = el.getBoundingClientRect().top
    const screenHeight = window.innerHeight

    if (position < screenHeight - 100) {
      el.style.opacity = "1"
      el.style.transform = "translateY(0)"
    }
  })
}

window.addEventListener("scroll", revealOnScroll)
window.addEventListener("load", revealOnScroll)

/* -------------------------------
   Button ripple effect
-------------------------------- */
document.querySelectorAll("button, .btn").forEach((btn) => {
  btn.addEventListener("click", function (e) {
    const circle = document.createElement("span")
    circle.classList.add("ripple")

    const x = e.clientX - e.target.offsetLeft
    const y = e.clientY - e.target.offsetTop

    circle.style.left = `${x}px`
    circle.style.top = `${y}px`

    this.appendChild(circle)

    setTimeout(() => circle.remove(), 600)
  })
})

/* -------------------------------
   Basic form validation
-------------------------------- */
function validateForm(form) {
  let valid = true
  const inputs = form.querySelectorAll("input, textarea")

  inputs.forEach((input) => {
    if (input.hasAttribute("required") && input.value.trim() === "") {
      input.style.border = "2px solid red"
      valid = false
    } else {
      input.style.border = "1px solid #ccc"
    }
  })

  return valid
}

/* -------------------------------
   AJAX Booking (Optional)
   Works if index.php uses JS instead of form action
-------------------------------- */
const bookingForm = document.querySelector("#bookingForm")

if (bookingForm) {
  bookingForm.addEventListener("submit", (e) => {
    e.preventDefault()

    if (!validateForm(bookingForm)) {
      alert("Please fill in all required fields.")
      return
    }

    const formData = new FormData(bookingForm)

    fetch("booking.php", {
      method: "POST",
      body: formData,
    })
      .then((res) => res.json())
      .then((data) => {
        alert(data.message)

        if (data.status === "success") {
          bookingForm.reset()
        }
      })
      .catch(() => {
        alert("Network error. Please try again.")
      })
  })
}

/* -------------------------------
   Smooth scroll for anchor links
-------------------------------- */
document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
  anchor.addEventListener("click", function (e) {
    e.preventDefault()
    const target = document.querySelector(this.getAttribute("href"))

    if (target) {
      target.scrollIntoView({ behavior: "smooth" })
    }
  })
})

/* -------------------------------
   Mobile menu toggle
-------------------------------- */
const menuBtn = document.getElementById("menu-btn")
const navMenu = document.getElementById("nav-menu")

if (menuBtn && navMenu) {
  menuBtn.addEventListener("click", () => {
    navMenu.classList.toggle("active")
  })

  document.addEventListener("click", (e) => {
    if (!menuBtn.contains(e.target) && !navMenu.contains(e.target)) {
      navMenu.classList.remove("active")
    }
  })

  navMenu.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
      navMenu.classList.remove("active")
    })
  })
}

/* -------------------------------
   Auto-refresh notifications for drivers (optional enhancement)
-------------------------------- */
const notificationSection = document.querySelector(".notification-section")

if (notificationSection && window.location.pathname.includes("driver_dashboard")) {
  // Check for new notifications every 30 seconds
  setInterval(() => {
    fetch(window.location.href)
      .then((res) => res.text())
      .then((html) => {
        const parser = new DOMParser()
        const doc = parser.parseFromString(html, "text/html")
        const newNotifSection = doc.querySelector(".notification-section")

        if (newNotifSection) {
          notificationSection.innerHTML = newNotifSection.innerHTML
        }
      })
      .catch((err) => console.log("Notification refresh error:", err))
  }, 30000)
}
