<?php
session_start();
include("db.php");

// Protect admin page
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: login.php");
    exit();
}

// Handle delete request
if (isset($_GET['delete'])) {
    $booking_id = intval($_GET['delete']);

    // Delete booking
    $stmt = $conn->prepare("DELETE FROM bookings WHERE id = ?");
    $stmt->bind_param("i", $booking_id);
    $stmt->execute();
    $stmt->close();

    header("Location: bookings_list.php?deleted=1");
    exit();
}

// Fetch all bookings with user + driver info
$bookings = $conn->query("
    SELECT b.*, 
           u.name AS user_name, u.phone AS user_phone, u.email AS user_email,
           d.name AS driver_name, d.phone AS driver_phone
    FROM bookings b
    JOIN users u ON b.user_id = u.id
    LEFT JOIN drivers d ON b.driver_id = d.id
    ORDER BY b.id DESC
");
?>
<!DOCTYPE html>
<html>
<head>
    <title>All Bookings - Fast Drop Admin</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {font-family: Arial; background:#f4f4f4; margin:0; padding:20px;}
        h1 {text-align:center;}
        table {
            width:100%; border-collapse:collapse; background:#fff;
            border-radius:10px; overflow:hidden; margin-top:20px;
        }
        th, td {padding:14px; border-bottom:1px solid #ddd; text-align:left;}
        th {background:#000; color:#fff;}
        tr:hover {background:#f1f1f1;}
        .btn-delete {
            background:#dc3545; color:#fff; padding:6px 12px;
            border-radius:6px; text-decoration:none; font-weight:bold;
        }
        .btn-delete:hover {background:#b52a37;}
        .back-btn {
            display:inline-block; margin-bottom:20px; padding:10px 16px;
            background:#007bff; color:#fff; border-radius:6px; text-decoration:none;
        }
        .back-btn:hover {background:#0056b3;}
    </style>
</head>
<body>

<a class="back-btn" href="admin_dashboard.php">⬅ Back to Dashboard</a>

<h1>All Bookings</h1>

<?php if (isset($_GET['deleted'])): ?>
    <p style="color:green; text-align:center; font-weight:bold;">Booking deleted successfully.</p>
<?php endif; ?>

<table>
    <tr>
        <th>ID</th>
        <th>User</th>
        <th>Driver</th>
        <th>Pickup</th>
        <th>Destination</th>
        <th>Time</th>
        <th>Status</th>
        <th>Action</th>
    </tr>

    <?php while ($b = $bookings->fetch_assoc()): ?>
        <tr>
            <td><?= $b['id'] ?></td>
            <td>
                <?= htmlspecialchars($b['user_name']) ?><br>
                <?= htmlspecialchars($b['user_phone']) ?>
            </td>
            <td>
                <?= $b['driver_name'] ? htmlspecialchars($b['driver_name']) : "Not Assigned" ?><br>
                <?= $b['driver_phone'] ?>
            </td>
            <td><?= htmlspecialchars($b['pickup']) ?></td>
            <td><?= htmlspecialchars($b['destination']) ?></td>
            <td><?= htmlspecialchars($b['time']) ?></td>
            <td><?= htmlspecialchars($b['status']) ?></td>
            <td>
                <a class="btn-delete"
                   href="bookings_list.php?delete=<?= $b['id'] ?>"
                   onclick="return confirm('Are you sure you want to delete this booking?');">
                   Delete
                </a>
            </td>
        </tr>
    <?php endwhile; ?>
</table>

</body>
</html>
